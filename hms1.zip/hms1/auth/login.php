<?php

session_start();

require_once "../includes/db.php";

if (
    isset($_SESSION['user_id']) &&
    !empty($_SESSION['user_id'])
) {
    header("Location: ../dashboard.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = isset($_POST['username'])
        ? trim($_POST['username'])
        : '';

    $password = isset($_POST['password'])
        ? $_POST['password']
        : '';

    if ($username === '' || $password === '') {

        $error = "Please enter your username and password.";

    } else {

        $stmt = $pdo->prepare("
            SELECT
                user_id,
                username,
                password_hash,
                full_name,
                role,
                status

            FROM users

            WHERE username = ?

            LIMIT 1
        ");

        $stmt->execute([$username]);

        $user = $stmt->fetch();

        if (!$user) {

            $error = "Invalid username or password.";

        } elseif ($user['status'] !== 'Active') {

            $error = "Your account is not active. Please contact the administrator.";

        } elseif (!password_verify($password, $user['password_hash'])) {

            $error = "Invalid username or password.";

        } else {

            /*
            |--------------------------------------------------------------------------
            | Regenerate Session ID
            |--------------------------------------------------------------------------
            */

            session_regenerate_id(true);

            $_SESSION['user_id'] = (int)$user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['role'] = $user['role'];

            $_SESSION['login_time'] = date('Y-m-d H:i:s');

            /*
            |--------------------------------------------------------------------------
            | Redirect to role dashboard
            |--------------------------------------------------------------------------
            */

            header("Location: ../dashboard.php");
            exit();
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Hospital Management System - Login</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            min-height: 100vh;
            background: linear-gradient(
                135deg,
                #0d6efd,
                #0a58ca
            );

            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            width: 100%;
            max-width: 430px;
            border: none;
            border-radius: 16px;
            box-shadow: 0 15px 40px rgba(0,0,0,.2);
        }

        .login-logo {
            width: 75px;
            height: 75px;
            border-radius: 50%;
            background: #0d6efd;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: auto;
            font-size: 32px;
            font-weight: bold;
        }

    </style>

</head>

<body>

<div class="container">

    <div class="card login-card mx-auto">

        <div class="card-body p-5">

            <div class="text-center mb-4">

                <div class="login-logo mb-3">
                    HMS
                </div>

                <h3 class="fw-bold">
                    Hospital Management System
                </h3>

                <p class="text-muted">
                    Sign in to your account
                </p>

            </div>


            <?php if ($error): ?>

                <div class="alert alert-danger">

                    <?= htmlspecialchars($error) ?>

                </div>

            <?php endif; ?>


            <form method="POST">

                <div class="mb-3">

                    <label class="form-label">
                        Username
                    </label>

                    <input
                        type="text"
                        name="username"
                        class="form-control form-control-lg"
                        autocomplete="username"
                        required
                        autofocus
                    >

                </div>


                <div class="mb-4">

                    <label class="form-label">
                        Password
                    </label>

                    <input
                        type="password"
                        name="password"
                        class="form-control form-control-lg"
                        autocomplete="current-password"
                        required
                    >

                </div>


                <button
                    type="submit"
                    class="btn btn-primary btn-lg w-100"
                >
                    Sign In
                </button>

            </form>

        </div>

    </div>

</div>

</body>
</html>