<?php
require_once __DIR__.'/../config/database.php';
$role=$pdo->query("SELECT id FROM roles WHERE name='Administrator' LIMIT 1")->fetchColumn();
if(!$role) exit('Administrator role missing. Import the SQL database first.');
$stmt=$pdo->prepare("INSERT INTO users(role_id,username,password_hash,full_name) VALUES(?,?,?,?)");
try{$stmt->execute([$role,'admin',password_hash('Admin@12345',PASSWORD_DEFAULT),'System Administrator']);echo 'Admin created. Username: admin Password: Admin@12345. DELETE THIS FILE NOW.';}catch(PDOException $e){echo 'Admin may already exist.';}
?>