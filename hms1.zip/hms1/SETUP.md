# HMS PHP Phase 1

1. Import `database/hospital_management.sql` into MySQL/phpMyAdmin.
2. Extract this project into `C:\xampp\htdocs\hospital_management` (XAMPP) or your web root.
3. Edit `config/database.php` if your MySQL username/password differs.
4. Start Apache and MySQL.
5. Visit `http://localhost/hospital_management/auth/create_admin.php`.
6. Login at `http://localhost/hospital_management/auth/login.php`.
7. Default development account: `admin` / `Admin@12345`.
8. DELETE `auth/create_admin.php` immediately after creating the account and change the password before production.

Included in this phase:
- PDO database connection
- Session authentication
- Admin bootstrap
- Dashboard
- Patient registration
- Patient search
- Patient profile and visit history
- Visit creation
- Visit queue

Next modules will use the same schema:
Triage -> Consultation -> Laboratory -> Pharmacy -> Billing -> Payments -> Receipts -> Reports -> M-Pesa Daraja.

Security before production:
- HTTPS
- strong database credentials
- CSRF protection
- role permissions
- server-side validation
- secure session cookies
- audit logging
- regular backups
- Kenyan health-data/privacy compliance
