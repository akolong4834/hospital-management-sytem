<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

if (!isset($_GET['visit_id']) || !is_numeric($_GET['visit_id'])) {
    die("Invalid visit ID.");
}

$visit_id = (int) $_GET['visit_id'];

/*
|--------------------------------------------------------------------------
| Get Visit, Patient, Triage and Existing Consultation
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.department,
        v.payment_category,
        v.chief_complaint,
        v.status AS visit_status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,

        t.id AS triage_id,
        t.weight_kg,
        t.height_cm,
        t.temperature_c,
        t.systolic_bp,
        t.diastolic_bp,
        t.pulse_bpm,
        t.respiratory_rate,
        t.spo2_percent,
        t.pain_score,
        t.symptoms AS triage_symptoms,
        t.priority,
        t.notes AS triage_notes,
        t.assessed_at,

        c.consultation_id,
        c.history_of_presenting_illness,
        c.past_medical_history,
        c.family_history,
        c.social_history,
        c.examination_findings,
        c.diagnosis,
        c.differential_diagnosis,
        c.treatment_plan,
        c.investigations_requested,
        c.laboratory_required,
        c.follow_up_instructions,
        c.referral_required,
        c.referral_notes,
        c.consultation_status

    FROM patient_visits v

    INNER JOIN patients p
        ON p.patient_id = v.patient_id

    LEFT JOIN triage t
        ON t.visit_id = v.visit_id

    LEFT JOIN consultations c
        ON c.visit_id = v.visit_id

    WHERE v.visit_id = ?

    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$visit_id]);

$visit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$visit) {
    die("Visit not found.");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Patient Consultation - HMS</title>

<style>

body {
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 1200px;
    margin: auto;
}

.card {
    background: #ffffff;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

h1 {
    margin-top: 0;
    color: #1f2937;
}

h2 {
    color: #374151;
    font-size: 20px;
    margin-bottom: 15px;
}

.patient-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.info-box {
    background: #f8fafc;
    padding: 12px;
    border-radius: 6px;
    border: 1px solid #e5e7eb;
}

.info-box strong {
    display: block;
    color: #374151;
    margin-bottom: 5px;
}

.vital-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

textarea,
input,
select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

textarea {
    resize: vertical;
}

.form-group {
    margin-bottom: 18px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 7px;
    color: #374151;
}

.radio-container {
    display: flex;
    gap: 25px;
    padding: 15px;
    background: #f8fafc;
    border: 1px solid #ddd;
    border-radius: 6px;
}

.radio-option {
    display: flex;
    align-items: center;
    gap: 8px;
}

.radio-option input {
    width: auto;
}

.lab-box {
    margin-top: 15px;
    padding: 15px;
    background: #eef8ff;
    border: 1px solid #b6d7f2;
    border-radius: 6px;
}

.hidden {
    display: none;
}

.required {
    color: #dc3545;
}

.btn {
    display: inline-block;
    padding: 11px 18px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    font-size: 14px;
}

.btn-primary {
    background: #198754;
    color: white;
}

.btn-secondary {
    background: #6c757d;
    color: white;
}

.alert {
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 20px;
}

.alert-info {
    background: #d1ecf1;
    color: #0c5460;
    border: 1px solid #bee5eb;
}

.priority-emergency {
    color: #dc3545;
    font-weight: bold;
}

.priority-urgent {
    color: #fd7e14;
    font-weight: bold;
}

.priority-routine {
    color: #198754;
    font-weight: bold;
}

.actions {
    margin-top: 25px;
    display: flex;
    gap: 10px;
}

@media(max-width: 900px) {

    .patient-grid,
    .vital-grid {
        grid-template-columns: repeat(2, 1fr);
    }

}

@media(max-width: 600px) {

    .patient-grid,
    .vital-grid {
        grid-template-columns: 1fr;
    }

}

</style>

</head>

<body>

<div class="container">

<!-- =========================================================
     HEADER
========================================================= -->

<div class="card">

    <h1>Patient Consultation</h1>

    <div class="alert alert-info">

        Patient has completed triage and is now ready for
        clinical consultation.

    </div>

    <div class="patient-grid">

        <div class="info-box">

            <strong>Patient Number</strong>

            <?= htmlspecialchars($visit['patient_number']) ?>

        </div>

        <div class="info-box">

            <strong>Patient Name</strong>

            <?= htmlspecialchars(
                trim(
                    $visit['first_name'] . ' ' .
                    $visit['middle_name'] . ' ' .
                    $visit['last_name']
                )
            ) ?>

        </div>

        <div class="info-box">

            <strong>Gender</strong>

            <?= htmlspecialchars($visit['gender'] ?? '') ?>

        </div>

        <div class="info-box">

            <strong>Date of Birth</strong>

            <?= htmlspecialchars($visit['date_of_birth'] ?? '') ?>

        </div>

        <div class="info-box">

            <strong>Phone</strong>

            <?= htmlspecialchars($visit['phone'] ?? '') ?>

        </div>

        <div class="info-box">

            <strong>Visit Number</strong>

            <?= htmlspecialchars($visit['visit_number'] ?? '') ?>

        </div>

        <div class="info-box">

            <strong>Visit Date</strong>

            <?= htmlspecialchars($visit['visit_date'] ?? '') ?>

        </div>

        <div class="info-box">

            <strong>Department</strong>

            <?= htmlspecialchars($visit['department'] ?? '') ?>

        </div>

        <div class="info-box">

            <strong>Chief Complaint</strong>

            <?= nl2br(
                htmlspecialchars(
                    $visit['chief_complaint'] ?? 'Not recorded'
                )
            ) ?>

        </div>

        <div class="info-box">

            <strong>Visit Status</strong>

            <?= htmlspecialchars($visit['visit_status'] ?? '') ?>

        </div>

    </div>

</div>


<!-- =========================================================
     TRIAGE INFORMATION
========================================================= -->

<div class="card">

    <h2>Triage Information</h2>

    <div class="vital-grid">

        <div class="info-box">

            <strong>Weight</strong>

            <?= htmlspecialchars($visit['weight_kg'] ?? '-') ?> kg

        </div>

        <div class="info-box">

            <strong>Height</strong>

            <?= htmlspecialchars($visit['height_cm'] ?? '-') ?> cm

        </div>

        <div class="info-box">

            <strong>Temperature</strong>

            <?= htmlspecialchars($visit['temperature_c'] ?? '-') ?> °C

        </div>

        <div class="info-box">

            <strong>Blood Pressure</strong>

            <?= htmlspecialchars($visit['systolic_bp'] ?? '-') ?>
            /
            <?= htmlspecialchars($visit['diastolic_bp'] ?? '-') ?>
            mmHg

        </div>

        <div class="info-box">

            <strong>Pulse</strong>

            <?= htmlspecialchars($visit['pulse_bpm'] ?? '-') ?> bpm

        </div>

        <div class="info-box">

            <strong>Respiratory Rate</strong>

            <?= htmlspecialchars($visit['respiratory_rate'] ?? '-') ?>

        </div>

        <div class="info-box">

            <strong>SpO₂</strong>

            <?= htmlspecialchars($visit['spo2_percent'] ?? '-') ?> %

        </div>

        <div class="info-box">

            <strong>Pain Score</strong>

            <?= htmlspecialchars($visit['pain_score'] ?? '-') ?>

        </div>

        <div class="info-box">

            <strong>Priority</strong>

            <span class="<?php

                if (($visit['priority'] ?? '') === 'Emergency') {
                    echo 'priority-emergency';
                } elseif (($visit['priority'] ?? '') === 'Urgent') {
                    echo 'priority-urgent';
                } else {
                    echo 'priority-routine';
                }

            ?>">

                <?= htmlspecialchars($visit['priority'] ?? 'Routine') ?>

            </span>

        </div>

    </div>

    <br>

    <div class="form-group">

        <label>Triage Symptoms</label>

        <div class="info-box">

            <?= nl2br(
                htmlspecialchars(
                    $visit['triage_symptoms'] ?? 'Not recorded'
                )
            ) ?>

        </div>

    </div>

    <div class="form-group">

        <label>Triage Notes</label>

        <div class="info-box">

            <?= nl2br(
                htmlspecialchars(
                    $visit['triage_notes'] ?? 'None'
                )
            ) ?>

        </div>

    </div>

</div>


<!-- =========================================================
     CONSULTATION FORM
========================================================= -->

<form method="POST" action="save.php">

<input type="hidden"
       name="visit_id"
       value="<?= $visit_id ?>">


<div class="card">

    <h2>Clinical Assessment</h2>

    <div class="form-group">

        <label>
            History of Present Illness
        </label>

        <textarea
            name="history_of_present_illness"
            rows="5"
            placeholder="Enter history of the present illness..."
        ><?= htmlspecialchars(
            $visit['history_of_present_illness'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Past Medical History
        </label>

        <textarea
            name="past_medical_history"
            rows="4"
            placeholder="Enter relevant past medical history..."
        ><?= htmlspecialchars(
            $visit['past_medical_history'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Family History
        </label>

        <textarea
            name="family_history"
            rows="4"
            placeholder="Enter relevant family history..."
        ><?= htmlspecialchars(
            $visit['family_history'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Social History
        </label>

        <textarea
            name="social_history"
            rows="4"
            placeholder="Enter relevant social history..."
        ><?= htmlspecialchars(
            $visit['social_history'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Examination Findings
        </label>

        <textarea
            name="examination_findings"
            rows="5"
            placeholder="Enter clinical examination findings..."
        ><?= htmlspecialchars(
            $visit['examination_findings'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Diagnosis <span class="required">*</span>
        </label>

        <textarea
            name="diagnosis"
            rows="4"
            required
            placeholder="Enter the clinical diagnosis..."
        ><?= htmlspecialchars(
            $visit['diagnosis'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Differential Diagnosis
        </label>

        <textarea
            name="differential_diagnosis"
            rows="4"
            placeholder="Enter differential diagnosis if applicable..."
        ><?= htmlspecialchars(
            $visit['differential_diagnosis'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Treatment Plan
        </label>

        <textarea
            name="treatment_plan"
            rows="5"
            placeholder="Enter treatment plan..."
        ><?= htmlspecialchars(
            $visit['treatment_plan'] ?? ''
        ) ?></textarea>

    </div>

</div>


<!-- =========================================================
     LABORATORY DECISION
========================================================= -->

<div class="card">

    <h2>Laboratory Investigation</h2>

    <div class="form-group">

        <label>
            Is Laboratory Investigation Required?
            <span class="required">*</span>
        </label>

        <div class="radio-container">

            <label class="radio-option">

                <input
                    type="radio"
                    name="laboratory_required"
                    value="Yes"
                    id="labYes"
                    <?= (($visit['laboratory_required'] ?? '') === 'Yes')
                        ? 'checked'
                        : '' ?>
                    required
                >

                <strong>Yes - Send Patient to Laboratory</strong>

            </label>


            <label class="radio-option">

                <input
                    type="radio"
                    name="laboratory_required"
                    value="No"
                    id="labNo"
                    <?= (($visit['laboratory_required'] ?? 'No') === 'No')
                        ? 'checked'
                        : '' ?>
                    required
                >

                <strong>No - Proceed to Pharmacy</strong>

            </label>

        </div>

    </div>


    <!-- LABORATORY DETAILS -->

    <div
        id="laboratorySection"
        class="lab-box hidden"
    >

        <div class="form-group">

            <label>
                Laboratory Investigations Requested
                <span class="required">*</span>
            </label>

            <textarea
                name="investigations_requested"
                id="investigations_requested"
                rows="5"
                placeholder="Example: FBC, Malaria Test, Blood Sugar, Urinalysis..."
            ><?= htmlspecialchars(
                $visit['investigations_requested'] ?? ''
            ) ?></textarea>

            <small>
                Specify the laboratory investigations required
                by the clinician.
            </small>

        </div>

    </div>


    <div
        id="pharmacyMessage"
        class="alert alert-info"
        style="display:none;"
    >

        <strong>Pharmacy:</strong>

        No laboratory investigation is required.

        After saving this consultation, the patient will be
        sent directly to the Pharmacy Queue.

    </div>

</div>


<!-- =========================================================
     FOLLOW-UP / REFERRAL
========================================================= -->

<div class="card">

    <h2>Follow-up and Referral</h2>

    <div class="form-group">

        <label>
            Follow-up Instructions
        </label>

        <textarea
            name="follow_up_instructions"
            rows="4"
            placeholder="Enter follow-up instructions..."
        ><?= htmlspecialchars(
            $visit['follow_up_instructions'] ?? ''
        ) ?></textarea>

    </div>


    <div class="form-group">

        <label>
            Referral Required?
        </label>

        <select name="referral_required">

            <option value="No"
                <?= (($visit['referral_required'] ?? 'No') === 'No')
                    ? 'selected'
                    : '' ?>>
                No
            </option>

            <option value="Yes"
                <?= (($visit['referral_required'] ?? '') === 'Yes')
                    ? 'selected'
                    : '' ?>>
                Yes
            </option>

        </select>

    </div>


    <div class="form-group">

        <label>
            Referral Notes
        </label>

        <textarea
            name="referral_notes"
            rows="4"
            placeholder="Enter referral details if applicable..."
        ><?= htmlspecialchars(
            $visit['referral_notes'] ?? ''
        ) ?></textarea>

    </div>

</div>


<!-- =========================================================
     ACTIONS
========================================================= -->

<div class="card">

    <div class="actions">

        <button
            type="submit"
            class="btn btn-primary"
        >
            Save Consultation
        </button>


        <a
            href="queue.php"
            class="btn btn-secondary"
        >
            Back to Consultation Queue
        </a>

    </div>

</div>

</form>

</div>


<script>

function updateLaboratorySection() {

    const yes = document.getElementById('labYes');
    const no = document.getElementById('labNo');

    const laboratorySection =
        document.getElementById('laboratorySection');

    const pharmacyMessage =
        document.getElementById('pharmacyMessage');

    const investigations =
        document.getElementById('investigations_requested');


    if (yes.checked) {

        laboratorySection.classList.remove('hidden');

        pharmacyMessage.style.display = 'none';

        investigations.required = true;

    }

    else if (no.checked) {

        laboratorySection.classList.add('hidden');

        pharmacyMessage.style.display = 'block';

        investigations.required = false;

    }

}


document
    .getElementById('labYes')
    .addEventListener('change', updateLaboratorySection);


document
    .getElementById('labNo')
    .addEventListener('change', updateLaboratorySection);


updateLaboratorySection();

</script>

</body>

</html>