<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header("Location: queue.php");
    exit;

}


/*
|--------------------------------------------------------------------------
| Get Visit ID
|--------------------------------------------------------------------------
*/

$visit_id = filter_input(
    INPUT_POST,
    'visit_id',
    FILTER_VALIDATE_INT
);

if (!$visit_id) {

    die("Invalid visit ID.");

}


/*
|--------------------------------------------------------------------------
| Collect Consultation Data
|--------------------------------------------------------------------------
*/

$history_of_present_illness =
    trim($_POST['history_of_present_illness'] ?? '');

$past_medical_history =
    trim($_POST['past_medical_history'] ?? '');

$family_history =
    trim($_POST['family_history'] ?? '');

$social_history =
    trim($_POST['social_history'] ?? '');

$examination_findings =
    trim($_POST['examination_findings'] ?? '');

$diagnosis =
    trim($_POST['diagnosis'] ?? '');

$differential_diagnosis =
    trim($_POST['differential_diagnosis'] ?? '');

$treatment_plan =
    trim($_POST['treatment_plan'] ?? '');

$laboratory_required =
    $_POST['laboratory_required'] ?? 'No';

$investigations_requested =
    trim($_POST['investigations_requested'] ?? '');

$follow_up_instructions =
    trim($_POST['follow_up_instructions'] ?? '');

$referral_required =
    $_POST['referral_required'] ?? 'No';

$referral_notes =
    trim($_POST['referral_notes'] ?? '');


/*
|--------------------------------------------------------------------------
| Validate Laboratory Decision
|--------------------------------------------------------------------------
*/

if (!in_array(
    $laboratory_required,
    ['Yes', 'No'],
    true
)) {

    $laboratory_required = 'No';

}


/*
|--------------------------------------------------------------------------
| Validate Diagnosis
|--------------------------------------------------------------------------
*/

if ($diagnosis === '') {

    die("Diagnosis is required.");

}


/*
|--------------------------------------------------------------------------
| Validate Laboratory Request
|--------------------------------------------------------------------------
*/

if (
    $laboratory_required === 'Yes' &&
    $investigations_requested === ''
) {

    die(
        "Laboratory is required. " .
        "Please specify the investigations requested."
    );

}


/*
|--------------------------------------------------------------------------
| If Laboratory is NOT Required
|--------------------------------------------------------------------------
|
| We deliberately clear the investigations field so that
| the database does not contain misleading laboratory orders.
|
*/

if ($laboratory_required === 'No') {

    $investigations_requested = null;

}


/*
|--------------------------------------------------------------------------
| Validate Referral
|--------------------------------------------------------------------------
*/

if (!in_array(
    $referral_required,
    ['Yes', 'No'],
    true
)) {

    $referral_required = 'No';

}


/*
|--------------------------------------------------------------------------
| Current Clinician
|--------------------------------------------------------------------------
*/

$clinician_id = isset($_SESSION['user_id'])
    ? (int) $_SESSION['user_id']
    : null;


/*
|--------------------------------------------------------------------------
| Determine Next Patient Status
|--------------------------------------------------------------------------
*/

if ($laboratory_required === 'Yes') {

    $next_status = 'Laboratory';

} else {

    $next_status = 'Pharmacy';

}


/*
|--------------------------------------------------------------------------
| Verify Visit Exists
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        visit_id,
        patient_id,
        status
    FROM patient_visits
    WHERE visit_id = ?
    LIMIT 1
");

$stmt->execute([$visit_id]);

$visit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$visit) {

    die("The selected visit does not exist.");

}


/*
|--------------------------------------------------------------------------
| Save Consultation
|--------------------------------------------------------------------------
*/

try {

    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | Check Existing Consultation
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT consultation_id
        FROM consultations
        WHERE visit_id = ?
        LIMIT 1
    ");

    $stmt->execute([$visit_id]);

    $existing =
        $stmt->fetch(PDO::FETCH_ASSOC);


    /*
    |--------------------------------------------------------------------------
    | Update Existing Consultation
    |--------------------------------------------------------------------------
    */

    if ($existing) {

        $consultation_id =
            (int) $existing['consultation_id'];


        $sql = "

            UPDATE consultations

            SET

                clinician_id = ?,

                history_of_presenting_illness = ?,

                past_medical_history = ?,

                family_history = ?,

                social_history = ?,

                examination_findings = ?,

                diagnosis = ?,

                differential_diagnosis = ?,

                treatment_plan = ?,

                investigations_requested = ?,

                laboratory_required = ?,

                follow_up_instructions = ?,

                referral_required = ?,

                referral_notes = ?,

                consultation_status = 'Completed',

                consultation_date = NOW()

            WHERE consultation_id = ?

        ";


        $stmt = $pdo->prepare($sql);


        $stmt->execute([

            $clinician_id,

            $history_of_presenting_illness,

            $past_medical_history,

            $family_history,

            $social_history,

            $examination_findings,

            $diagnosis,

            $differential_diagnosis,

            $treatment_plan,

            $investigations_requested,

            $laboratory_required,

            $follow_up_instructions,

            $referral_required,

            $referral_notes,

            $consultation_id

        ]);

    }


    /*
    |--------------------------------------------------------------------------
    | Create New Consultation
    |--------------------------------------------------------------------------
    */

    else {

        $sql = "

            INSERT INTO consultations

            (

                visit_id,

                clinician_id,

                history_of_presenting_illness,

                past_medical_history,

                family_history,

                social_history,

                examination_findings,

                diagnosis,

                differential_diagnosis,

                treatment_plan,

                investigations_requested,

                laboratory_required,

                follow_up_instructions,

                referral_required,

                referral_notes,

                consultation_status,

                consultation_date

            )

            VALUES

            (

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                ?,

                'Completed',

                NOW()

            )

        ";


        $stmt = $pdo->prepare($sql);


        $stmt->execute([

            $visit_id,

            $clinician_id,

            $history_of_presenting_illness,

            $past_medical_history,

            $family_history,

            $social_history,

            $examination_findings,

            $diagnosis,

            $differential_diagnosis,

            $treatment_plan,

            $investigations_requested,

            $laboratory_required,

            $follow_up_instructions,

            $referral_required,

            $referral_notes

        ]);

    }


    /*
    |--------------------------------------------------------------------------
    | Move Patient to Next Department
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("

        UPDATE patient_visits

        SET status = ?

        WHERE visit_id = ?

    ");

    $stmt->execute([

        $next_status,

        $visit_id

    ]);


    /*
    |--------------------------------------------------------------------------
    | Commit Transaction
    |--------------------------------------------------------------------------
    */

    $pdo->commit();


    /*
    |--------------------------------------------------------------------------
    | Redirect According to Clinical Decision
    |--------------------------------------------------------------------------
    */

    if ($laboratory_required === 'Yes') {

        header(
            "Location: ../laboratory/queue.php?saved=1"
        );

        exit;

    }


    header(
        "Location: ../pharmacy/queue.php?saved=1"
    );

    exit;


} catch (PDOException $e) {


    if ($pdo->inTransaction()) {

        $pdo->rollBack();

    }


    die(

        "<h3>Unable to save consultation</h3>" .

        "<p>" .

        htmlspecialchars(
            $e->getMessage()
        ) .

        "</p>"

    );

}