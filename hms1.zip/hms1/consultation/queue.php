<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

/*
|--------------------------------------------------------------------------
| Consultation Queue
|--------------------------------------------------------------------------
| Shows patients who have completed triage and are ready
| for consultation.
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.department,
        v.payment_category,
        v.chief_complaint,
        v.status AS visit_status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,

        t.id AS triage_id,
        t.weight_kg,
        t.height_cm,
        t.temperature_c,
        t.systolic_bp,
        t.diastolic_bp,
        t.pulse_bpm,
        t.respiratory_rate,
        t.spo2_percent,
        t.pain_score,
        t.symptoms,
        t.priority,
        t.notes AS triage_notes,
        t.assessed_at

    FROM patient_visits v

    INNER JOIN patients p
        ON p.patient_id = v.patient_id

    INNER JOIN triage t
        ON t.visit_id = v.visit_id

    LEFT JOIN consultations c
        ON c.visit_id = v.visit_id

    WHERE c.consultation_id IS NULL

    ORDER BY
        CASE t.priority
            WHEN 'Emergency' THEN 1
            WHEN 'Urgent' THEN 2
            ELSE 3
        END,
        t.assessed_at ASC
";

$stmt = $pdo->query($sql);

$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Consultation Queue - HMS</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: auto;
        }

        .header {
            background: #1f4e78;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 0 0 5px;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background: #1f4e78;
            color: white;
        }

        tr:nth-child(even) {
            background: #f8f9fa;
        }

        .patient-name {
            font-weight: bold;
        }

        .small {
            font-size: 12px;
            color: #666;
        }

        .btn {
            display: inline-block;
            padding: 8px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 13px;
            margin: 2px;
        }

        .btn-primary {
            background: #198754;
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .badge {
            display: inline-block;
            padding: 5px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge-routine {
            background: #e2e3e5;
            color: #41464b;
        }

        .badge-urgent {
            background: #fff3cd;
            color: #856404;
        }

        .badge-emergency {
            background: #f8d7da;
            color: #842029;
        }

        .empty {
            text-align: center;
            padding: 50px;
            color: #666;
        }

        .vitals {
            line-height: 1.6;
            font-size: 13px;
        }

    </style>

</head>

<body>

<div class="container">

    <div class="header">

        <h1>Consultation Queue</h1>

        <div>
            Patients who have completed triage and are awaiting consultation
        </div>

    </div>


    <div class="card">

        <?php if (empty($patients)): ?>

            <div class="empty">

                <h3>No Patients Awaiting Consultation</h3>

                <p>
                    Patients who complete triage will appear here.
                </p>

            </div>

        <?php else: ?>

            <div class="table-container">

                <table>

                    <thead>

                    <tr>

                        <th>#</th>

                        <th>Visit No.</th>

                        <th>Patient</th>

                        <th>Gender</th>

                        <th>Chief Complaint</th>

                        <th>Vital Signs</th>

                        <th>Priority</th>

                        <th>Triage Time</th>

                        <th>Action</th>

                    </tr>

                    </thead>

                    <tbody>

                    <?php foreach ($patients as $index => $patient): ?>

                        <tr>

                            <td>
                                <?= $index + 1 ?>
                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $patient['visit_number'] ?? ''
                                ) ?>

                                <div class="small">

                                    <?= htmlspecialchars(
                                        $patient['visit_type'] ?? ''
                                    ) ?>

                                </div>

                            </td>


                            <td>

                                <div class="patient-name">

                                    <?= htmlspecialchars(
                                        trim(
                                            $patient['first_name'] . ' ' .
                                            ($patient['middle_name'] ?? '') . ' ' .
                                            $patient['last_name']
                                        )
                                    ) ?>

                                </div>

                                <div class="small">

                                    Patient No:
                                    <?= htmlspecialchars(
                                        $patient['patient_number'] ?? ''
                                    ) ?>

                                </div>

                                <div class="small">

                                    Phone:
                                    <?= htmlspecialchars(
                                        $patient['phone'] ?? ''
                                    ) ?>

                                </div>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $patient['gender'] ?? ''
                                ) ?>

                            </td>


                            <td>

                                <?= nl2br(
                                    htmlspecialchars(
                                        $patient['chief_complaint'] ?? 'Not recorded'
                                    )
                                ) ?>

                            </td>


                            <td>

                                <div class="vitals">

                                    <strong>Weight:</strong>
                                    <?= htmlspecialchars(
                                        $patient['weight_kg'] ?? '-'
                                    ) ?> kg

                                    <br>

                                    <strong>Temp:</strong>
                                    <?= htmlspecialchars(
                                        $patient['temperature_c'] ?? '-'
                                    ) ?> °C

                                    <br>

                                    <strong>BP:</strong>
                                    <?= htmlspecialchars(
                                        $patient['systolic_bp'] ?? '-'
                                    ) ?>/<?= htmlspecialchars(
                                        $patient['diastolic_bp'] ?? '-'
                                    ) ?>

                                    <br>

                                    <strong>Pulse:</strong>
                                    <?= htmlspecialchars(
                                        $patient['pulse_bpm'] ?? '-'
                                    ) ?> bpm

                                    <br>

                                    <strong>SpO₂:</strong>
                                    <?= htmlspecialchars(
                                        $patient['spo2_percent'] ?? '-'
                                    ) ?>%

                                </div>

                            </td>


                            <td>

                                <?php

                                $priority =
                                    $patient['priority'] ?? 'Routine';

                                $priorityClass = 'badge-routine';

                                if ($priority === 'Urgent') {
                                    $priorityClass = 'badge-urgent';
                                }

                                if ($priority === 'Emergency') {
                                    $priorityClass = 'badge-emergency';
                                }

                                ?>

                                <span class="badge <?= $priorityClass ?>">

                                    <?= htmlspecialchars($priority) ?>

                                </span>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $patient['assessed_at'] ?? ''
                                ) ?>

                            </td>


                            <td>

                                <a
                                    href="consultation.php?visit_id=<?= (int)$patient['visit_id'] ?>"
                                    class="btn btn-primary"
                                >
                                    Start Consultation
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>

</div>

</body>

</html>