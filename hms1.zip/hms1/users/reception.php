<?php
require_once "../includes/db.php";
require_once "../includes/auth.php";

require_role(['Administrator', 'Receptionist']);

// Today's statistics
$stmt = $pdo->query("
    SELECT COUNT(*) 
    FROM patient_visits 
    WHERE visit_date = CURDATE()
");
$today_visits = (int)$stmt->fetchColumn();

$stmt = $pdo->query("
    SELECT COUNT(*) 
    FROM patients
");
$total_patients = (int)$stmt->fetchColumn();

$stmt = $pdo->query("
    SELECT COUNT(*)
    FROM patient_visits
    WHERE status = 'Registered'
");
$waiting_patients = (int)$stmt->fetchColumn();

// Recent visits
$stmt = $pdo->query("
    SELECT 
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.department,
        v.status,
        p.patient_number,
        CONCAT(
            p.first_name, ' ',
            COALESCE(p.middle_name, ''), ' ',
            p.last_name
        ) AS patient_name
    FROM patient_visits v
    INNER JOIN patients p 
        ON p.patient_id = v.patient_id
    ORDER BY v.visit_id DESC
    LIMIT 10
");

$recent_visits = $stmt->fetchAll();

$user_name = get_current_user_name();
$user_role = get_current_user_role();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Reception Dashboard - Hospital Management System</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>
        body {
            background: #f4f6f9;
        }

        .sidebar {
            min-height: 100vh;
            background: #0d6efd;
            color: white;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 12px 18px;
            border-radius: 6px;
            margin-bottom: 4px;
        }

        .sidebar a:hover {
            background: rgba(255,255,255,0.15);
        }

        .sidebar .active {
            background: rgba(255,255,255,0.2);
        }

        .stat-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        .stat-number {
            font-size: 30px;
            font-weight: bold;
        }

        .main-content {
            min-height: 100vh;
        }
    </style>
</head>

<body>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-md-3 col-lg-2 sidebar p-3">

            <h4 class="mb-4">
                🏥 HMS
            </h4>

            <div class="mb-4">
                <small>Logged in as</small>
                <strong class="d-block">
                    <?= htmlspecialchars($user_name) ?>
                </strong>

                <small>
                    <?= htmlspecialchars($user_role) ?>
                </small>
            </div>

            <a href="reception.php" class="active">
                🏠 Dashboard
            </a>

            <a href="../patients/index.php">
                👤 Patients
            </a>

            <a href="../patients/create.php">
                ➕ Register Patient
            </a>

            <a href="../visits/index.php">
                📋 Visits
            </a>

            <a href="../visits/create.php">
                ➕ Register Visit
            </a>

            <hr>

            <a href="../auth/logout.php">
                🚪 Logout
            </a>

        </div>

        <!-- MAIN CONTENT -->
        <div class="col-md-9 col-lg-10 main-content">

            <!-- TOP BAR -->
            <nav class="navbar bg-white shadow-sm mb-4 px-3">
                <div>
                    <h4 class="mb-0">
                        Reception Dashboard
                    </h4>
                    <small class="text-muted">
                        Patient registration and visit management
                    </small>
                </div>

                <div>
                    <span class="me-3">
                        <?= htmlspecialchars($user_name) ?>
                    </span>

                    <a
                        href="../auth/logout.php"
                        class="btn btn-outline-danger btn-sm"
                    >
                        Logout
                    </a>
                </div>
            </nav>

            <div class="container-fluid">

                <!-- STATISTICS -->
                <div class="row g-4 mb-4">

                    <div class="col-md-4">
                        <div class="card stat-card">
                            <div class="card-body">

                                <h6 class="text-muted">
                                    Total Patients
                                </h6>

                                <div class="stat-number text-primary">
                                    <?= number_format($total_patients) ?>
                                </div>

                                <a
                                    href="../patients/index.php"
                                    class="btn btn-sm btn-outline-primary mt-2"
                                >
                                    View Patients
                                </a>

                            </div>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="card stat-card">
                            <div class="card-body">

                                <h6 class="text-muted">
                                    Today's Visits
                                </h6>

                                <div class="stat-number text-success">
                                    <?= number_format($today_visits) ?>
                                </div>

                                <a
                                    href="../visits/index.php"
                                    class="btn btn-sm btn-outline-success mt-2"
                                >
                                    View Visits
                                </a>

                            </div>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="card stat-card">
                            <div class="card-body">

                                <h6 class="text-muted">
                                    Waiting Patients
                                </h6>

                                <div class="stat-number text-warning">
                                    <?= number_format($waiting_patients) ?>
                                </div>

                                <span class="text-muted">
                                    Registered / awaiting triage
                                </span>

                            </div>
                        </div>
                    </div>

                </div>


                <!-- QUICK ACTIONS -->
                <div class="card shadow-sm mb-4">

                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            Quick Actions
                        </h5>
                    </div>

                    <div class="card-body">

                        <div class="row g-3">

                            <div class="col-md-3">

                                <a
                                    href="../patients/create.php"
                                    class="btn btn-primary w-100 p-3"
                                >
                                    👤<br>
                                    <strong>Register Patient</strong>
                                </a>

                            </div>

                            <div class="col-md-3">

                                <a
                                    href="../visits/create.php"
                                    class="btn btn-success w-100 p-3"
                                >
                                    📋<br>
                                    <strong>New Visit</strong>
                                </a>

                            </div>

                            <div class="col-md-3">

                                <a
                                    href="../patients/index.php"
                                    class="btn btn-info w-100 p-3 text-white"
                                >
                                    🔎<br>
                                    <strong>Search Patients</strong>
                                </a>

                            </div>

                            <div class="col-md-3">

                                <a
                                    href="../visits/index.php"
                                    class="btn btn-secondary w-100 p-3"
                                >
                                    📑<br>
                                    <strong>View Visits</strong>
                                </a>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- RECENT VISITS -->
                <div class="card shadow-sm">

                    <div class="card-header bg-white d-flex justify-content-between align-items-center">

                        <h5 class="mb-0">
                            Recent Patient Visits
                        </h5>

                        <a
                            href="../visits/index.php"
                            class="btn btn-sm btn-primary"
                        >
                            View All
                        </a>

                    </div>

                    <div class="card-body">

                        <?php if (empty($recent_visits)): ?>

                            <div class="alert alert-info mb-0">
                                No patient visits have been registered yet.
                            </div>

                        <?php else: ?>

                            <div class="table-responsive">

                                <table class="table table-hover align-middle">

                                    <thead class="table-light">

                                        <tr>
                                            <th>#</th>
                                            <th>Patient Number</th>
                                            <th>Patient Name</th>
                                            <th>Visit Number</th>
                                            <th>Date</th>
                                            <th>Type</th>
                                            <th>Department</th>
                                            <th>Status</th>
                                        </tr>

                                    </thead>

                                    <tbody>

                                    <?php foreach ($recent_visits as $visit): ?>

                                        <tr>

                                            <td>
                                                <?= (int)$visit['visit_id'] ?>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $visit['patient_number']
                                                ) ?>
                                            </td>

                                            <td>
                                                <strong>
                                                    <?= htmlspecialchars(
                                                        $visit['patient_name']
                                                    ) ?>
                                                </strong>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $visit['visit_number'] ?? ''
                                                ) ?>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $visit['visit_date']
                                                ) ?>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $visit['visit_type'] ?? ''
                                                ) ?>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $visit['department'] ?? ''
                                                ) ?>
                                            </td>

                                            <td>

                                                <?php
                                                $status = $visit['status'] ?? '';

                                                $badge = 'secondary';

                                                if ($status === 'Registered') {
                                                    $badge = 'primary';
                                                } elseif ($status === 'Triage') {
                                                    $badge = 'warning';
                                                } elseif ($status === 'Consultation') {
                                                    $badge = 'info';
                                                } elseif ($status === 'Laboratory') {
                                                    $badge = 'dark';
                                                } elseif ($status === 'Pharmacy') {
                                                    $badge = 'success';
                                                } elseif ($status === 'Billing') {
                                                    $badge = 'warning';
                                                } elseif ($status === 'Completed') {
                                                    $badge = 'success';
                                                }
                                                ?>

                                                <span class="badge bg-<?= $badge ?>">
                                                    <?= htmlspecialchars($status) ?>
                                                </span>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                    </tbody>

                                </table>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

    </div>
</div>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>