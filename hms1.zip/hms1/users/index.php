<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

require_role('Administrator');

$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';


/*
|--------------------------------------------------------------------------
| Get Users
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        user_id,
        username,
        full_name,
        role,
        phone,
        email,
        status,
        created_at
    FROM users
    ORDER BY user_id DESC
");

$users = $stmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Count Users
|--------------------------------------------------------------------------
*/

$total_users = (int)$pdo
    ->query("SELECT COUNT(*) FROM users")
    ->fetchColumn();

$active_users = (int)$pdo
    ->query("
        SELECT COUNT(*)
        FROM users
        WHERE status = 'Active'
    ")
    ->fetchColumn();

$inactive_users = (int)$pdo
    ->query("
        SELECT COUNT(*)
        FROM users
        WHERE status <> 'Active'
    ")
    ->fetchColumn();

?>

<!DOCTYPE html>
<html lang="en">

<head>
<?php if ($success): ?>

    <div class="alert alert-success alert-dismissible fade show">

        <?= htmlspecialchars($success) ?>

        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="alert"
        ></button>

    </div>

<?php endif; ?>


<?php if ($error): ?>

    <div class="alert alert-danger alert-dismissible fade show">

        <?= htmlspecialchars($error) ?>

        <button
            type="button"
            class="btn-close"
            data-bs-dismiss="alert"
        ></button>

    </div>

<?php endif; ?>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>User Management</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f5f7fb;
        }

        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.06);
        }

        .stat-number {
            font-size: 28px;
            font-weight: 700;
        }

    </style>

</head>

<body>

<nav class="navbar navbar-dark bg-primary">

    <div class="container-fluid">

        <span class="navbar-brand">
            Hospital Management System
        </span>

        <div class="text-white">

            <?= htmlspecialchars(
                get_current_user_name()
            ) ?>

            |

            Administrator

            <a
                href="../auth/logout.php"
                class="btn btn-light btn-sm ms-2"
            >
                Logout
            </a>

        </div>

    </div>

</nav>


<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2>
                User Management
            </h2>

            <p class="text-muted mb-0">
                Register and manage HMS system users
            </p>

        </div>

        <div>

            <a
                href="create.php"
                class="btn btn-success"
            >
                + Register New User
            </a>

            <a
                href="../dashboard.php"
                class="btn btn-secondary"
            >
                Dashboard
            </a>

        </div>

    </div>


    <!-- Statistics -->

    <div class="row g-3 mb-4">

        <div class="col-md-4">

            <div class="card">

                <div class="card-body">

                    <div class="text-muted">
                        Total Users
                    </div>

                    <div class="stat-number">
                        <?= number_format($total_users) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card">

                <div class="card-body">

                    <div class="text-muted">
                        Active Users
                    </div>

                    <div class="stat-number text-success">
                        <?= number_format($active_users) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card">

                <div class="card-body">

                    <div class="text-muted">
                        Inactive/Suspended
                    </div>

                    <div class="stat-number text-danger">
                        <?= number_format($inactive_users) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- Users Table -->

    <div class="card">

        <div class="card-header bg-white">

            <strong>
                Registered System Users
            </strong>

        </div>

        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover mb-0">

                    <thead class="table-dark">

                        <tr>

                            <th>#</th>

                            <th>Name</th>

                            <th>Username</th>

                            <th>Role</th>

                            <th>Phone</th>

                            <th>Email</th>

                            <th>Status</th>

                            <th>Registered</th>

                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (!$users): ?>

                        <tr>

                            <td
                                colspan="9"
                                class="text-center py-5 text-muted"
                            >
                                No users registered.
                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($users as $index => $user): ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>

                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            $user['full_name']
                                        ) ?>
                                    </strong>

                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $user['username']
                                    ) ?>
                                </td>

                                <td>

                                    <?php

                                    $roleClass = 'bg-secondary';

                                    switch ($user['role']) {

                                        case 'Administrator':
                                            $roleClass = 'bg-danger';
                                            break;

                                        case 'Clinician':
                                            $roleClass = 'bg-primary';
                                            break;

                                        case 'Nurse':
                                            $roleClass = 'bg-info text-dark';
                                            break;

                                        case 'Laboratory':
                                            $roleClass = 'bg-warning text-dark';
                                            break;

                                        case 'Pharmacist':
                                            $roleClass = 'bg-success';
                                            break;

                                        case 'Cashier':
                                            $roleClass = 'bg-dark';
                                            break;

                                        case 'Receptionist':
                                            $roleClass = 'bg-secondary';
                                            break;

                                        case 'Records Officer':
                                            $roleClass = 'bg-primary';
                                            break;
                                    }

                                    ?>

                                    <span
                                        class="badge <?= $roleClass ?>"
                                    >
                                        <?= htmlspecialchars(
                                            $user['role']
                                        ) ?>
                                    </span>

                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $user['phone'] ?? ''
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $user['email'] ?? ''
                                    ) ?>
                                </td>

                                <td>

                                    <?php if (
                                        $user['status'] === 'Active'
                                    ): ?>

                                        <span class="badge bg-success">
                                            Active
                                        </span>

                                    <?php elseif (
                                        $user['status'] === 'Suspended'
                                    ): ?>

                                        <span class="badge bg-warning text-dark">
                                            Suspended
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-danger">
                                            Inactive
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?= date(
                                        'd M Y',
                                        strtotime(
                                            $user['created_at']
                                        )
                                    ) ?>

                                </td>

                                <td>

                                    <div class="btn-group">

                                        <a
                                            href="edit.php?user_id=<?= (int)$user['user_id'] ?>"
                                            class="btn btn-sm btn-outline-primary"
                                        >
                                            Edit
                                        </a>

                                        <a
                                            href="reset_password.php?user_id=<?= (int)$user['user_id'] ?>"
                                            class="btn btn-sm btn-outline-warning"
                                        >
                                            Reset Password
                                        </a>

                                        <?php if (
                                            (int)$user['user_id']
                                            !==
                                            (int)get_current_user_id()
                                        ): ?>

                                            <a
                                                href="toggle_status.php?user_id=<?= (int)$user['user_id'] ?>"
                                                class="btn btn-sm btn-outline-danger"
                                                onclick="return confirm('Change this user account status?');"
                                            >
                                                Status
                                            </a>

                                        <?php endif; ?>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

</body>
</html>