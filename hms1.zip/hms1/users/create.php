<?php
require_once "../includes/db.php";
require_once "../includes/auth.php";

require_role('Administrator');

// Get active roles from database
$stmt = $pdo->query("
    SELECT role_id, role_name, description
    FROM roles
    WHERE status = 'Active'
    ORDER BY role_name ASC
");

$roles = $stmt->fetchAll();

$user_name = get_current_user_name();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create User - Hospital Management System</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>
        body {
            background: #f4f6f9;
        }

        .page-card {
            max-width: 900px;
            margin: 30px auto;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .card-header {
            border-radius: 12px 12px 0 0 !important;
        }

        .required {
            color: red;
        }

        .password-wrapper {
            position: relative;
        }

        .password-wrapper input {
            padding-right: 50px;
        }

        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            border: none;
            background: transparent;
            cursor: pointer;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="card page-card">

        <div class="card-header bg-primary text-white p-4">

            <div class="d-flex justify-content-between align-items-center">

                <div>
                    <h4 class="mb-1">
                        Create System User
                    </h4>

                    <small>
                        Register a new staff member and assign their system role
                    </small>
                </div>

                <div>
                    <a
                        href="index.php"
                        class="btn btn-light btn-sm"
                    >
                        ← User List
                    </a>
                </div>

            </div>

        </div>


        <div class="card-body p-4">

            <form
                method="POST"
                action="save.php"
                autocomplete="off"
            >

                <!-- CSRF -->
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars(csrf_token()) ?>"
                >


                <!-- PERSONAL DETAILS -->
                <h5 class="mb-3 text-primary">
                    Personal Details
                </h5>

                <div class="row g-3">

                    <!-- FULL NAME -->
                    <div class="col-md-12">

                        <label class="form-label">
                            Full Name
                            <span class="required">*</span>
                        </label>

                        <input
                            type="text"
                            name="full_name"
                            class="form-control"
                            placeholder="Enter staff member's full name"
                            maxlength="200"
                            required
                        >

                    </div>


                    <!-- PHONE -->
                    <div class="col-md-6">

                        <label class="form-label">
                            Phone Number
                        </label>

                        <input
                            type="tel"
                            name="phone"
                            class="form-control"
                            placeholder="e.g. 0712345678"
                            maxlength="30"
                        >

                    </div>


                    <!-- EMAIL -->
                    <div class="col-md-6">

                        <label class="form-label">
                            Email Address
                        </label>

                        <input
                            type="email"
                            name="email"
                            class="form-control"
                            placeholder="e.g. staff@hospital.com"
                            maxlength="150"
                        >

                    </div>

                </div>


                <hr class="my-4">


                <!-- LOGIN DETAILS -->
                <h5 class="mb-3 text-primary">
                    Login Details
                </h5>

                <div class="row g-3">

                    <!-- USERNAME -->
                    <div class="col-md-6">

                        <label class="form-label">
                            Username
                            <span class="required">*</span>
                        </label>

                        <input
                            type="text"
                            name="username"
                            class="form-control"
                            placeholder="Enter username"
                            maxlength="100"
                            autocomplete="off"
                            required
                        >

                        <small class="text-muted">
                            This will be used when logging into the system.
                        </small>

                    </div>


                    <!-- ROLE -->
                    <div class="col-md-6">

                        <label class="form-label">
                            System Role
                            <span class="required">*</span>
                        </label>

                        <select
                            name="role"
                            id="role"
                            class="form-select"
                            required
                        >

                            <option value="">
                                -- Select User Role --
                            </option>

                            <?php foreach ($roles as $role): ?>

                                <option
                                    value="<?= htmlspecialchars($role['role_name']) ?>"
                                >
                                    <?= htmlspecialchars($role['role_name']) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- PASSWORD -->
                    <div class="col-md-6">

                        <label class="form-label">
                            Password
                            <span class="required">*</span>
                        </label>

                        <div class="password-wrapper">

                            <input
                                type="password"
                                name="password"
                                id="password"
                                class="form-control"
                                minlength="8"
                                autocomplete="new-password"
                                placeholder="Enter password"
                                required
                            >

                            <button
                                type="button"
                                class="password-toggle"
                                onclick="togglePassword('password', this)"
                            >
                                👁
                            </button>

                        </div>

                        <small class="text-muted">
                            Minimum 8 characters.
                        </small>

                    </div>


                    <!-- CONFIRM PASSWORD -->
                    <div class="col-md-6">

                        <label class="form-label">
                            Confirm Password
                            <span class="required">*</span>
                        </label>

                        <div class="password-wrapper">

                            <input
                                type="password"
                                name="confirm_password"
                                id="confirm_password"
                                class="form-control"
                                minlength="8"
                                autocomplete="new-password"
                                placeholder="Confirm password"
                                required
                            >

                            <button
                                type="button"
                                class="password-toggle"
                                onclick="togglePassword('confirm_password', this)"
                            >
                                👁
                            </button>

                        </div>

                        <div id="passwordMessage" class="small mt-1"></div>

                    </div>


                    <!-- STATUS -->
                    <div class="col-md-6">

                        <label class="form-label">
                            Account Status
                            <span class="required">*</span>
                        </label>

                        <select
                            name="status"
                            class="form-select"
                            required
                        >

                            <option value="Active" selected>
                                Active
                            </option>

                            <option value="Inactive">
                                Inactive
                            </option>

                            <option value="Suspended">
                                Suspended
                            </option>

                        </select>

                    </div>

                </div>


                <hr class="my-4">


                <!-- ROLE INFORMATION -->
                <div
                    id="roleDescription"
                    class="alert alert-info"
                >
                    <strong>Role:</strong>
                    Select a role to view its description.
                </div>


                <!-- BUTTONS -->
                <div class="d-flex justify-content-between mt-4">

                    <a
                        href="index.php"
                        class="btn btn-secondary"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        id="saveButton"
                        class="btn btn-primary px-4"
                    >
                        Create User
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<script>

function togglePassword(fieldId, button) {

    const field = document.getElementById(fieldId);

    if (field.type === "password") {

        field.type = "text";
        button.innerHTML = "🙈";

    } else {

        field.type = "password";
        button.innerHTML = "👁";

    }
}


// Password confirmation
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirm_password");
const passwordMessage = document.getElementById("passwordMessage");
const saveButton = document.getElementById("saveButton");

function checkPasswords() {

    if (confirmPassword.value === "") {

        passwordMessage.innerHTML = "";
        saveButton.disabled = false;
        return;

    }

    if (password.value === confirmPassword.value) {

        passwordMessage.innerHTML =
            '<span class="text-success">✓ Passwords match</span>';

        saveButton.disabled = false;

    } else {

        passwordMessage.innerHTML =
            '<span class="text-danger">✗ Passwords do not match</span>';

        saveButton.disabled = true;

    }
}

password.addEventListener("input", checkPasswords);
confirmPassword.addEventListener("input", checkPasswords);


// Role descriptions
const roleDescriptions = <?= json_encode(
    array_column($roles, 'description', 'role_name')
) ?>;

const roleSelect = document.getElementById("role");
const roleDescription = document.getElementById("roleDescription");

roleSelect.addEventListener("change", function() {

    const selectedRole = this.value;

    if (selectedRole && roleDescriptions[selectedRole]) {

        roleDescription.innerHTML =
            "<strong>" +
            selectedRole +
            ":</strong> " +
            roleDescriptions[selectedRole];

    } else if (selectedRole) {

        roleDescription.innerHTML =
            "<strong>Role:</strong> " +
            selectedRole;

    } else {

        roleDescription.innerHTML =
            "<strong>Role:</strong> Select a role to view its description.";

    }

});

</script>

</body>
</html>