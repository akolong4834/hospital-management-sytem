<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

require_role('Administrator');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: create.php");
    exit();
}


// --------------------------------------------------
// CSRF CHECK
// --------------------------------------------------

$csrf_token = $_POST['csrf_token'] ?? '';

if (!verify_csrf_token($csrf_token)) {

    die("
        <div style='font-family:Arial;padding:40px;text-align:center;'>
            <h2>Invalid Request</h2>
            <p>Your security token is invalid or expired.</p>
            <a href='create.php'>Return to Create User</a>
        </div>
    ");

}


// --------------------------------------------------
// GET FORM DATA
// --------------------------------------------------

$full_name = trim($_POST['full_name'] ?? '');
$username = trim($_POST['username'] ?? '');
$role = trim($_POST['role'] ?? '');

$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');

$password = $_POST['password_hash'] ?? '';


$status = trim($_POST['status'] ?? 'Active');


// --------------------------------------------------
// VALIDATION
// --------------------------------------------------

$errors = [];


// Full name
if ($full_name === '') {

    $errors[] = "Full name is required.";

} elseif (strlen($full_name) < 3) {

    $errors[] = "Full name must contain at least 3 characters.";

}


// Username
if ($username === '') {

    $errors[] = "Username is required.";

} elseif (!preg_match('/^[A-Za-z0-9._-]{3,100}$/', $username)) {

    $errors[] =
        "Username may contain letters, numbers, dots, underscores and hyphens only.";

}


// Password
if ($password === '') {

    $errors[] = "Password is required.";

} elseif (strlen($password) < 8) {

    $errors[] = "Password must contain at least 8 characters.";

}


// Confirm password
if ($password !== $confirm_password) {

    $errors[] = "Passwords do not match.";

}


// Email
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {

    $errors[] = "Please enter a valid email address.";

}


// Status
$allowed_statuses = [
    'Active',
    'Inactive',
    'Suspended'
];

if (!in_array($status, $allowed_statuses, true)) {

    $errors[] = "Invalid account status.";

}


// --------------------------------------------------
// CHECK ROLE
// --------------------------------------------------

$stmt = $pdo->prepare("
    SELECT role_id
    FROM roles
    WHERE role_name = ?
    AND status = 'Active'
    LIMIT 1
");

$stmt->execute([$role]);

$role_exists = $stmt->fetch();

if (!$role_exists) {

    $errors[] = "The selected role does not exist or is inactive.";

}


// --------------------------------------------------
// CHECK USERNAME
// --------------------------------------------------

$stmt = $pdo->prepare("
    SELECT user_id
    FROM users
    WHERE username = ?
    LIMIT 1
");

$stmt->execute([$username]);

if ($stmt->fetch()) {

    $errors[] =
        "The username '" .
        htmlspecialchars($username) .
        "' is already registered.";

}


// --------------------------------------------------
// SHOW ERRORS
// --------------------------------------------------

if (!empty($errors)) {

    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>

        <meta charset="UTF-8">

        <meta
            name="viewport"
            content="width=device-width, initial-scale=1.0"
        >

        <title>Create User - Error</title>

        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet"
        >

    </head>

    <body class="bg-light">

    <div class="container">

        <div class="card shadow-sm mt-5">

            <div class="card-header bg-danger text-white">

                <h4 class="mb-0">
                    Unable to Create User
                </h4>

            </div>

            <div class="card-body">

                <div class="alert alert-danger">

                    <ul class="mb-0">

                        <?php foreach ($errors as $error): ?>

                            <li>
                                <?= htmlspecialchars($error) ?>
                            </li>

                        <?php endforeach; ?>

                    </ul>

                </div>

                <a
                    href="create.php"
                    class="btn btn-primary"
                >
                    ← Return to Create User
                </a>

            </div>

        </div>

    </div>

    </body>
    </html>

    <?php

    exit();
}


// --------------------------------------------------
// HASH PASSWORD
// --------------------------------------------------

$password_hash = password_hash(
    $password,
    PASSWORD_DEFAULT
);


// --------------------------------------------------
// INSERT USER
// --------------------------------------------------

try {

    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        INSERT INTO users (
            username,
            password_hash,
            full_name,
            role,
            phone,
            email,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $username,
        $password_hash,
        $full_name,
        $role,
        $phone !== '' ? $phone : null,
        $email !== '' ? $email : null,
        $status
    ]);

    $user_id = $pdo->lastInsertId();

    $pdo->commit();

    header(
        "Location: index.php?success=" .
        urlencode(
            "User '$full_name' was created successfully."
        )
    );

    exit();

} catch (PDOException $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    die("
        <div style='font-family:Arial;padding:40px;'>
            <h2>Database Error</h2>
            <p>Unable to create the user.</p>
            <p>
                " . htmlspecialchars($e->getMessage()) . "
            </p>
            <a href='create.php'>Return</a>
        </div>
    ");
}
?>