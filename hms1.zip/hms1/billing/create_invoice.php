<?php
$title='Create Patient Bill';
require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$visitId=(int)($_GET['visit_id']??0);
$s=$pdo->prepare("SELECT v.*,p.id patient_id,p.patient_no,CONCAT_WS(' ',p.first_name,p.middle_name,p.last_name) patient_name FROM patient_visits v JOIN patients p ON p.id=v.patient_id WHERE v.id=?");$s->execute([$visitId]);$v=$s->fetch();if(!$v)exit('Visit not found.');
$items=[];
$items[]=['Registration',null,'Registration',100];
$items[]=['Consultation',null,'Consultation',500];
$l=$pdo->prepare("SELECT loi.id,lt.test_name,loi.price FROM lab_order_items loi JOIN lab_orders lo ON lo.id=loi.lab_order_id JOIN lab_tests lt ON lt.id=loi.lab_test_id WHERE lo.visit_id=?");$l->execute([$visitId]);foreach($l as $x)$items[]=['Laboratory',$x['id'],$x['test_name'],(float)$x['price']];
$r=$pdo->prepare("SELECT pi.id,m.medicine_name,pi.quantity_dispensed,pi.price FROM prescription_items pi JOIN prescriptions rx ON rx.id=pi.prescription_id JOIN medicines m ON m.id=pi.medicine_id WHERE rx.visit_id=? AND pi.quantity_dispensed>0");$r->execute([$visitId]);foreach($r as $x)$items[]=['Pharmacy',$x['id'],$x['medicine_name'].' x'.$x['quantity_dispensed'],(float)$x['price']*(int)$x['quantity_dispensed'];
?>
<div class="card p-4"><h5><?=htmlspecialchars($v['patient_name'])?> — <?=$v['patient_no']?></h5><form method="post" action="save_invoice.php"><input type="hidden" name="visit_id" value="<?=$visitId?>">
<table class="table"><tr><th>Service</th><th>Description</th><th>Amount</th></tr><?php foreach($items as $i):?><tr><td><?=$i[0]?></td><td><?=htmlspecialchars($i[2])?></td><td>KSh <?=number_format($i[3],2)?><input type="hidden" name="service_type[]" value="<?=$i[0]?>"><input type="hidden" name="reference_id[]" value="<?=$i[1]??''?>"><input type="hidden" name="description[]" value="<?=htmlspecialchars($i[2],ENT_QUOTES)?>"><input type="hidden" name="amount[]" value="<?=$i[3]?>"></td></tr><?php endforeach;?></table>
<div class="col-md-4"><label class="form-label">Discount</label><input class="form-control" type="number" step="0.01" min="0" name="discount" value="0"></div>
<button class="btn btn-primary mt-3">Generate Invoice</button></form></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>