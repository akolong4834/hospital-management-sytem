<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$bill_id = isset($_GET['bill_id'])
    ? (int) $_GET['bill_id']
    : 0;

if ($bill_id <= 0) {
    die("Invalid bill ID.");
}


/*
|--------------------------------------------------------------------------
| Get Bill + Patient + Visit
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        b.bill_id,
        b.bill_number,
        b.subtotal,
        b.discount,
        b.total_amount,
        b.amount_paid,
        b.balance,
        b.bill_status,
        b.created_at,

        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.payment_category,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,
        p.id_number

    FROM bills b

    INNER JOIN patient_visits v
        ON b.visit_id = v.visit_id

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    WHERE b.bill_id = ?

    LIMIT 1
");

$stmt->execute([$bill_id]);

$bill = $stmt->fetch();

if (!$bill) {
    die("Bill not found.");
}


/*
|--------------------------------------------------------------------------
| Get Bill Items
|--------------------------------------------------------------------------
*/

$itemStmt = $pdo->prepare("
    SELECT
        bill_item_id,
        item_type,
        description,
        reference_id,
        quantity,
        unit_price,
        total_price

    FROM bill_items

    WHERE bill_id = ?

    ORDER BY
        CASE item_type
            WHEN 'Consultation' THEN 1
            WHEN 'Laboratory' THEN 2
            WHEN 'Medicine' THEN 3
            WHEN 'Procedure' THEN 4
            WHEN 'Other' THEN 5
            ELSE 6
        END,
        bill_item_id ASC
");

$itemStmt->execute([$bill_id]);

$items = $itemStmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Group Items
|--------------------------------------------------------------------------
*/

$groupedItems = [
    'Consultation' => [],
    'Laboratory'   => [],
    'Medicine'     => [],
    'Procedure'    => [],
    'Other'        => []
];

foreach ($items as $item) {

    $type = $item['item_type'];

    if (isset($groupedItems[$type])) {

        $groupedItems[$type][] = $item;

    } else {

        $groupedItems['Other'][] = $item;

    }
}


/*
|--------------------------------------------------------------------------
| Get Payments
|--------------------------------------------------------------------------
*/

$paymentStmt = $pdo->prepare("
    SELECT
        payment_id,
        receipt_number,
        payment_method,
        amount,
        transaction_reference,
        payment_date

    FROM payments

    WHERE bill_id = ?

    ORDER BY payment_id DESC
");

$paymentStmt->execute([$bill_id]);

$payments = $paymentStmt->fetchAll();

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Invoice <?= htmlspecialchars($bill['bill_number']) ?>
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f4f6f9;
        }

        .invoice-container {
            max-width: 1100px;
            margin: 30px auto;
        }

        .invoice-card {
            background: #fff;
            border-radius: 8px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }

        .hospital-name {
            font-size: 28px;
            font-weight: 700;
        }

        .invoice-title {
            font-size: 32px;
            font-weight: 700;
            letter-spacing: 1px;
        }

        .summary-box {
            border: 1px solid #dee2e6;
            border-radius: 6px;
            padding: 15px;
        }

        .total-box {
            background: #f8f9fa;
            border-radius: 6px;
            padding: 20px;
        }

        @media print {

            body {
                background: white;
            }

            .no-print {
                display: none !important;
            }

            .invoice-container {
                margin: 0;
                max-width: 100%;
            }

            .invoice-card {
                box-shadow: none;
                padding: 10px;
            }

        }

    </style>

</head>


<body>


<div class="invoice-container">


    <!-- Action buttons -->

    <div class="d-flex justify-content-between mb-3 no-print">

        <a
            href="index.php"
            class="btn btn-secondary"
        >
            ← Billing Queue
        </a>


        <div class="d-flex gap-2">

            <button
                onclick="window.print()"
                class="btn btn-dark"
            >
                🖨 Print Invoice
            </button>


            <?php if ($bill['bill_status'] !== 'Paid'): ?>

                <a
                    href="payment.php?bill_id=<?= $bill_id ?>"
                    class="btn btn-success"
                >
                    💳 Proceed to Payment
                </a>

            <?php else: ?>

                <a
                    href="receipt.php?bill_id=<?= $bill_id ?>"
                    class="btn btn-success"
                >
                    🧾 View Receipt
                </a>

            <?php endif; ?>

        </div>

    </div>


    <div class="invoice-card">


        <!-- Header -->

        <div class="row mb-4">


            <div class="col-md-7">

                <div class="hospital-name">
                    HOSPITAL MANAGEMENT SYSTEM
                </div>

                <div class="text-muted">
                    Patient Billing &amp; Finance Department
                </div>

                <div class="mt-2">

                    <strong>Hospital</strong><br>

                    Hospital Management System<br>

                    Kenya

                </div>

            </div>


            <div class="col-md-5 text-md-end">

                <div class="invoice-title">
                    INVOICE
                </div>

                <div class="mt-2">

                    <strong>Invoice No:</strong>

                    <?= htmlspecialchars(
                        $bill['bill_number']
                    ) ?>

                </div>

                <div>

                    <strong>Date:</strong>

                    <?= date(
                        'd M Y H:i',
                        strtotime($bill['created_at'])
                    ) ?>

                </div>


                <div class="mt-2">

                    <?php

                    $statusClass = 'secondary';

                    if ($bill['bill_status'] === 'Unpaid') {
                        $statusClass = 'danger';
                    }

                    if ($bill['bill_status'] === 'Partially Paid') {
                        $statusClass = 'warning';
                    }

                    if ($bill['bill_status'] === 'Paid') {
                        $statusClass = 'success';
                    }

                    if ($bill['bill_status'] === 'Cancelled') {
                        $statusClass = 'dark';
                    }

                    ?>

                    <span
                        class="badge bg-<?= $statusClass ?>"
                    >

                        <?= htmlspecialchars(
                            $bill['bill_status']
                        ) ?>

                    </span>

                </div>

            </div>

        </div>


        <hr>


        <!-- Patient information -->

        <div class="row mb-4">


            <div class="col-md-6">

                <div class="summary-box">

                    <h6 class="text-primary">
                        BILL TO
                    </h6>

                    <h5>

                        <?= htmlspecialchars(
                            trim(
                                $bill['first_name']
                                . ' '
                                . $bill['middle_name']
                                . ' '
                                . $bill['last_name']
                            )
                        ) ?>

                    </h5>

                    <div>

                        <strong>Patient No:</strong>

                        <?= htmlspecialchars(
                            $bill['patient_number']
                        ) ?>

                    </div>

                    <div>

                        <strong>Gender:</strong>

                        <?= htmlspecialchars(
                            $bill['gender']
                        ) ?>

                    </div>

                    <div>

                        <strong>Phone:</strong>

                        <?= htmlspecialchars(
                            $bill['phone']
                        ) ?>

                    </div>

                    <?php if (!empty($bill['id_number'])): ?>

                        <div>

                            <strong>ID No:</strong>

                            <?= htmlspecialchars(
                                $bill['id_number']
                            ) ?>

                        </div>

                    <?php endif; ?>

                </div>

            </div>


            <div class="col-md-6">

                <div class="summary-box">

                    <h6 class="text-primary">
                        VISIT INFORMATION
                    </h6>

                    <div>

                        <strong>Visit No:</strong>

                        <?= htmlspecialchars(
                            $bill['visit_number']
                        ) ?>

                    </div>

                    <div>

                        <strong>Visit Date:</strong>

                        <?= htmlspecialchars(
                            $bill['visit_date']
                        ) ?>

                    </div>

                    <div>

                        <strong>Visit Type:</strong>

                        <?= htmlspecialchars(
                            $bill['visit_type']
                        ) ?>

                    </div>

                    <div>

                        <strong>Payment Category:</strong>

                        <?= htmlspecialchars(
                            $bill['payment_category']
                        ) ?>

                    </div>

                </div>

            </div>

        </div>


        <!-- Bill items -->

        <h5 class="mb-3">
            Bill Details
        </h5>


        <div class="table-responsive">

            <table class="table table-bordered align-middle">

                <thead class="table-dark">

                <tr>

                    <th style="width: 5%;">
                        #
                    </th>

                    <th style="width: 15%;">
                        Service
                    </th>

                    <th>
                        Description
                    </th>

                    <th style="width: 10%;">
                        Qty
                    </th>

                    <th style="width: 15%;">
                        Unit Price
                    </th>

                    <th style="width: 15%;">
                        Total
                    </th>

                </tr>

                </thead>


                <tbody>


                <?php

                $counter = 1;

                ?>


                <!-- Consultation -->

                <?php foreach (
                    $groupedItems['Consultation']
                    as $item
                ): ?>

                    <tr>

                        <td>
                            <?= $counter++ ?>
                        </td>

                        <td>
                            <span class="badge bg-primary">
                                Consultation
                            </span>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $item['description']
                            ) ?>
                        </td>

                        <td>
                            <?= (int) $item['quantity'] ?>
                        </td>

                        <td>

                            KSh
                            <?= number_format(
                                $item['unit_price'],
                                2
                            ) ?>

                        </td>

                        <td>

                            <strong>

                                KSh
                                <?= number_format(
                                    $item['total_price'],
                                    2
                                ) ?>

                            </strong>

                        </td>

                    </tr>

                <?php endforeach; ?>


                <!-- Laboratory -->

                <?php foreach (
                    $groupedItems['Laboratory']
                    as $item
                ): ?>

                    <tr>

                        <td>
                            <?= $counter++ ?>
                        </td>

                        <td>
                            <span class="badge bg-info text-dark">
                                Laboratory
                            </span>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $item['description']
                            ) ?>
                        </td>

                        <td>
                            <?= (int) $item['quantity'] ?>
                        </td>

                        <td>

                            KSh
                            <?= number_format(
                                $item['unit_price'],
                                2
                            ) ?>

                        </td>

                        <td>

                            <strong>

                                KSh
                                <?= number_format(
                                    $item['total_price'],
                                    2
                                ) ?>

                            </strong>

                        </td>

                    </tr>

                <?php endforeach; ?>


                <!-- Medicines -->

                <?php foreach (
                    $groupedItems['Medicine']
                    as $item
                ): ?>

                    <tr>

                        <td>
                            <?= $counter++ ?>
                        </td>

                        <td>
                            <span class="badge bg-success">
                                Medicine
                            </span>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $item['description']
                            ) ?>
                        </td>

                        <td>
                            <?= (int) $item['quantity'] ?>
                        </td>

                        <td>

                            KSh
                            <?= number_format(
                                $item['unit_price'],
                                2
                            ) ?>

                        </td>

                        <td>

                            <strong>

                                KSh
                                <?= number_format(
                                    $item['total_price'],
                                    2
                                ) ?>

                            </strong>

                        </td>

                    </tr>

                <?php endforeach; ?>


                <!-- Procedures -->

                <?php foreach (
                    $groupedItems['Procedure']
                    as $item
                ): ?>

                    <tr>

                        <td>
                            <?= $counter++ ?>
                        </td>

                        <td>
                            <span class="badge bg-warning text-dark">
                                Procedure
                            </span>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $item['description']
                            ) ?>
                        </td>

                        <td>
                            <?= (int) $item['quantity'] ?>
                        </td>

                        <td>

                            KSh
                            <?= number_format(
                                $item['unit_price'],
                                2
                            ) ?>

                        </td>

                        <td>

                            <strong>

                                KSh
                                <?= number_format(
                                    $item['total_price'],
                                    2
                                ) ?>

                            </strong>

                        </td>

                    </tr>

                <?php endforeach; ?>


                <!-- Other -->

                <?php foreach (
                    $groupedItems['Other']
                    as $item
                ): ?>

                    <tr>

                        <td>
                            <?= $counter++ ?>
                        </td>

                        <td>
                            <span class="badge bg-secondary">
                                Other
                            </span>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $item['description']
                            ) ?>
                        </td>

                        <td>
                            <?= (int) $item['quantity'] ?>
                        </td>

                        <td>

                            KSh
                            <?= number_format(
                                $item['unit_price'],
                                2
                            ) ?>

                        </td>

                        <td>

                            <strong>

                                KSh
                                <?= number_format(
                                    $item['total_price'],
                                    2
                                ) ?>

                            </strong>

                        </td>

                    </tr>

                <?php endforeach; ?>


                <?php if (empty($items)): ?>

                    <tr>

                        <td
                            colspan="6"
                            class="text-center text-muted"
                        >

                            No bill items found.

                        </td>

                    </tr>

                <?php endif; ?>


                </tbody>

            </table>

        </div>


        <!-- Totals -->

        <div class="row justify-content-end mt-4">


            <div class="col-md-5">


                <div class="total-box">


                    <div class="d-flex justify-content-between mb-2">

                        <span>
                            Subtotal:
                        </span>

                        <strong>

                            KSh
                            <?= number_format(
                                $bill['subtotal'],
                                2
                            ) ?>

                        </strong>

                    </div>


                    <div class="d-flex justify-content-between mb-2">

                        <span>
                            Discount:
                        </span>

                        <strong>

                            KSh
                            <?= number_format(
                                $bill['discount'],
                                2
                            ) ?>

                        </strong>

                    </div>


                    <hr>


                    <div class="d-flex justify-content-between mb-2">

                        <strong class="fs-5">
                            Total:
                        </strong>

                        <strong class="fs-5 text-primary">

                            KSh
                            <?= number_format(
                                $bill['total_amount'],
                                2
                            ) ?>

                        </strong>

                    </div>


                    <div class="d-flex justify-content-between mb-2">

                        <span>
                            Amount Paid:
                        </span>

                        <strong class="text-success">

                            KSh
                            <?= number_format(
                                $bill['amount_paid'],
                                2
                            ) ?>

                        </strong>

                    </div>


                    <div class="d-flex justify-content-between">

                        <strong>
                            Balance:
                        </strong>

                        <strong class="text-danger">

                            KSh
                            <?= number_format(
                                $bill['balance'],
                                2
                            ) ?>

                        </strong>

                    </div>


                </div>

            </div>

        </div>


        <!-- Payment history -->

        <?php if (!empty($payments)): ?>

            <div class="mt-5">

                <h5>
                    Payment History
                </h5>


                <div class="table-responsive">

                    <table class="table table-bordered">

                        <thead class="table-light">

                        <tr>

                            <th>
                                Receipt
                            </th>

                            <th>
                                Method
                            </th>

                            <th>
                                Amount
                            </th>

                            <th>
                                Reference
                            </th>

                            <th>
                                Date
                            </th>

                        </tr>

                        </thead>


                        <tbody>

                        <?php foreach (
                            $payments
                            as $payment
                        ): ?>

                            <tr>

                                <td>

                                    <?= htmlspecialchars(
                                        $payment['receipt_number']
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $payment['payment_method']
                                    ) ?>

                                </td>

                                <td>

                                    KSh
                                    <?= number_format(
                                        $payment['amount'],
                                        2
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $payment[
                                            'transaction_reference'
                                        ] ?: '-'
                                    ) ?>

                                </td>

                                <td>

                                    <?= date(
                                        'd M Y H:i',
                                        strtotime(
                                            $payment[
                                                'payment_date'
                                            ]
                                        )
                                    ) ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        <?php endif; ?>


        <!-- Footer -->

        <div class="mt-5 pt-4 border-top text-center text-muted">

            <p class="mb-1">
                Thank you for choosing our healthcare services.
            </p>

            <small>
                This is a computer-generated invoice.
            </small>

        </div>


    </div>

</div>


</body>

</html>