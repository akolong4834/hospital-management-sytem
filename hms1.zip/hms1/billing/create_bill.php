<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$visit_id = isset($_GET['visit_id'])
    ? (int) $_GET['visit_id']
    : 0;

if ($visit_id <= 0) {
    die("Invalid visit ID.");
}


/*
|--------------------------------------------------------------------------
| Get patient and visit information
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.payment_category,
        v.status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,
        p.id_number,

        c.diagnosis,
        c.treatment_plan

    FROM patient_visits v

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    LEFT JOIN consultations c
        ON v.visit_id = c.visit_id

    WHERE v.visit_id = ?

    LIMIT 1
");

$stmt->execute([$visit_id]);

$visit = $stmt->fetch();

if (!$visit) {
    die("Patient visit not found.");
}


/*
|--------------------------------------------------------------------------
| Check whether bill already exists
|--------------------------------------------------------------------------
*/

$billCheck = $pdo->prepare("
    SELECT
        bill_id,
        bill_number,
        bill_status,
        total_amount,
        amount_paid,
        balance

    FROM bills

    WHERE visit_id = ?

    ORDER BY bill_id DESC

    LIMIT 1
");

$billCheck->execute([$visit_id]);

$existingBill = $billCheck->fetch();


/*
|--------------------------------------------------------------------------
| Get dispensed medicines
|--------------------------------------------------------------------------
*/

$medicineStmt = $pdo->prepare("
    SELECT

        pi.prescription_item_id,

        pi.quantity_prescribed,
        pi.quantity_dispensed,

        pi.dosage,
        pi.frequency,
        pi.duration,
        pi.route,

        m.medicine_id,
        m.medicine_name,
        m.medicine_code,
        m.selling_price

    FROM prescription_items pi

    INNER JOIN prescriptions pr
        ON pi.prescription_id = pr.prescription_id

    INNER JOIN medicines m
        ON pi.medicine_id = m.medicine_id

    WHERE pr.visit_id = ?

    AND pi.item_status = 'Dispensed'

    ORDER BY pi.prescription_item_id ASC
");

$medicineStmt->execute([$visit_id]);

$medicines = $medicineStmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Calculate medicine total
|--------------------------------------------------------------------------
*/

$medicineTotal = 0;

foreach ($medicines as $medicine) {

    $quantity = (int) $medicine['quantity_dispensed'];

    $price = (float) $medicine['selling_price'];

    $medicineTotal += $quantity * $price;
}


/*
|--------------------------------------------------------------------------
| Get completed laboratory tests
|--------------------------------------------------------------------------
*/

$labStmt = $pdo->prepare("
    SELECT

        loi.order_item_id,

        loi.test_price,

        loi.item_status,

        lt.test_code,
        lt.test_name

    FROM laboratory_order_items loi

    INNER JOIN laboratory_orders lo
        ON loi.lab_order_id = lo.lab_order_id

    INNER JOIN laboratory_tests lt
        ON loi.test_id = lt.test_id

    WHERE lo.visit_id = ?

    AND loi.item_status = 'Completed'

    ORDER BY loi.order_item_id ASC
");

$labStmt->execute([$visit_id]);

$laboratoryTests = $labStmt->fetchAll();


/*
|--------------------------------------------------------------------------
| Calculate laboratory total
|--------------------------------------------------------------------------
*/

$labTotal = 0;

foreach ($laboratoryTests as $lab) {

    $labTotal += (float) $lab['test_price'];

}


/*
|--------------------------------------------------------------------------
| Consultation charge
|--------------------------------------------------------------------------
|
| We do not assume a consultation price from the database because
| the current consultations schema does not contain a consultation fee.
|
| The user can enter the consultation charge manually.
|--------------------------------------------------------------------------
*/

$defaultConsultationFee = 0;


/*
|--------------------------------------------------------------------------
| Calculate automatic subtotal
|--------------------------------------------------------------------------
*/

$automaticSubtotal =
    $medicineTotal
    + $labTotal
    + $defaultConsultationFee;

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Create Bill - Hospital Management System</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>


<body class="bg-light">


<div class="container-fluid mt-4">


    <!-- Header -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2>
                💰 Create Patient Bill
            </h2>

            <p class="text-muted mb-0">
                Generate invoice for completed services
            </p>

        </div>


        <div>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                ← Billing Queue
            </a>

        </div>

    </div>


    <?php if ($existingBill): ?>

        <div class="alert alert-warning">

            <strong>Existing Bill Found</strong>

            <br>

            Bill Number:
            <strong>
                <?= htmlspecialchars(
                    $existingBill['bill_number']
                ) ?>
            </strong>

            <br>

            Status:
            <?= htmlspecialchars(
                $existingBill['bill_status']
            ) ?>

            <br>

            Total:
            KSh <?= number_format(
                $existingBill['total_amount'],
                2
            ) ?>

            <br>

            Balance:
            KSh <?= number_format(
                $existingBill['balance'],
                2
            ) ?>

            <div class="mt-3">

                <a
                    href="invoice.php?bill_id=<?= (int) $existingBill['bill_id'] ?>"
                    class="btn btn-primary"
                >
                    View Existing Bill
                </a>

            </div>

        </div>

    <?php endif; ?>


    <!-- Patient Information -->

    <div class="card shadow mb-4">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">
                Patient Information
            </h5>

        </div>


        <div class="card-body">

            <div class="row">

                <div class="col-md-3">

                    <strong>Patient Number</strong>

                    <div>
                        <?= htmlspecialchars(
                            $visit['patient_number']
                        ) ?>
                    </div>

                </div>


                <div class="col-md-3">

                    <strong>Patient Name</strong>

                    <div>

                        <?= htmlspecialchars(
                            trim(
                                $visit['first_name']
                                . ' '
                                . $visit['middle_name']
                                . ' '
                                . $visit['last_name']
                            )
                        ) ?>

                    </div>

                </div>


                <div class="col-md-2">

                    <strong>Gender</strong>

                    <div>
                        <?= htmlspecialchars(
                            $visit['gender']
                        ) ?>
                    </div>

                </div>


                <div class="col-md-2">

                    <strong>Phone</strong>

                    <div>
                        <?= htmlspecialchars(
                            $visit['phone']
                        ) ?>
                    </div>

                </div>


                <div class="col-md-2">

                    <strong>Visit Number</strong>

                    <div>
                        <?= htmlspecialchars(
                            $visit['visit_number']
                        ) ?>
                    </div>

                </div>

            </div>


            <hr>


            <div class="row">

                <div class="col-md-3">

                    <strong>Visit Date</strong>

                    <div>
                        <?= htmlspecialchars(
                            $visit['visit_date']
                        ) ?>
                    </div>

                </div>


                <div class="col-md-3">

                    <strong>Visit Type</strong>

                    <div>
                        <?= htmlspecialchars(
                            $visit['visit_type']
                        ) ?>
                    </div>

                </div>


                <div class="col-md-3">

                    <strong>Payment Category</strong>

                    <div>

                        <span class="badge bg-info text-dark">

                            <?= htmlspecialchars(
                                $visit['payment_category']
                            ) ?>

                        </span>

                    </div>

                </div>


                <div class="col-md-3">

                    <strong>Diagnosis</strong>

                    <div>

                        <?= htmlspecialchars(
                            $visit['diagnosis']
                                ?: 'Not recorded'
                        ) ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- Laboratory Services -->

    <div class="card shadow mb-4">

        <div class="card-header bg-info">

            <h5 class="mb-0">
                🧪 Laboratory Services
            </h5>

        </div>


        <div class="card-body">

            <?php if (empty($laboratoryTests)): ?>

                <div class="alert alert-secondary mb-0">

                    No completed laboratory services found.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered">

                        <thead class="table-dark">

                        <tr>

                            <th>#</th>

                            <th>Test Code</th>

                            <th>Test Name</th>

                            <th>Price</th>

                        </tr>

                        </thead>


                        <tbody>

                        <?php foreach (
                            $laboratoryTests
                            as $index => $lab
                        ): ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $lab['test_code']
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $lab['test_name']
                                    ) ?>
                                </td>

                                <td>

                                    KSh
                                    <?= number_format(
                                        $lab['test_price'],
                                        2
                                    ) ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>


                        <tfoot>

                        <tr>

                            <th colspan="3" class="text-end">

                                Laboratory Total:

                            </th>

                            <th>

                                KSh
                                <?= number_format(
                                    $labTotal,
                                    2
                                ) ?>

                            </th>

                        </tr>

                        </tfoot>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- Medicines -->

    <div class="card shadow mb-4">

        <div class="card-header bg-success text-white">

            <h5 class="mb-0">
                💊 Dispensed Medicines
            </h5>

        </div>


        <div class="card-body">

            <?php if (empty($medicines)): ?>

                <div class="alert alert-secondary mb-0">

                    No dispensed medicines found.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered">

                        <thead class="table-dark">

                        <tr>

                            <th>#</th>

                            <th>Medicine</th>

                            <th>Dosage</th>

                            <th>Frequency</th>

                            <th>Duration</th>

                            <th>Qty</th>

                            <th>Unit Price</th>

                            <th>Total</th>

                        </tr>

                        </thead>


                        <tbody>

                        <?php foreach (
                            $medicines
                            as $index => $medicine
                        ): ?>

                            <?php

                            $quantity =
                                (int) $medicine[
                                    'quantity_dispensed'
                                ];

                            $unitPrice =
                                (float) $medicine[
                                    'selling_price'
                                ];

                            $total =
                                $quantity * $unitPrice;

                            ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $medicine[
                                            'medicine_name'
                                        ]
                                    ) ?>

                                    <br>

                                    <small class="text-muted">

                                        <?= htmlspecialchars(
                                            $medicine[
                                                'medicine_code'
                                            ]
                                        ) ?>

                                    </small>

                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $medicine['dosage']
                                            ?: '-'
                                    ) ?>

                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $medicine['frequency']
                                            ?: '-'
                                    ) ?>

                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $medicine['duration']
                                            ?: '-'
                                    ) ?>

                                </td>


                                <td>
                                    <?= $quantity ?>
                                </td>


                                <td>

                                    KSh
                                    <?= number_format(
                                        $unitPrice,
                                        2
                                    ) ?>

                                </td>


                                <td>

                                    KSh
                                    <?= number_format(
                                        $total,
                                        2
                                    ) ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>


                        <tfoot>

                        <tr>

                            <th
                                colspan="7"
                                class="text-end"
                            >

                                Medicine Total:

                            </th>

                            <th>

                                KSh
                                <?= number_format(
                                    $medicineTotal,
                                    2
                                ) ?>

                            </th>

                        </tr>

                        </tfoot>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- Bill Form -->

    <div class="card shadow mb-5">

        <div class="card-header bg-dark text-white">

            <h5 class="mb-0">
                🧾 Bill Summary
            </h5>

        </div>


        <div class="card-body">


            <form
                action="save_bill.php"
                method="POST"
            >


                <input
                    type="hidden"
                    name="visit_id"
                    value="<?= $visit_id ?>"
                >


                <div class="row">


                    <div class="col-md-4 mb-3">

                        <label class="form-label">
                            Consultation Fee
                        </label>

                        <input
                            type="number"
                            name="consultation_fee"
                            id="consultation_fee"
                            class="form-control amount-input"
                            value="0"
                            min="0"
                            step="0.01"
                        >

                    </div>


                    <div class="col-md-4 mb-3">

                        <label class="form-label">
                            Other Charges
                        </label>

                        <input
                            type="number"
                            name="other_charges"
                            id="other_charges"
                            class="form-control amount-input"
                            value="0"
                            min="0"
                            step="0.01"
                        >

                    </div>


                    <div class="col-md-4 mb-3">

                        <label class="form-label">
                            Discount
                        </label>

                        <input
                            type="number"
                            name="discount"
                            id="discount"
                            class="form-control amount-input"
                            value="0"
                            min="0"
                            step="0.01"
                        >

                    </div>

                </div>


                <div class="row">


                    <div class="col-md-4">

                        <div class="border rounded p-3 bg-light">

                            <small class="text-muted">
                                Laboratory
                            </small>

                            <h5>

                                KSh
                                <?= number_format(
                                    $labTotal,
                                    2
                                ) ?>

                            </h5>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="border rounded p-3 bg-light">

                            <small class="text-muted">
                                Medicines
                            </small>

                            <h5>

                                KSh
                                <?= number_format(
                                    $medicineTotal,
                                    2
                                ) ?>

                            </h5>

                        </div>

                    </div>


                    <div class="col-md-4">

                        <div class="border rounded p-3 bg-primary text-white">

                            <small>
                                Current Subtotal
                            </small>

                            <h5 id="subtotalDisplay">

                                KSh
                                <?= number_format(
                                    $automaticSubtotal,
                                    2
                                ) ?>

                            </h5>

                        </div>

                    </div>

                </div>


                <hr class="my-4">


                <div class="row justify-content-end">


                    <div class="col-md-5">


                        <div class="d-flex justify-content-between mb-2">

                            <span>
                                Services Total:
                            </span>

                            <strong id="servicesTotal">
                                KSh 0.00
                            </strong>

                        </div>


                        <div class="d-flex justify-content-between mb-2">

                            <span>
                                Discount:
                            </span>

                            <strong id="discountDisplay">
                                KSh 0.00
                            </strong>

                        </div>


                        <div class="d-flex justify-content-between border-top pt-3">

                            <strong class="fs-5">
                                TOTAL:
                            </strong>

                            <strong
                                class="fs-4 text-primary"
                                id="totalDisplay"
                            >
                                KSh 0.00
                            </strong>

                        </div>

                    </div>

                </div>


                <div class="mt-4 d-flex justify-content-end gap-2">

                    <a
                        href="index.php"
                        class="btn btn-secondary"
                    >
                        Cancel
                    </a>


                    <button
                        type="submit"
                        class="btn btn-success btn-lg"
                        <?= $existingBill ? 'disabled' : '' ?>
                    >
                        🧾 Create Bill
                    </button>

                </div>


            </form>

        </div>

    </div>

</div>


<script>

const laboratoryTotal =
    <?= json_encode($labTotal) ?>;

const medicineTotal =
    <?= json_encode($medicineTotal) ?>;


const consultationInput =
    document.getElementById(
        'consultation_fee'
    );

const otherInput =
    document.getElementById(
        'other_charges'
    );

const discountInput =
    document.getElementById(
        'discount'
    );


function calculateTotal()
{

    const consultation =
        parseFloat(
            consultationInput.value
        ) || 0;


    const other =
        parseFloat(
            otherInput.value
        ) || 0;


    const discount =
        parseFloat(
            discountInput.value
        ) || 0;


    const servicesTotal =
        laboratoryTotal
        + medicineTotal
        + consultation
        + other;


    let total =
        servicesTotal
        - discount;


    if (total < 0) {
        total = 0;
    }


    document.getElementById(
        'servicesTotal'
    ).textContent =
        'KSh '
        + servicesTotal.toFixed(2);


    document.getElementById(
        'discountDisplay'
    ).textContent =
        'KSh '
        + discount.toFixed(2);


    document.getElementById(
        'totalDisplay'
    ).textContent =
        'KSh '
        + total.toFixed(2);


    document.getElementById(
        'subtotalDisplay'
    ).textContent =
        'KSh '
        + servicesTotal.toFixed(2);
}


consultationInput.addEventListener(
    'input',
    calculateTotal
);

otherInput.addEventListener(
    'input',
    calculateTotal
);

discountInput.addEventListener(
    'input',
    calculateTotal
);


calculateTotal();

</script>


</body>

</html>