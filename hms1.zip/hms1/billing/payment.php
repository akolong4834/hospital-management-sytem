<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$bill_id = isset($_GET['bill_id'])
    ? (int) $_GET['bill_id']
    : 0;

if ($bill_id <= 0) {
    die("Invalid bill ID.");
}


/*
|--------------------------------------------------------------------------
| Get bill information
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        b.bill_id,
        b.bill_number,
        b.subtotal,
        b.discount,
        b.total_amount,
        b.amount_paid,
        b.balance,
        b.bill_status,
        b.created_at,

        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.payment_category,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.phone

    FROM bills b

    INNER JOIN patient_visits v
        ON b.visit_id = v.visit_id

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    WHERE b.bill_id = ?

    LIMIT 1
");

$stmt->execute([$bill_id]);

$bill = $stmt->fetch();

if (!$bill) {
    die("Bill not found.");
}


/*
|--------------------------------------------------------------------------
| Check whether bill is already paid
|--------------------------------------------------------------------------
*/

if ($bill['bill_status'] === 'Paid' || $bill['balance'] <= 0) {

    header(
        "Location: receipt.php?bill_id="
        . $bill_id
    );

    exit();
}


/*
|--------------------------------------------------------------------------
| Payment amount
|--------------------------------------------------------------------------
*/

$balance = (float) $bill['balance'];

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Payment - <?= htmlspecialchars($bill['bill_number']) ?>
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f4f6f9;
        }

        .payment-container {
            max-width: 900px;
            margin: 40px auto;
        }

        .payment-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.08);
        }

        .balance-box {
            border-radius: 8px;
            padding: 25px;
            background: #f8f9fa;
        }

        .balance-amount {
            font-size: 32px;
            font-weight: 700;
        }

    </style>

</head>


<body>


<div class="container payment-container">


    <!-- Header -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2>
                💳 Receive Payment
            </h2>

            <p class="text-muted mb-0">
                Record patient payment
            </p>

        </div>


        <div class="d-flex gap-2">

            <a
                href="invoice.php?bill_id=<?= $bill_id ?>"
                class="btn btn-secondary"
            >
                ← Invoice
            </a>

            <a
                href="index.php"
                class="btn btn-outline-secondary"
            >
                Billing Queue
            </a>

        </div>

    </div>


    <!-- Patient information -->

    <div class="card payment-card mb-4">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">
                Patient &amp; Bill Information
            </h5>

        </div>


        <div class="card-body">

            <div class="row">


                <div class="col-md-6 mb-3">

                    <strong>Patient</strong>

                    <div class="fs-5">

                        <?= htmlspecialchars(
                            trim(
                                $bill['first_name']
                                . ' '
                                . $bill['middle_name']
                                . ' '
                                . $bill['last_name']
                            )
                        ) ?>

                    </div>

                    <small class="text-muted">

                        Patient No:
                        <?= htmlspecialchars(
                            $bill['patient_number']
                        ) ?>

                    </small>

                </div>


                <div class="col-md-3 mb-3">

                    <strong>Bill Number</strong>

                    <div>

                        <?= htmlspecialchars(
                            $bill['bill_number']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3 mb-3">

                    <strong>Visit Number</strong>

                    <div>

                        <?= htmlspecialchars(
                            $bill['visit_number']
                        ) ?>

                    </div>

                </div>


            </div>


            <div class="row">


                <div class="col-md-4">

                    <strong>Total Bill</strong>

                    <div>

                        KSh
                        <?= number_format(
                            $bill['total_amount'],
                            2
                        ) ?>

                    </div>

                </div>


                <div class="col-md-4">

                    <strong>Amount Paid</strong>

                    <div class="text-success">

                        KSh
                        <?= number_format(
                            $bill['amount_paid'],
                            2
                        ) ?>

                    </div>

                </div>


                <div class="col-md-4">

                    <strong>Outstanding Balance</strong>

                    <div class="text-danger fw-bold">

                        KSh
                        <?= number_format(
                            $bill['balance'],
                            2
                        ) ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- Payment form -->

    <div class="card payment-card">

        <div class="card-header bg-success text-white">

            <h5 class="mb-0">
                Payment Details
            </h5>

        </div>


        <div class="card-body">


            <form
                action="save_payment.php"
                method="POST"
                id="paymentForm"
            >


                <input
                    type="hidden"
                    name="bill_id"
                    value="<?= $bill_id ?>"
                >


                <!-- Payment method -->

                <div class="mb-4">

                    <label
                        for="payment_method"
                        class="form-label fw-bold"
                    >
                        Payment Method
                    </label>


                    <select
                        name="payment_method"
                        id="payment_method"
                        class="form-select form-select-lg"
                        required
                    >

                        <option value="">
                            -- Select Payment Method --
                        </option>

                        <option value="Cash">
                            💵 Cash
                        </option>

                        <option value="M-Pesa">
                            📱 M-Pesa
                        </option>

                        <option value="Card">
                            💳 Card
                        </option>

                        <option value="Insurance">
                            🏥 Insurance
                        </option>

                        <option value="Bank">
                            🏦 Bank
                        </option>

                        <option value="Other">
                            Other
                        </option>

                    </select>

                </div>


                <!-- Amount -->

                <div class="mb-4">

                    <label
                        for="amount"
                        class="form-label fw-bold"
                    >
                        Amount Received
                    </label>


                    <div class="input-group input-group-lg">

                        <span class="input-group-text">
                            KSh
                        </span>

                        <input
                            type="number"
                            name="amount"
                            id="amount"
                            class="form-control"
                            min="0.01"
                            max="<?= htmlspecialchars(
                                $balance
                            ) ?>"
                            step="0.01"
                            value="<?= number_format(
                                $balance,
                                2,
                                '.',
                                ''
                            ) ?>"
                            required
                        >

                    </div>


                    <div class="form-text">

                        Maximum payment for this transaction:

                        KSh
                        <?= number_format(
                            $balance,
                            2
                        ) ?>

                    </div>

                </div>


                <!-- Transaction reference -->

                <div
                    class="mb-4"
                    id="referenceContainer"
                >

                    <label
                        for="transaction_reference"
                        class="form-label fw-bold"
                    >
                        Transaction / Reference Number
                    </label>


                    <input
                        type="text"
                        name="transaction_reference"
                        id="transaction_reference"
                        class="form-control form-control-lg"
                        placeholder="e.g. M-Pesa transaction code"
                        maxlength="100"
                    >


                    <div class="form-text">

                        Required for M-Pesa, Card and Bank payments.

                    </div>

                </div>


                <!-- Payment notes -->

                <div class="mb-4">

                    <label
                        for="payment_notes"
                        class="form-label fw-bold"
                    >
                        Payment Notes
                    </label>


                    <textarea
                        name="payment_notes"
                        id="payment_notes"
                        class="form-control"
                        rows="3"
                        placeholder="Optional payment notes..."
                    ></textarea>

                </div>


                <!-- Payment summary -->

                <div class="balance-box mb-4">


                    <div class="d-flex justify-content-between mb-2">

                        <span>
                            Outstanding Balance:
                        </span>

                        <strong>

                            KSh
                            <?= number_format(
                                $balance,
                                2
                            ) ?>

                        </strong>

                    </div>


                    <div class="d-flex justify-content-between mb-2">

                        <span>
                            Amount Being Paid:
                        </span>

                        <strong
                            id="paymentDisplay"
                            class="text-success"
                        >
                            KSh
                            <?= number_format(
                                $balance,
                                2
                            ) ?>
                        </strong>

                    </div>


                    <hr>


                    <div class="d-flex justify-content-between">

                        <strong class="fs-5">
                            Balance After Payment:
                        </strong>

                        <strong
                            id="remainingDisplay"
                            class="fs-4 text-danger"
                        >
                            KSh 0.00
                        </strong>

                    </div>

                </div>


                <!-- Buttons -->

                <div class="d-flex justify-content-end gap-2">

                    <a
                        href="invoice.php?bill_id=<?= $bill_id ?>"
                        class="btn btn-secondary btn-lg"
                    >
                        Cancel
                    </a>


                    <button
                        type="submit"
                        class="btn btn-success btn-lg"
                    >
                        💰 Record Payment
                    </button>

                </div>


            </form>

        </div>

    </div>

</div>


<script>

const balance =
    <?= json_encode($balance) ?>;

const amountInput =
    document.getElementById('amount');

const methodInput =
    document.getElementById('payment_method');

const referenceInput =
    document.getElementById(
        'transaction_reference'
    );


const paymentDisplay =
    document.getElementById(
        'paymentDisplay'
    );

const remainingDisplay =
    document.getElementById(
        'remainingDisplay'
    );


function updatePaymentSummary()
{

    let amount =
        parseFloat(
            amountInput.value
        ) || 0;


    if (amount < 0) {
        amount = 0;
    }


    let remaining =
        balance - amount;


    if (remaining < 0) {
        remaining = 0;
    }


    paymentDisplay.textContent =
        'KSh '
        + amount.toFixed(2);


    remainingDisplay.textContent =
        'KSh '
        + remaining.toFixed(2);


    if (remaining === 0) {

        remainingDisplay.classList.remove(
            'text-danger'
        );

        remainingDisplay.classList.add(
            'text-success'
        );

    } else {

        remainingDisplay.classList.remove(
            'text-success'
        );

        remainingDisplay.classList.add(
            'text-danger'
        );
    }

}


function checkReferenceRequirement()
{

    const method =
        methodInput.value;


    if (
        method === 'M-Pesa'
        || method === 'Card'
        || method === 'Bank'
    ) {

        referenceInput.required = true;

        referenceInput.placeholder =
            'Enter transaction/reference number';

    } else {

        referenceInput.required = false;

        referenceInput.placeholder =
            'Optional transaction/reference number';

    }

}


amountInput.addEventListener(
    'input',
    updatePaymentSummary
);


methodInput.addEventListener(
    'change',
    checkReferenceRequirement
);


updatePaymentSummary();

checkReferenceRequirement();


document.getElementById(
    'paymentForm'
).addEventListener(
    'submit',
    function(event)
    {

        const amount =
            parseFloat(
                amountInput.value
            ) || 0;


        if (amount <= 0) {

            event.preventDefault();

            alert(
                'Please enter a valid payment amount.'
            );

            return;
        }


        if (amount > balance) {

            event.preventDefault();

            alert(
                'Payment cannot exceed the outstanding balance.'
            );

            return;
        }


        const method =
            methodInput.value;


        if (!method) {

            event.preventDefault();

            alert(
                'Please select a payment method.'
            );

            return;
        }


        if (
            (
                method === 'M-Pesa'
                || method === 'Card'
                || method === 'Bank'
            )
            &&
            referenceInput.value.trim() === ''
        ) {

            event.preventDefault();

            alert(
                'Please enter the transaction/reference number.'
            );

            referenceInput.focus();

            return;
        }


        if (
            !confirm(
                'Are you sure you want to record this payment?'
            )
        ) {

            event.preventDefault();

        }

    }
);

</script>


</body>

</html>