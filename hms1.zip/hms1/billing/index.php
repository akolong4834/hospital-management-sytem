<?php

session_start();


require_once "../includes/db.php";
require_once "../includes/auth.php";

require_permission('billing.view');

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.payment_category,
        v.status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.phone,

        c.diagnosis,

        pr.prescription_id,
        pr.prescription_status

    FROM patient_visits v

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    LEFT JOIN consultations c
        ON v.visit_id = c.visit_id

    LEFT JOIN prescriptions pr
        ON v.visit_id = pr.visit_id

    WHERE v.status = 'Billing'

    ORDER BY v.visit_id DESC
";

$stmt = $pdo->query($sql);
$patients = $stmt->fetchAll();

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Billing Queue - Hospital Management System</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>

<body class="bg-light">

<div class="container-fluid mt-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                💰 Billing Queue
            </h2>

            <p class="text-muted mb-0">
                Patients ready for billing and payment
            </p>

        </div>

        <div>

            <a
                href="../index.php"
                class="btn btn-secondary"
            >
                ← Dashboard
            </a>

        </div>

    </div>


    <div class="card shadow">

        <div class="card-header bg-primary text-white">

            <h5 class="mb-0">
                Patients Awaiting Billing
            </h5>

        </div>


        <div class="card-body">

            <?php if (empty($patients)): ?>

                <div class="alert alert-info">

                    No patients are currently waiting for billing.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-dark">

                        <tr>

                            <th>#</th>

                            <th>Patient</th>

                            <th>Patient No.</th>

                            <th>Visit No.</th>

                            <th>Gender</th>

                            <th>Phone</th>

                            <th>Diagnosis</th>

                            <th>Payment Category</th>

                            <th>Status</th>

                            <th>Action</th>

                        </tr>

                        </thead>


                        <tbody>

                        <?php foreach ($patients as $index => $patient): ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>


                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            trim(
                                                $patient['first_name']
                                                . ' '
                                                . $patient['middle_name']
                                                . ' '
                                                . $patient['last_name']
                                            )
                                        ) ?>
                                    </strong>

                                </td>


                                <td>
                                    <?= htmlspecialchars(
                                        $patient['patient_number']
                                    ) ?>
                                </td>


                                <td>
                                    <?= htmlspecialchars(
                                        $patient['visit_number']
                                    ) ?>
                                </td>


                                <td>
                                    <?= htmlspecialchars(
                                        $patient['gender']
                                    ) ?>
                                </td>


                                <td>
                                    <?= htmlspecialchars(
                                        $patient['phone']
                                    ) ?>
                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $patient['diagnosis']
                                            ?: 'Not recorded'
                                    ) ?>

                                </td>


                                <td>

                                    <span class="badge bg-info text-dark">

                                        <?= htmlspecialchars(
                                            $patient['payment_category']
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <span class="badge bg-warning text-dark">

                                        <?= htmlspecialchars(
                                            $patient['status']
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <a
                                        href="create_bill.php?visit_id=<?= (int) $patient['visit_id'] ?>"
                                        class="btn btn-primary btn-sm"
                                    >
                                        Create Bill
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

</body>
</html>