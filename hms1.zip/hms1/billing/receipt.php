<?php
require_once "../includes/db.php";
require_once "../includes/auth.php";

require_permission(billing.receipt);

check_authentication();

$payment_id = isset($_GET['payment_id']) ? (int)$_GET['payment_id'] : 0;
$bill_id = isset($_GET['bill_id']) ? (int)$_GET['bill_id'] : 0;

if ($payment_id <= 0 && $bill_id <= 0) {
    die("Invalid receipt request.");
}

/*
|--------------------------------------------------------------------------
| Get payment
|--------------------------------------------------------------------------
*/

if ($payment_id > 0) {

    $stmt = $pdo->prepare("
        SELECT
            p.payment_id,
            p.bill_id,
            p.receipt_number,
            p.payment_method,
            p.amount,
            p.transaction_reference,
            p.payment_notes,
            p.received_by,
            p.payment_date,

            b.bill_number,
            b.total_amount,
            b.amount_paid,
            b.balance,
            b.bill_status,

            v.visit_id,
            v.visit_number,
            v.visit_date,
            v.department,

            pt.patient_id,
            pt.patient_number,
            pt.first_name,
            pt.middle_name,
            pt.last_name,
            pt.gender,
            pt.phone

        FROM payments p

        INNER JOIN bills b
            ON p.bill_id = b.bill_id

        INNER JOIN patient_visits v
            ON b.visit_id = v.visit_id

        INNER JOIN patients pt
            ON v.patient_id = pt.patient_id

        WHERE p.payment_id = ?

        LIMIT 1
    ");

    $stmt->execute([$payment_id]);

} else {

    /*
    |--------------------------------------------------------------------------
    | If only bill_id was supplied, get latest payment
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            p.payment_id,
            p.bill_id,
            p.receipt_number,
            p.payment_method,
            p.amount,
            p.transaction_reference,
            p.payment_notes,
            p.received_by,
            p.payment_date,

            b.bill_number,
            b.total_amount,
            b.amount_paid,
            b.balance,
            b.bill_status,

            v.visit_id,
            v.visit_number,
            v.visit_date,
            v.department,

            pt.patient_id,
            pt.patient_number,
            pt.first_name,
            pt.middle_name,
            pt.last_name,
            pt.gender,
            pt.phone

        FROM payments p

        INNER JOIN bills b
            ON p.bill_id = b.bill_id

        INNER JOIN patient_visits v
            ON b.visit_id = v.visit_id

        INNER JOIN patients pt
            ON v.patient_id = pt.patient_id

        WHERE p.bill_id = ?

        ORDER BY p.payment_id DESC

        LIMIT 1
    ");

    $stmt->execute([$bill_id]);
}

$receipt = $stmt->fetch();

if (!$receipt) {
    die("Payment receipt not found.");
}

/*
|--------------------------------------------------------------------------
| Get cashier/user name
|--------------------------------------------------------------------------
*/

$cashier_name = "System User";

if (!empty($receipt['received_by'])) {

    $userStmt = $pdo->prepare("
        SELECT
            COALESCE(full_name, username) AS user_name
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $userStmt->execute([
        $receipt['received_by']
    ]);

    $user = $userStmt->fetch();

    if ($user && !empty($user['user_name'])) {
        $cashier_name = $user['user_name'];
    }
}

/*
|--------------------------------------------------------------------------
| Patient full name
|--------------------------------------------------------------------------
*/

$patient_name = trim(
    $receipt['first_name']
    . ' '
    . ($receipt['middle_name'] ?? '')
    . ' '
    . $receipt['last_name']
);

/*
|--------------------------------------------------------------------------
| Payment calculations
|--------------------------------------------------------------------------
*/

$current_payment = (float)$receipt['amount'];
$total_bill = (float)$receipt['total_amount'];
$total_paid = (float)$receipt['amount_paid'];
$balance = (float)$receipt['balance'];

/*
|--------------------------------------------------------------------------
| Calculate previous amount paid before this receipt
|--------------------------------------------------------------------------
*/

$previous_paid = $total_paid - $current_payment;

if ($previous_paid < 0) {
    $previous_paid = 0;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Payment Receipt - <?= htmlspecialchars($receipt['receipt_number']) ?>
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f4f6f9;
            font-family: Arial, Helvetica, sans-serif;
        }

        .receipt-wrapper {
            max-width: 850px;
            margin: 30px auto;
        }

        .receipt {
            background: #ffffff;
            border: 1px solid #ddd;
            padding: 35px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.08);
        }

        .hospital-name {
            font-size: 28px;
            font-weight: 700;
            text-transform: uppercase;
        }

        .hospital-subtitle {
            color: #666;
            font-size: 14px;
        }

        .receipt-title {
            font-size: 24px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .receipt-number {
            font-size: 18px;
            font-weight: 600;
        }

        .section-title {
            font-weight: 700;
            background: #f1f3f5;
            padding: 8px 10px;
            margin-bottom: 12px;
        }

        .amount-paid {
            font-size: 28px;
            font-weight: 700;
        }

        .balance {
            font-size: 22px;
            font-weight: 700;
        }

        .signature {
            margin-top: 70px;
        }

        .footer {
            margin-top: 30px;
            text-align: center;
            color: #666;
            font-size: 13px;
        }

        .no-print {
            margin-bottom: 20px;
        }

        @media print {

            body {
                background: #ffffff;
            }

            .receipt-wrapper {
                max-width: 100%;
                margin: 0;
            }

            .receipt {
                border: none;
                box-shadow: none;
                padding: 15px;
            }

            .no-print {
                display: none !important;
            }

            @page {
                size: A4;
                margin: 12mm;
            }
        }

    </style>

</head>

<body>

<div class="container receipt-wrapper">

    <!-- ACTION BUTTONS -->

    <div class="no-print d-flex justify-content-between align-items-center">

        <a
            href="invoice.php?bill_id=<?= (int)$receipt['bill_id'] ?>"
            class="btn btn-secondary"
        >
            ← Back to Invoice
        </a>

        <button
            onclick="window.print()"
            class="btn btn-primary"
        >
            🖨 Print Receipt
        </button>

    </div>


    <!-- RECEIPT -->

    <div class="receipt">

        <!-- HEADER -->

        <div class="row align-items-center mb-4">

            <div class="col-md-8">

                <div class="hospital-name">
                    Hospital Management System
                </div>

                <div class="hospital-subtitle">
                    Healthcare Payment Receipt
                </div>

                <div class="hospital-subtitle">
                    Professional Medical Services
                </div>

            </div>

            <div class="col-md-4 text-md-end mt-3 mt-md-0">

                <div class="receipt-title">
                    PAYMENT RECEIPT
                </div>

                <div class="receipt-number">
                    <?= htmlspecialchars($receipt['receipt_number']) ?>
                </div>

            </div>

        </div>


        <hr>


        <!-- RECEIPT INFORMATION -->

        <div class="row mb-4">

            <div class="col-md-6">

                <div class="section-title">
                    Receipt Information
                </div>

                <table class="table table-sm table-borderless">

                    <tr>
                        <td><strong>Receipt No.</strong></td>
                        <td>
                            <?= htmlspecialchars($receipt['receipt_number']) ?>
                        </td>
                    </tr>

                    <tr>
                        <td><strong>Bill No.</strong></td>
                        <td>
                            <?= htmlspecialchars($receipt['bill_number']) ?>
                        </td>
                    </tr>

                    <tr>
                        <td><strong>Visit No.</strong></td>
                        <td>
                            <?= htmlspecialchars($receipt['visit_number']) ?>
                        </td>
                    </tr>

                    <tr>
                        <td><strong>Payment Date</strong></td>
                        <td>
                            <?= date(
                                'd M Y H:i',
                                strtotime($receipt['payment_date'])
                            ) ?>
                        </td>
                    </tr>

                </table>

            </div>


            <div class="col-md-6">

                <div class="section-title">
                    Patient Information
                </div>

                <table class="table table-sm table-borderless">

                    <tr>
                        <td><strong>Patient No.</strong></td>
                        <td>
                            <?= htmlspecialchars($receipt['patient_number']) ?>
                        </td>
                    </tr>

                    <tr>
                        <td><strong>Patient Name</strong></td>
                        <td>
                            <?= htmlspecialchars($patient_name) ?>
                        </td>
                    </tr>

                    <tr>
                        <td><strong>Gender</strong></td>
                        <td>
                            <?= htmlspecialchars($receipt['gender'] ?? '') ?>
                        </td>
                    </tr>

                    <tr>
                        <td><strong>Phone</strong></td>
                        <td>
                            <?= htmlspecialchars($receipt['phone'] ?? '') ?>
                        </td>
                    </tr>

                </table>

            </div>

        </div>


        <!-- PAYMENT DETAILS -->

        <div class="section-title">
            Payment Details
        </div>

        <table class="table table-bordered">

            <thead>

                <tr>

                    <th>Description</th>

                    <th class="text-end">
                        Amount (Ksh)
                    </th>

                </tr>

            </thead>

            <tbody>

                <tr>

                    <td>
                        Payment against Bill
                        <?= htmlspecialchars($receipt['bill_number']) ?>
                    </td>

                    <td class="text-end">
                        <?= number_format($current_payment, 2) ?>
                    </td>

                </tr>

            </tbody>

            <tfoot>

                <tr>

                    <th class="text-end">
                        Amount Paid
                    </th>

                    <th class="text-end">
                        <?= number_format($current_payment, 2) ?>
                    </th>

                </tr>

            </tfoot>

        </table>


        <!-- PAYMENT SUMMARY -->

        <div class="row mt-4">

            <div class="col-md-6">

                <div class="section-title">
                    Payment Method
                </div>

                <table class="table table-sm table-borderless">

                    <tr>

                        <td>
                            <strong>Method</strong>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $receipt['payment_method']
                            ) ?>
                        </td>

                    </tr>

                    <?php if (!empty($receipt['transaction_reference'])): ?>

                        <tr>

                            <td>
                                <strong>Reference</strong>
                            </td>

                            <td>
                                <?= htmlspecialchars(
                                    $receipt['transaction_reference']
                                ) ?>
                            </td>

                        </tr>

                    <?php endif; ?>

                    <tr>

                        <td>
                            <strong>Received By</strong>
                        </td>

                        <td>
                            <?= htmlspecialchars($cashier_name) ?>
                        </td>

                    </tr>

                </table>

            </div>


            <div class="col-md-6">

                <div class="section-title">
                    Account Summary
                </div>

                <table class="table table-sm">

                    <tr>

                        <td>
                            Total Bill
                        </td>

                        <td class="text-end">
                            Ksh <?= number_format($total_bill, 2) ?>
                        </td>

                    </tr>

                    <tr>

                        <td>
                            Previously Paid
                        </td>

                        <td class="text-end">
                            Ksh <?= number_format($previous_paid, 2) ?>
                        </td>

                    </tr>

                    <tr>

                        <td>
                            This Payment
                        </td>

                        <td class="text-end">
                            <strong>
                                Ksh <?= number_format(
                                    $current_payment,
                                    2
                                ) ?>
                            </strong>
                        </td>

                    </tr>

                    <tr class="table-light">

                        <th>
                            Total Paid
                        </th>

                        <th class="text-end">
                            Ksh <?= number_format($total_paid, 2) ?>
                        </th>

                    </tr>

                    <tr>

                        <th>
                            Balance
                        </th>

                        <th class="text-end">

                            <span class="balance">

                                Ksh <?= number_format(
                                    $balance,
                                    2
                                ) ?>

                            </span>

                        </th>

                    </tr>

                </table>

            </div>

        </div>


        <!-- PAYMENT STATUS -->

        <div class="text-center mt-4">

            <?php if ($receipt['bill_status'] === 'Paid'): ?>

                <span class="badge bg-success fs-6 px-4 py-2">
                    PAID IN FULL
                </span>

            <?php elseif ($receipt['bill_status'] === 'Partially Paid'): ?>

                <span class="badge bg-warning text-dark fs-6 px-4 py-2">
                    PARTIALLY PAID
                </span>

            <?php else: ?>

                <span class="badge bg-secondary fs-6 px-4 py-2">
                    PAYMENT RECEIVED
                </span>

            <?php endif; ?>

        </div>


        <!-- NOTES -->

        <?php if (!empty($receipt['payment_notes'])): ?>

            <div class="mt-4">

                <div class="section-title">
                    Payment Notes
                </div>

                <div class="border rounded p-3">

                    <?= nl2br(
                        htmlspecialchars(
                            $receipt['payment_notes']
                        )
                    ) ?>

                </div>

            </div>

        <?php endif; ?>


        <!-- SIGNATURE -->

        <div class="row signature">

            <div class="col-md-6">

                ______________________________

                <br>

                <strong>
                    Cashier / Received By
                </strong>

                <br>

                <?= htmlspecialchars($cashier_name) ?>

            </div>

            <div class="col-md-6 text-md-end mt-4 mt-md-0">

                ______________________________

                <br>

                <strong>
                    Patient / Authorized Representative
                </strong>

            </div>

        </div>


        <!-- FOOTER -->

        <div class="footer">

            <strong>
                Thank you for choosing our healthcare services.
            </strong>

            <br>

            This is a computer-generated receipt and does not require a stamp.

        </div>

    </div>

</div>

</body>

</html>