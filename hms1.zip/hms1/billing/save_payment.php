<?php
require_once "../includes/db.php";
require_once "../includes/auth.php";

require_permission(billing.payment);

check_authentication();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}

$bill_id = isset($_POST['bill_id']) ? (int)$_POST['bill_id'] : 0;
$payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : '';
$amount = isset($_POST['amount']) ? (float)$_POST['amount'] : 0;
$transaction_reference = isset($_POST['transaction_reference'])
    ? trim($_POST['transaction_reference'])
    : '';
$payment_notes = isset($_POST['payment_notes'])
    ? trim($_POST['payment_notes'])
    : '';

$received_by = isset($_SESSION['user_id'])
    ? (int)$_SESSION['user_id']
    : null;

/*
|--------------------------------------------------------------------------
| Basic Validation
|--------------------------------------------------------------------------
*/

if ($bill_id <= 0) {
    die("Invalid bill ID.");
}

$allowed_methods = [
    'Cash',
    'M-Pesa',
    'Card',
    'Insurance',
    'Bank',
    'Other'
];

if (!in_array($payment_method, $allowed_methods, true)) {
    die("Invalid payment method.");
}

if ($amount <= 0) {
    die("Payment amount must be greater than zero.");
}

/*
|--------------------------------------------------------------------------
| Transaction
|--------------------------------------------------------------------------
*/

try {

    $pdo->beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Get and lock bill
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            bill_id,
            visit_id,
            bill_number,
            total_amount,
            amount_paid,
            balance,
            bill_status
        FROM bills
        WHERE bill_id = ?
        FOR UPDATE
    ");

    $stmt->execute([$bill_id]);

    $bill = $stmt->fetch();

    if (!$bill) {
        throw new Exception("Bill not found.");
    }

    /*
    |--------------------------------------------------------------------------
    | Check bill status
    |--------------------------------------------------------------------------
    */

    if ($bill['bill_status'] === 'Cancelled') {
        throw new Exception("This bill has been cancelled.");
    }

    if ($bill['bill_status'] === 'Paid' || (float)$bill['balance'] <= 0) {
        throw new Exception("This bill has already been fully paid.");
    }

    /*
    |--------------------------------------------------------------------------
    | Calculate outstanding balance
    |--------------------------------------------------------------------------
    */

    $total_amount = (float)$bill['total_amount'];
    $amount_paid = (float)$bill['amount_paid'];
    $balance = (float)$bill['balance'];

    /*
    |--------------------------------------------------------------------------
    | Prevent overpayment
    |--------------------------------------------------------------------------
    */

    if ($amount > $balance) {
        throw new Exception(
            "Payment amount cannot exceed the outstanding balance of Ksh "
            . number_format($balance, 2)
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Require transaction reference for non-cash payments
    |--------------------------------------------------------------------------
    */

    if (
        in_array(
            $payment_method,
            ['M-Pesa', 'Card', 'Insurance', 'Bank'],
            true
        )
        && $transaction_reference === ''
    ) {
        throw new Exception(
            "Transaction/reference number is required for "
            . $payment_method
            . " payments."
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Generate unique receipt number
    |--------------------------------------------------------------------------
    */

    $date_prefix = date('Ymd');

    $receipt_number = null;

    for ($i = 1; $i <= 9999; $i++) {

        $candidate = 'RCT-' . $date_prefix . '-' . str_pad(
            $i,
            4,
            '0',
            STR_PAD_LEFT
        );

        $check = $pdo->prepare("
            SELECT payment_id
            FROM payments
            WHERE receipt_number = ?
            LIMIT 1
        ");

        $check->execute([$candidate]);

        if (!$check->fetch()) {
            $receipt_number = $candidate;
            break;
        }
    }

    if (!$receipt_number) {
        throw new Exception("Unable to generate a unique receipt number.");
    }

    /*
    |--------------------------------------------------------------------------
    | Insert payment
    |--------------------------------------------------------------------------
    */

    $insert = $pdo->prepare("
        INSERT INTO payments (
            bill_id,
            receipt_number,
            payment_method,
            amount,
            transaction_reference,
            payment_notes,
            received_by,
            payment_date
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");

    $insert->execute([
        $bill_id,
        $receipt_number,
        $payment_method,
        $amount,
        $transaction_reference !== '' ? $transaction_reference : null,
        $payment_notes !== '' ? $payment_notes : null,
        $received_by
    ]);

    $payment_id = (int)$pdo->lastInsertId();

    /*
    |--------------------------------------------------------------------------
    | Calculate new payment totals
    |--------------------------------------------------------------------------
    */

    $new_amount_paid = $amount_paid + $amount;

    $new_balance = $total_amount - $new_amount_paid;

    /*
    |--------------------------------------------------------------------------
    | Prevent floating-point rounding problems
    |--------------------------------------------------------------------------
    */

    if ($new_balance < 0.01) {
        $new_balance = 0.00;
    }

    if ($new_amount_paid > $total_amount) {
        $new_amount_paid = $total_amount;
    }

    /*
    |--------------------------------------------------------------------------
    | Determine bill status
    |--------------------------------------------------------------------------
    */

    if ($new_balance <= 0) {

        $new_balance = 0.00;
        $new_status = 'Paid';

    } elseif ($new_amount_paid > 0) {

        $new_status = 'Partially Paid';

    } else {

        $new_status = 'Unpaid';
    }

    /*
    |--------------------------------------------------------------------------
    | Update bill
    |--------------------------------------------------------------------------
    */

    $updateBill = $pdo->prepare("
        UPDATE bills
        SET
            amount_paid = ?,
            balance = ?,
            bill_status = ?,
            updated_at = NOW()
        WHERE bill_id = ?
    ");

    $updateBill->execute([
        $new_amount_paid,
        $new_balance,
        $new_status,
        $bill_id
    ]);

    /*
    |--------------------------------------------------------------------------
    | If fully paid, complete the patient visit
    |--------------------------------------------------------------------------
    */

    if ($new_status === 'Paid') {

        $updateVisit = $pdo->prepare("
            UPDATE patient_visits
            SET
                status = 'Completed',
                updated_at = NOW()
            WHERE visit_id = ?
        ");

        $updateVisit->execute([
            $bill['visit_id']
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Commit transaction
    |--------------------------------------------------------------------------
    */

    $pdo->commit();

    /*
    |--------------------------------------------------------------------------
    | Redirect to receipt
    |--------------------------------------------------------------------------
    */

    header(
        "Location: receipt.php?payment_id="
        . $payment_id
        . "&bill_id="
        . $bill_id
    );

    exit();

} catch (Exception $e) {

    /*
    |--------------------------------------------------------------------------
    | Rollback if transaction is active
    |--------------------------------------------------------------------------
    */

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    /*
    |--------------------------------------------------------------------------
    | Display error
    |--------------------------------------------------------------------------
    */

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Payment Error</title>

        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet"
        >
    </head>

    <body class="bg-light">

    <div class="container py-5">

        <div class="row justify-content-center">

            <div class="col-md-6">

                <div class="card shadow-sm border-0">

                    <div class="card-header bg-danger text-white">
                        <h5 class="mb-0">
                            Payment Error
                        </h5>
                    </div>

                    <div class="card-body">

                        <div class="alert alert-danger">
                            <?= htmlspecialchars($e->getMessage()) ?>
                        </div>

                        <div class="d-flex gap-2">

                            <a
                                href="payment.php?bill_id=<?= $bill_id ?>"
                                class="btn btn-primary"
                            >
                                Try Again
                            </a>

                            <a
                                href="invoice.php?bill_id=<?= $bill_id ?>"
                                class="btn btn-secondary"
                            >
                                Back to Invoice
                            </a>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    </body>
    </html>
    <?php
}
?>