<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

require_permission(billing.create);

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| Get submitted values
|--------------------------------------------------------------------------
*/

$visit_id = isset($_POST['visit_id'])
    ? (int) $_POST['visit_id']
    : 0;

$consultation_fee = isset($_POST['consultation_fee'])
    ? (float) $_POST['consultation_fee']
    : 0;

$other_charges = isset($_POST['other_charges'])
    ? (float) $_POST['other_charges']
    : 0;

$discount = isset($_POST['discount'])
    ? (float) $_POST['discount']
    : 0;

$created_by = isset($_SESSION['user_id'])
    ? (int) $_SESSION['user_id']
    : null;


if ($visit_id <= 0) {
    die("Invalid visit ID.");
}

if ($consultation_fee < 0) {
    die("Invalid consultation fee.");
}

if ($other_charges < 0) {
    die("Invalid other charges.");
}

if ($discount < 0) {
    die("Invalid discount.");
}


try {

    /*
    |--------------------------------------------------------------------------
    | Start transaction
    |--------------------------------------------------------------------------
    */

    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | Verify patient visit
    |--------------------------------------------------------------------------
    */

    $visitStmt = $pdo->prepare("
        SELECT
            visit_id,
            visit_number,
            patient_id,
            status,
            payment_category

        FROM patient_visits

        WHERE visit_id = ?

        LIMIT 1

        FOR UPDATE
    ");

    $visitStmt->execute([$visit_id]);

    $visit = $visitStmt->fetch();

    if (!$visit) {
        throw new Exception(
            "Patient visit was not found."
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Prevent duplicate bills
    |--------------------------------------------------------------------------
    */

    $existingStmt = $pdo->prepare("
        SELECT
            bill_id,
            bill_number,
            bill_status

        FROM bills

        WHERE visit_id = ?

        AND bill_status != 'Cancelled'

        LIMIT 1
    ");

    $existingStmt->execute([$visit_id]);

    $existingBill = $existingStmt->fetch();

    if ($existingBill) {

        throw new Exception(
            "A bill already exists for this visit. "
            . "Bill Number: "
            . $existingBill['bill_number']
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Generate unique bill number
    |--------------------------------------------------------------------------
    */

    $datePart = date('Ymd');

    $bill_number = null;

    for ($i = 1; $i <= 10; $i++) {

        $candidate =
            'INV-'
            . $datePart
            . '-'
            . str_pad(
                (string) $i,
                4,
                '0',
                STR_PAD_LEFT
            );

        $checkNumber = $pdo->prepare("
            SELECT bill_id

            FROM bills

            WHERE bill_number = ?

            LIMIT 1
        ");

        $checkNumber->execute([$candidate]);

        if (!$checkNumber->fetch()) {

            $bill_number = $candidate;

            break;
        }
    }


    if (!$bill_number) {

        /*
         * Fallback to timestamp-based number
         */
        $bill_number =
            'INV-'
            . date('YmdHis')
            . '-'
            . random_int(100, 999);
    }


    /*
    |--------------------------------------------------------------------------
    | Get completed laboratory services
    |--------------------------------------------------------------------------
    */

    $labStmt = $pdo->prepare("
        SELECT

            loi.order_item_id,
            loi.test_price,

            lt.test_code,
            lt.test_name

        FROM laboratory_order_items loi

        INNER JOIN laboratory_orders lo
            ON loi.lab_order_id = lo.lab_order_id

        INNER JOIN laboratory_tests lt
            ON loi.test_id = lt.test_id

        WHERE lo.visit_id = ?

        AND loi.item_status = 'Completed'

        ORDER BY loi.order_item_id ASC
    ");

    $labStmt->execute([$visit_id]);

    $laboratoryTests = $labStmt->fetchAll();


    /*
    |--------------------------------------------------------------------------
    | Get dispensed medicines
    |--------------------------------------------------------------------------
    */

    $medicineStmt = $pdo->prepare("
        SELECT

            pi.prescription_item_id,

            pi.quantity_dispensed,
            pi.dosage,
            pi.frequency,
            pi.duration,
            pi.route,

            m.medicine_id,
            m.medicine_name,
            m.medicine_code,
            m.selling_price

        FROM prescription_items pi

        INNER JOIN prescriptions pr
            ON pi.prescription_id = pr.prescription_id

        INNER JOIN medicines m
            ON pi.medicine_id = m.medicine_id

        WHERE pr.visit_id = ?

        AND pi.item_status = 'Dispensed'

        ORDER BY pi.prescription_item_id ASC
    ");

    $medicineStmt->execute([$visit_id]);

    $medicines = $medicineStmt->fetchAll();


    /*
    |--------------------------------------------------------------------------
    | Calculate service totals
    |--------------------------------------------------------------------------
    */

    $labTotal = 0;

    foreach ($laboratoryTests as $lab) {

        $labTotal +=
            (float) $lab['test_price'];
    }


    $medicineTotal = 0;

    foreach ($medicines as $medicine) {

        $quantity =
            (int) $medicine['quantity_dispensed'];

        $unitPrice =
            (float) $medicine['selling_price'];

        $medicineTotal +=
            $quantity * $unitPrice;
    }


    /*
    |--------------------------------------------------------------------------
    | Calculate subtotal
    |--------------------------------------------------------------------------
    */

    $subtotal =
        $labTotal
        + $medicineTotal
        + $consultation_fee
        + $other_charges;


    /*
    |--------------------------------------------------------------------------
    | Validate discount
    |--------------------------------------------------------------------------
    */

    if ($discount > $subtotal) {
        throw new Exception(
            "Discount cannot be greater than the subtotal."
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Calculate total
    |--------------------------------------------------------------------------
    */

    $total_amount =
        $subtotal - $discount;


    if ($total_amount < 0) {
        $total_amount = 0;
    }


    /*
    |--------------------------------------------------------------------------
    | Initial payment and balance
    |--------------------------------------------------------------------------
    */

    $amount_paid = 0;

    $balance = $total_amount;


    if ($amount_paid <= 0) {

        $bill_status = 'Unpaid';

    } elseif ($amount_paid < $total_amount) {

        $bill_status = 'Partially Paid';

    } else {

        $bill_status = 'Paid';
    }


    /*
    |--------------------------------------------------------------------------
    | Create bill
    |--------------------------------------------------------------------------
    */

    $billStmt = $pdo->prepare("
        INSERT INTO bills
        (
            visit_id,
            bill_number,
            subtotal,
            discount,
            total_amount,
            amount_paid,
            balance,
            bill_status,
            created_by
        )

        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ");

    $billStmt->execute([
        $visit_id,
        $bill_number,
        $subtotal,
        $discount,
        $total_amount,
        $amount_paid,
        $balance,
        $bill_status,
        $created_by
    ]);


    $bill_id =
        (int) $pdo->lastInsertId();


    /*
    |--------------------------------------------------------------------------
    | Bill item insert statement
    |--------------------------------------------------------------------------
    */

    $itemStmt = $pdo->prepare("
        INSERT INTO bill_items
        (
            bill_id,
            item_type,
            description,
            reference_id,
            quantity,
            unit_price,
            total_price
        )

        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | Add laboratory bill items
    |--------------------------------------------------------------------------
    */

    foreach ($laboratoryTests as $lab) {

        $price =
            (float) $lab['test_price'];

        $itemStmt->execute([
            $bill_id,
            'Laboratory',
            $lab['test_name'],
            (int) $lab['order_item_id'],
            1,
            $price,
            $price
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Add medicine bill items
    |--------------------------------------------------------------------------
    */

    foreach ($medicines as $medicine) {

        $quantity =
            (int) $medicine['quantity_dispensed'];

        $unitPrice =
            (float) $medicine['selling_price'];

        $totalPrice =
            $quantity * $unitPrice;


        $description =
            $medicine['medicine_name'];


        if (!empty($medicine['dosage'])) {

            $description .=
                ' - '
                . $medicine['dosage'];
        }


        if (!empty($medicine['frequency'])) {

            $description .=
                ' - '
                . $medicine['frequency'];
        }


        $itemStmt->execute([
            $bill_id,
            'Medicine',
            $description,
            (int) $medicine['prescription_item_id'],
            $quantity,
            $unitPrice,
            $totalPrice
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Add consultation charge
    |--------------------------------------------------------------------------
    */

    if ($consultation_fee > 0) {

        $itemStmt->execute([
            $bill_id,
            'Consultation',
            'Medical consultation',
            null,
            1,
            $consultation_fee,
            $consultation_fee
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Add other charges
    |--------------------------------------------------------------------------
    */

    if ($other_charges > 0) {

        $itemStmt->execute([
            $bill_id,
            'Other',
            'Other hospital services',
            null,
            1,
            $other_charges,
            $other_charges
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Update patient visit
    |--------------------------------------------------------------------------
    |
    | The patient remains in Billing until payment is completed.
    |--------------------------------------------------------------------------
    */

    $visitUpdate = $pdo->prepare("
        UPDATE patient_visits

        SET status = 'Billing'

        WHERE visit_id = ?
    ");

    $visitUpdate->execute([
        $visit_id
    ]);


    /*
    |--------------------------------------------------------------------------
    | Commit transaction
    |--------------------------------------------------------------------------
    */

    $pdo->commit();


    /*
    |--------------------------------------------------------------------------
    | Redirect to invoice
    |--------------------------------------------------------------------------
    */

    header(
        "Location: invoice.php?bill_id="
        . $bill_id
    );

    exit();


} catch (Exception $e) {


    /*
    |--------------------------------------------------------------------------
    | Rollback transaction
    |--------------------------------------------------------------------------
    */

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }


    ?>

    <!DOCTYPE html>

    <html lang="en">

    <head>

        <meta charset="UTF-8">

        <title>Billing Error</title>

        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet"
        >

    </head>


    <body class="bg-light">


    <div class="container mt-5">

        <div class="card shadow">

            <div class="card-header bg-danger text-white">

                <h4 class="mb-0">
                    Billing Error
                </h4>

            </div>


            <div class="card-body">

                <div class="alert alert-danger">

                    <?= htmlspecialchars(
                        $e->getMessage()
                    ) ?>

                </div>


                <a
                    href="create_bill.php?visit_id=<?= $visit_id ?>"
                    class="btn btn-primary"
                >
                    ← Return to Bill
                </a>


                <a
                    href="index.php"
                    class="btn btn-secondary"
                >
                    Billing Queue
                </a>

            </div>

        </div>

    </div>


    </body>

    </html>

    <?php
}
?>