<?php
require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/auth.php';require_login();
$vid=(int)($_POST['visit_id']??0);$pdo->beginTransaction();
try{
 $p=$pdo->prepare("SELECT patient_id FROM patient_visits WHERE id=?");$p->execute([$vid]);$pid=(int)$p->fetchColumn();
 $invoice='INV'.date('YmdHis').random_int(100,999);$amounts=array_map('floatval',$_POST['amount']??[]);$subtotal=array_sum($amounts);$discount=max(0,(float)($_POST['discount']??0));$patient=max(0,$subtotal-$discount);
 $pdo->prepare("INSERT INTO invoices(invoice_no,visit_id,patient_id,subtotal,discount,patient_amount,balance,created_by) VALUES(?,?,?,?,?,?,?,?)")->execute([$invoice,$vid,$pid,$subtotal,$discount,$patient,$patient,$_SESSION['user_id']]);$iid=(int)$pdo->lastInsertId();
 $ins=$pdo->prepare("INSERT INTO invoice_items(invoice_id,service_type,reference_id,description,quantity,unit_price,amount) VALUES(?,?,?,?,1,?,?)");
 foreach($amounts as $i=>$a)$ins->execute([$iid,$_POST['service_type'][$i],($_POST['reference_id'][$i]??'')?:null,$_POST['description'][$i],$a,$a]);
 $pdo->prepare("UPDATE patient_visits SET status='Billing' WHERE id=?")->execute([$vid]);
 $pdo->commit();header('Location: invoice.php?id='.$iid);exit;
}catch(Throwable $e){$pdo->rollBack();http_response_code(500);exit('Could not create invoice: '.$e->getMessage());}