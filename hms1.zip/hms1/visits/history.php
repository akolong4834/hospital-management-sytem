<?php
$page_title='Visit History';require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$id=(int)($_GET['patient_id']??0);$s=$pdo->prepare("SELECT * FROM patients WHERE patient_id=?");$s->execute([$id]);$p=$s->fetch();if(!$p)die('Patient not found.');
$s=$pdo->prepare("SELECT * FROM patient_visits WHERE patient_id=? ORDER BY visit_id DESC");$s->execute([$id]);$vs=$s->fetchAll();
?>
<h2>Visit History</h2><p class="text-muted"><?=htmlspecialchars(trim($p['first_name'].' '.$p['middle_name'].' '.$p['last_name']))?> — <?=htmlspecialchars($p['patient_number'])?></p>
<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Visit</th><th>Date</th><th>Type</th><th>Department</th><th>Complaint</th><th>Status</th></tr></thead><tbody>
<?php foreach($vs as $v):?><tr><td><?=htmlspecialchars($v['visit_number'])?></td><td><?=htmlspecialchars($v['visit_date'])?></td><td><?=htmlspecialchars($v['visit_type'])?></td><td><?=htmlspecialchars($v['department'])?></td><td><?=htmlspecialchars($v['chief_complaint'])?></td><td><span class="badge bg-secondary"><?=htmlspecialchars($v['status'])?></span></td></tr><?php endforeach;?>
<?php if(!$vs):?><tr><td colspan="6" class="text-center py-4">No visits found.</td></tr><?php endif;?></tbody></table></div></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>