<?php
$page_title='Start New Visit';require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$id=(int)($_GET['patient_id']??0);$s=$pdo->prepare("SELECT * FROM patients WHERE patient_id=?");$s->execute([$id]);$p=$s->fetch();
if(!$p){echo '<div class="alert alert-danger">Patient not found.</div>';require_once __DIR__.'/../includes/footer.php';exit;}
?>
<h2>Start New Visit</h2><div class="card shadow-sm"><div class="card-body"><div class="alert alert-info"><strong><?=htmlspecialchars($p['patient_number'])?></strong> — <?=htmlspecialchars(trim($p['first_name'].' '.$p['middle_name'].' '.$p['last_name']))?></div>
<form method="post" action="save.php"><input type="hidden" name="patient_id" value="<?=$id?>"><div class="row g-3">
<div class="col-md-4"><label class="form-label">Visit Type *</label><select name="visit_type" class="form-select"><option>Outpatient</option><option>Emergency</option><option>Review</option></select></div>
<div class="col-md-4"><label class="form-label">Department / Clinic</label><select name="department" class="form-select"><option>General Outpatient</option><option>Maternal & Child Health</option><option>Eye / Optical</option><option>Dental</option><option>Emergency</option></select></div>
<div class="col-md-4"><label class="form-label">Payment Category</label><select name="payment_category" class="form-select"><option>Cash</option><option>Insurance / SHA</option><option>Corporate</option><option>Credit</option></select></div>
<div class="col-12"><label class="form-label">Chief Complaint / Reason for Visit</label><textarea name="chief_complaint" rows="4" class="form-control"></textarea></div>
</div><div class="mt-4 text-end"><a href="../patients/view.php?id=<?=$id?>" class="btn btn-secondary">Cancel</a> <button class="btn btn-success">Start Visit & Send to Triage</button></div></form>
</div></div><?php require_once __DIR__.'/../includes/footer.php'; ?>