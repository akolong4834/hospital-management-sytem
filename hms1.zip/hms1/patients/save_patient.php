<?php
require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/auth.php';require_login();
function p($k){$v=trim($_POST[$k]??'');return $v===''?null:$v;}
$no='PT'.date('YmdHis').random_int(100,999);
$s=$pdo->prepare("INSERT INTO patients(patient_no,first_name,middle_name,last_name,date_of_birth,gender,national_id,phone,email,address,county,next_of_kin_name,next_of_kin_phone,blood_group,insurance_provider,insurance_member_no,sha_member_no,allergies,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
try{$s->execute([$no,p('first_name'),p('middle_name'),p('last_name'),p('date_of_birth'),p('gender'),p('national_id'),p('phone'),p('email'),p('address'),p('county'),p('next_of_kin_name'),p('next_of_kin_phone'),p('blood_group'),p('insurance_provider'),p('insurance_member_no'),p('sha_member_no'),p('allergies'),$_SESSION['user_id']]);header('Location: register.php?success=1&patient_no='.urlencode($no));exit;}catch(PDOException $e){http_response_code(400);exit('Could not register patient. Check duplicate National ID and required fields.');}
?>