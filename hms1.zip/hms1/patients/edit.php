<?php
$page_title='Edit Patient';require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$id=(int)($_GET['id']??0);$s=$pdo->prepare("SELECT * FROM patients WHERE patient_id=?");$s->execute([$id]);$p=$s->fetch();
if(!$p){echo '<div class="alert alert-danger">Patient not found.</div>';require_once __DIR__.'/../includes/footer.php';exit;}
?>
<h2>Edit Patient</h2><form method="post" action="update.php" class="card shadow-sm"><input type="hidden" name="patient_id" value="<?=$id?>"><div class="card-body"><div class="row g-3">
<?php foreach([['first_name','First Name','required'],['middle_name','Middle Name',''],['last_name','Last Name','required'],['id_number','ID / Passport',''],['phone','Phone','required'],['email','Email',''],['county','County',''],['sub_county','Sub-County',''],['village','Village / Estate',''],['occupation','Occupation',''],['next_of_kin_name','Next of Kin',''],['next_of_kin_relationship','Relationship',''],['next_of_kin_phone','Next of Kin Phone',''],['blood_group','Blood Group',''],['allergies','Allergies','']] as $f):?><div class="col-md-4"><label class="form-label"><?=$f[1]?></label><input name="<?=$f[0]?>" class="form-control" <?=$f[2]?> value="<?=htmlspecialchars($p[$f[0]]??'')?>"></div><?php endforeach;?>
<div class="col-md-3"><label class="form-label">Gender</label><select name="gender" class="form-select"><?php foreach(['Male','Female','Other'] as $g):?><option <?=$p['gender']===$g?'selected':''?>><?=$g?></option><?php endforeach;?></select></div>
<div class="col-md-3"><label class="form-label">Date of Birth</label><input type="date" name="date_of_birth" class="form-control" required value="<?=htmlspecialchars($p['date_of_birth'])?>"></div>
<div class="col-12"><label class="form-label">Emergency Contact / Notes</label><textarea name="emergency_contact" rows="3" class="form-control"><?=htmlspecialchars($p['emergency_contact']??'')?></textarea></div>
</div></div><div class="card-footer text-end"><a href="view.php?id=<?=$id?>" class="btn btn-secondary">Cancel</a> <button class="btn btn-primary">Save Changes</button></div></form>
<?php require_once __DIR__.'/../includes/footer.php'; ?>