<?php
$page_title='Patient Search';require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$q=trim($_GET['q']??'');$patients=[];
if($q!==''){ $x='%'.$q.'%';$s=$pdo->prepare("SELECT * FROM patients WHERE patient_number LIKE ? OR first_name LIKE ? OR middle_name LIKE ? OR last_name LIKE ? OR phone LIKE ? OR id_number LIKE ? ORDER BY patient_id DESC LIMIT 100");$s->execute([$x,$x,$x,$x,$x,$x]);$patients=$s->fetchAll();}
?>
<div class="d-flex justify-content-between align-items-center mb-4"><h2>Patient Search</h2><a href="register.php" class="btn btn-primary">+ Register Patient</a></div>
<form class="card card-body shadow-sm mb-4" method="get"><div class="input-group"><input name="q" class="form-control" placeholder="Patient No., name, phone or ID" value="<?=htmlspecialchars($q)?>"><button class="btn btn-primary">Search</button></div></form>
<?php if($q!==''): ?><div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover mb-0"><thead><tr><th>Patient No.</th><th>Name</th><th>Gender</th><th>DOB</th><th>Phone</th><th></th></tr></thead><tbody>
<?php if(!$patients):?><tr><td colspan="6" class="text-center py-4">No patients found.</td></tr><?php else: foreach($patients as $p):?><tr><td><?=htmlspecialchars($p['patient_number'])?></td><td><?=htmlspecialchars(trim($p['first_name'].' '.$p['middle_name'].' '.$p['last_name']))?></td><td><?=htmlspecialchars($p['gender'])?></td><td><?=htmlspecialchars($p['date_of_birth'])?></td><td><?=htmlspecialchars($p['phone'])?></td><td><a class="btn btn-sm btn-outline-primary" href="view.php?id=<?=$p['patient_id']?>">View</a></td></tr><?php endforeach;endif;?>
</tbody></table></div></div><?php endif;?>
<?php require_once __DIR__.'/../includes/footer.php'; ?>