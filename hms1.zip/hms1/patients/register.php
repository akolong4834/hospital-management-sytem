<?php
$page_title='Patient Registration'; require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/header.php';
$errors=$_SESSION['patient_errors']??[]; $old=$_SESSION['patient_old']??[]; unset($_SESSION['patient_errors'],$_SESSION['patient_old']);
?>
<div class="d-flex justify-content-between align-items-center mb-4"><div><h2>Patient Registration</h2><p class="text-muted">Register a new patient.</p></div><a href="search.php" class="btn btn-outline-primary">Search Patients</a></div>
<?php if($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e): ?><li><?=htmlspecialchars($e)?></li><?php endforeach;?></ul></div><?php endif;?>
<form method="post" action="save.php" class="card shadow-sm"><div class="card-body">
<h5>Personal Details</h5><div class="row g-3">
<?php
$inputs=[
['first_name','First Name *','required'],['middle_name','Middle Name',''],['last_name','Last Name *','required'],
['id_number','ID / Passport No.',''],['phone','Phone Number *','required'],['email','Email',''],
['county','County',''],['sub_county','Sub-County',''],['village','Village / Estate',''],['occupation','Occupation','']
];
foreach($inputs as $i): ?><div class="col-md-4"><label class="form-label"><?=$i[1]?></label><input type="<?=$i[0]==='email'?'email':'text'?>" name="<?=$i[0]?>" class="form-control" <?=$i[2]?> value="<?=htmlspecialchars($old[$i[0]]??'')?>"></div><?php endforeach;?>
<div class="col-md-3"><label class="form-label">Gender *</label><select name="gender" class="form-select" required><option value="">Select</option><?php foreach(['Male','Female','Other'] as $g): ?><option value="<?=$g?>" <?=($old['gender']??'')===$g?'selected':''?>><?=$g?></option><?php endforeach;?></select></div>
<div class="col-md-3"><label class="form-label">Date of Birth *</label><input type="date" name="date_of_birth" class="form-control" required value="<?=htmlspecialchars($old['date_of_birth']??'')?>"></div>
</div>
<hr><h5>Next of Kin</h5><div class="row g-3">
<?php foreach([['next_of_kin_name','Name'],['next_of_kin_relationship','Relationship'],['next_of_kin_phone','Phone']] as $i): ?><div class="col-md-4"><label class="form-label"><?=$i[1]?></label><input name="<?=$i[0]?>" class="form-control" value="<?=htmlspecialchars($old[$i[0]]??'')?>"></div><?php endforeach;?>
</div><hr><h5>Medical Information</h5><div class="row g-3">
<div class="col-md-3"><label class="form-label">Blood Group</label><select name="blood_group" class="form-select"><option value="">Select</option><?php foreach(['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $b): ?><option <?=$old['blood_group']??''===$b?'selected':''?>><?=$b?></option><?php endforeach;?></select></div>
<div class="col-md-9"><label class="form-label">Allergies</label><input name="allergies" class="form-control" value="<?=htmlspecialchars($old['allergies']??'')?>"></div>
<div class="col-12"><label class="form-label">Emergency Contact / Notes</label><textarea name="emergency_contact" class="form-control" rows="3"><?=htmlspecialchars($old['emergency_contact']??'')?></textarea></div>
</div></div><div class="card-footer text-end"><button class="btn btn-secondary" type="reset">Reset</button> <button class="btn btn-primary">Register Patient</button></div></form>
<?php require_once __DIR__.'/../includes/footer.php'; ?>