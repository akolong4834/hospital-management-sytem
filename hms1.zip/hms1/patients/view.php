<?php
$page_title='Patient Profile';require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$id=(int)($_GET['id']??0);$s=$pdo->prepare("SELECT * FROM patients WHERE patient_id=?");$s->execute([$id]);$p=$s->fetch();
if(!$p){echo '<div class="alert alert-danger">Patient not found.</div>';require_once __DIR__.'/../includes/footer.php';exit;}
$s=$pdo->prepare("SELECT * FROM patient_visits WHERE patient_id=? ORDER BY visit_id DESC");$s->execute([$id]);$visits=$s->fetchAll();
$success=$_SESSION['success']??'';unset($_SESSION['success']);
?>
<?php if($success):?><div class="alert alert-success"><?=htmlspecialchars($success)?></div><?php endif;?>
<div class="d-flex justify-content-between align-items-center mb-4"><div><h2><?=htmlspecialchars(trim($p['first_name'].' '.$p['middle_name'].' '.$p['last_name']))?></h2><div class="text-muted">Patient No: <strong><?=htmlspecialchars($p['patient_number'])?></strong></div></div><div><a href="search.php" class="btn btn-outline-secondary">Search</a> <a href="edit.php?id=<?=$id?>" class="btn btn-outline-primary">Edit</a> <a href="../visits/new.php?patient_id=<?=$id?>" class="btn btn-success">Start New Visit</a></div></div>
<div class="row g-4"><div class="col-lg-7"><div class="card shadow-sm"><div class="card-header fw-bold">Patient Information</div><div class="card-body"><div class="row g-3">
<?php foreach([['Gender','gender'],['Date of Birth','date_of_birth'],['ID/Passport','id_number'],['Phone','phone'],['Email','email'],['Blood Group','blood_group'],['County','county'],['Sub-County','sub_county'],['Village/Estate','village'],['Occupation','occupation'],['Allergies','allergies']] as $f):?><div class="col-md-6"><strong><?=$f[0]?>:</strong><br><?=htmlspecialchars($p[$f[1]]??'')?></div><?php endforeach;?>
<div class="col-md-6"><strong>Next of Kin:</strong><br><?=htmlspecialchars($p['next_of_kin_name']??'')?> (<?=htmlspecialchars($p['next_of_kin_relationship']??'')?>)</div><div class="col-md-6"><strong>Next of Kin Phone:</strong><br><?=htmlspecialchars($p['next_of_kin_phone']??'')?></div><div class="col-12"><strong>Emergency Contact / Notes:</strong><br><?=nl2br(htmlspecialchars($p['emergency_contact']??''))?></div>
</div></div></div></div><div class="col-lg-5"><div class="card shadow-sm"><div class="card-header fw-bold">Visit History</div><div class="table-responsive"><table class="table table-sm mb-0"><thead><tr><th>Visit</th><th>Date</th><th>Status</th></tr></thead><tbody>
<?php if(!$visits):?><tr><td colspan="3" class="text-center py-4">No visits yet.</td></tr><?php else:foreach($visits as $v):?><tr><td><?=htmlspecialchars($v['visit_number'])?></td><td><?=htmlspecialchars($v['visit_date'])?></td><td><span class="badge bg-secondary"><?=htmlspecialchars($v['status'])?></span></td></tr><?php endforeach;endif;?>
</tbody></table></div></div></div></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>