<?php
require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/auth.php'; check_authentication();
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: register.php');exit;}
$fields=['first_name','middle_name','last_name','gender','date_of_birth','id_number','phone','email','county','sub_county','village','occupation','next_of_kin_name','next_of_kin_relationship','next_of_kin_phone','blood_group','allergies','emergency_contact'];
$data=[]; foreach($fields as $f)$data[$f]=trim($_POST[$f]??'');
$errors=[];
foreach(['first_name'=>'First name','last_name'=>'Last name','gender'=>'Gender','date_of_birth'=>'Date of birth','phone'=>'Phone number'] as $f=>$label) if($data[$f]==='')$errors[]="$label is required.";
if($data['email']!==''&&!filter_var($data['email'],FILTER_VALIDATE_EMAIL))$errors[]='Invalid email address.';
if($data['id_number']!==''){ $s=$pdo->prepare("SELECT patient_id FROM patients WHERE id_number=? LIMIT 1");$s->execute([$data['id_number']]);if($s->fetch())$errors[]='ID / Passport number already exists.'; }
if($errors){$_SESSION['patient_errors']=$errors;$_SESSION['patient_old']=$data;header('Location: register.php');exit;}
try{
$pdo->beginTransaction();
$s=$pdo->prepare("INSERT INTO patients(first_name,middle_name,last_name,gender,date_of_birth,id_number,phone,email,county,sub_county,village,occupation,next_of_kin_name,next_of_kin_relationship,next_of_kin_phone,blood_group,allergies,emergency_contact,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())");
$s->execute([$data['first_name'],$data['middle_name'],$data['last_name'],$data['gender'],$data['date_of_birth'],$data['id_number']?:null,$data['phone'],$data['email']?:null,$data['county'],$data['sub_county'],$data['village'],$data['occupation'],$data['next_of_kin_name'],$data['next_of_kin_relationship'],$data['next_of_kin_phone'],$data['blood_group'],$data['allergies'],$data['emergency_contact']]);
$id=(int)$pdo->lastInsertId();$no='PT-'.date('Y').'-'.str_pad((string)$id,5,'0',STR_PAD_LEFT);
$pdo->prepare("UPDATE patients SET patient_number=? WHERE patient_id=?")->execute([$no,$id]);$pdo->commit();
$_SESSION['success']="Patient registered successfully. Patient Number: $no";header("Location: view.php?id=$id");exit;
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$_SESSION['patient_errors']=['Unable to register patient: '.$e->getMessage()];$_SESSION['patient_old']=$data;header('Location: register.php');exit;}
?>