<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

check_authentication();

$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.chief_complaint,
        v.status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,

        c.consultation_id,
        c.diagnosis,
        c.investigations_requested

    FROM patient_visits v

    INNER JOIN patients p
        ON p.patient_id = v.patient_id

    INNER JOIN consultations c
        ON c.visit_id = v.visit_id

    WHERE c.consultation_status = 'Completed'

    AND (
        c.investigations_requested IS NOT NULL
        AND TRIM(c.investigations_requested) <> ''
    )

    ORDER BY v.visit_id ASC
";

$stmt = $pdo->query($sql);
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<?php require_once __DIR__ . '/../includes/header.php'; ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>
            <h2>Laboratory Queue</h2>

            <p class="text-muted">
                Patients requiring laboratory investigations
            </p>
        </div>

        <span class="badge bg-primary fs-6">
            <?= count($patients); ?> Patient(s)
        </span>

    </div>


    <?php if (isset($_GET['saved'])): ?>

        <div class="alert alert-success">
            Laboratory order created successfully.
        </div>

    <?php endif; ?>


    <?php if (isset($_GET['result_saved'])): ?>

        <div class="alert alert-success">
            Laboratory result saved successfully.
        </div>

    <?php endif; ?>


    <div class="card shadow-sm">

        <div class="card-header bg-primary text-white">
            <strong>Laboratory Patients</strong>
        </div>

        <div class="card-body">

            <?php if (empty($patients)): ?>

                <div class="alert alert-info">
                    No patients are currently waiting for laboratory
                    investigations.
                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-light">

                            <tr>

                                <th>#</th>

                                <th>Visit No.</th>

                                <th>Patient</th>

                                <th>Gender</th>

                                <th>Chief Complaint</th>

                                <th>Diagnosis</th>

                                <th>Investigations Requested</th>

                                <th>Action</th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($patients as $index => $patient): ?>

                            <?php

                            $fullName = trim(
                                $patient['first_name'] . ' ' .
                                ($patient['middle_name'] ?? '') . ' ' .
                                $patient['last_name']
                            );

                            ?>

                            <tr>

                                <td>
                                    <?= $index + 1; ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= htmlspecialchars(
                                            $patient['visit_number'] ?? ''
                                        ); ?>
                                    </strong>
                                </td>

                                <td>

                                    <strong>
                                        <?= htmlspecialchars($fullName); ?>
                                    </strong>

                                    <br>

                                    <small class="text-muted">
                                        <?= htmlspecialchars(
                                            $patient['patient_number'] ?? ''
                                        ); ?>
                                    </small>

                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['gender']
                                    ); ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['chief_complaint'] ?? ''
                                    ); ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['diagnosis'] ?? ''
                                    ); ?>
                                </td>

                                <td>

                                    <?= nl2br(
                                        htmlspecialchars(
                                            $patient['investigations_requested']
                                        )
                                    ); ?>

                                </td>

                                <td>

                                    <a
                                        href="order.php?visit_id=<?= (int)$patient['visit_id']; ?>"
                                        class="btn btn-primary btn-sm"
                                    >
                                        Create Lab Order
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>