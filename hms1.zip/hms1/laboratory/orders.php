<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

/*
|--------------------------------------------------------------------------
| Get Laboratory Orders
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        lo.lab_order_id,
        lo.visit_id,
        lo.order_status,
        lo.ordered_at,
        lo.completed_at,

        v.visit_number,
        v.visit_date,
        v.department,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.phone

    FROM laboratory_orders lo

    INNER JOIN patient_visits v
        ON lo.visit_id = v.visit_id

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    ORDER BY lo.ordered_at DESC
";

$stmt = $pdo->query($sql);

$orders = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Laboratory Orders</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #f1f3f5;
        }

        .status {
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
        }

        .ordered {
            background: #fff3cd;
            color: #856404;
        }

        .processing {
            background: #cfe2ff;
            color: #084298;
        }

        .completed {
            background: #d1e7dd;
            color: #0f5132;
        }

        .cancelled {
            background: #f8d7da;
            color: #842029;
        }

        .btn {
            display: inline-block;
            padding: 8px 14px;
            background: #0d6efd;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .btn:hover {
            background: #0b5ed7;
        }

        .back {
            background: #6c757d;
            margin-bottom: 15px;
        }

        @media(max-width: 800px) {

            table {
                display: block;
                overflow-x: auto;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <div class="card">

        <h1>Laboratory Orders</h1>

        <a href="queue.php" class="btn back">
            ← Laboratory Queue
        </a>

        <?php if (empty($orders)): ?>

            <p>No laboratory orders found.</p>

        <?php else: ?>

            <table>

                <thead>

                    <tr>

                        <th>#</th>

                        <th>Order</th>

                        <th>Patient Number</th>

                        <th>Patient Name</th>

                        <th>Visit Number</th>

                        <th>Visit Date</th>

                        <th>Department</th>

                        <th>Status</th>

                        <th>Action</th>

                    </tr>

                </thead>

                <tbody>

                <?php foreach ($orders as $index => $order): ?>

                    <?php

                    $patient_name = trim(
                        $order['first_name'] . ' ' .
                        $order['middle_name'] . ' ' .
                        $order['last_name']
                    );

                    $status_class = strtolower(
                        $order['order_status']
                    );

                    ?>

                    <tr>

                        <td>
                            <?= $index + 1 ?>
                        </td>

                        <td>
                            LAB-<?= htmlspecialchars(
                                $order['lab_order_id']
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $order['patient_number']
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $patient_name
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $order['visit_number']
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $order['visit_date']
                            ) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars(
                                $order['department'] ?? ''
                            ) ?>
                        </td>

                        <td>

                            <span class="status <?= $status_class ?>">

                                <?= htmlspecialchars(
                                    $order['order_status']
                                ) ?>

                            </span>

                        </td>

                        <td>

                            <a
                                href="processing.php?lab_order_id=<?= $order['lab_order_id'] ?>"
                                class="btn"
                            >
                                Process

                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        <?php endif; ?>

    </div>

</div>

</body>

</html>