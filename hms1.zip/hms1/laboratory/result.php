<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

$order_item_id = isset($_GET['order_item_id'])
    ? (int)$_GET['order_item_id']
    : 0;

if ($order_item_id <= 0) {
    die("Invalid laboratory order item.");
}

/*
|--------------------------------------------------------------------------
| Get laboratory item and automatically determine laboratory order
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare("
    SELECT
        loi.order_item_id,
        loi.lab_order_id,
        loi.test_id,
        loi.test_price,
        loi.item_status,
        loi.result,
        loi.result_unit,
        loi.reference_range,
        loi.result_notes,

        lt.test_code,
        lt.test_name,
        lt.category,
        lt.specimen_type,

        lo.visit_id,
        lo.order_status,

        v.visit_number,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth

    FROM laboratory_order_items loi

    INNER JOIN laboratory_tests lt
        ON loi.test_id = lt.test_id

    INNER JOIN laboratory_orders lo
        ON loi.lab_order_id = lo.lab_order_id

    INNER JOIN patient_visits v
        ON lo.visit_id = v.visit_id

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    WHERE loi.order_item_id = ?

    LIMIT 1
");

$stmt->execute([$order_item_id]);

$item = $stmt->fetch();

if (!$item) {
    die("Invalid laboratory order: Laboratory test could not be found.");
}

/*
|--------------------------------------------------------------------------
| Get laboratory order ID from database
|--------------------------------------------------------------------------
*/
$lab_order_id = (int)$item['lab_order_id'];

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>Laboratory Result</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

</head>

<body>

<div class="container mt-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <h3>Laboratory Result</h3>

        <a
            href="processing.php?lab_order_id=<?php echo $lab_order_id; ?>"
            class="btn btn-secondary"
        >
            Back to Processing
        </a>

    </div>


    <!-- Patient Information -->

    <div class="card mb-4">

        <div class="card-header bg-primary text-white">
            Patient Information
        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-4">

                    <strong>Patient Number</strong><br>

                    <?php
                    echo htmlspecialchars($item['patient_number']);
                    ?>

                </div>

                <div class="col-md-4">

                    <strong>Patient Name</strong><br>

                    <?php
                    echo htmlspecialchars(
                        trim(
                            $item['first_name'] . ' ' .
                            $item['middle_name'] . ' ' .
                            $item['last_name']
                        )
                    );
                    ?>

                </div>

                <div class="col-md-4">

                    <strong>Visit Number</strong><br>

                    <?php
                    echo htmlspecialchars($item['visit_number']);
                    ?>

                </div>

            </div>

        </div>

    </div>


    <!-- Laboratory Test -->

    <div class="card mb-4">

        <div class="card-header bg-info text-white">
            Laboratory Test
        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-3">

                    <strong>Test Code</strong><br>

                    <?php
                    echo htmlspecialchars($item['test_code']);
                    ?>

                </div>

                <div class="col-md-3">

                    <strong>Test Name</strong><br>

                    <?php
                    echo htmlspecialchars($item['test_name']);
                    ?>

                </div>

                <div class="col-md-3">

                    <strong>Specimen</strong><br>

                    <?php
                    echo htmlspecialchars($item['specimen_type']);
                    ?>

                </div>

                <div class="col-md-3">

                    <strong>Status</strong><br>

                    <?php
                    echo htmlspecialchars($item['item_status']);
                    ?>

                </div>

            </div>

        </div>

    </div>


    <!-- Result Form -->

    <div class="card">

        <div class="card-header">
            Enter Laboratory Result
        </div>

        <div class="card-body">

            <form method="POST" action="save_result.php">

                <!-- Laboratory order -->

                <input
                    type="hidden"
                    name="lab_order_id"
                    value="<?php echo $lab_order_id; ?>"
                >

                <!-- Laboratory order item -->

                <input
                    type="hidden"
                    name="order_item_id"
                    value="<?php echo (int)$item['order_item_id']; ?>"
                >


                <div class="mb-3">

                    <label class="form-label">
                        Result
                    </label>

                    <textarea
                        name="result"
                        class="form-control"
                        rows="5"
                        required
                    ><?php
                    echo htmlspecialchars(
                        $item['result'] ?? ''
                    );
                    ?></textarea>

                </div>


                <div class="row">

                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Result Unit
                        </label>

                        <input
                            type="text"
                            name="result_unit"
                            class="form-control"
                            value="<?php
                            echo htmlspecialchars(
                                $item['result_unit'] ?? ''
                            );
                            ?>"
                        >

                    </div>


                    <div class="col-md-6 mb-3">

                        <label class="form-label">
                            Reference Range
                        </label>

                        <input
                            type="text"
                            name="reference_range"
                            class="form-control"
                            value="<?php
                            echo htmlspecialchars(
                                $item['reference_range'] ?? ''
                            );
                            ?>"
                        >

                    </div>

                </div>


                <div class="mb-3">

                    <label class="form-label">
                        Result Notes
                    </label>

                    <textarea
                        name="result_notes"
                        class="form-control"
                        rows="3"
                    ><?php
                    echo htmlspecialchars(
                        $item['result_notes'] ?? ''
                    );
                    ?></textarea>

                </div>


                <button
                    type="submit"
                    class="btn btn-success"
                >
                    Save Laboratory Result
                </button>

                <a
                    href="processing.php?lab_order_id=<?php echo $lab_order_id; ?>"
                    class="btn btn-secondary"
                >
                    Cancel
                </a>

            </form>

        </div>

    </div>

</div>

</body>
</html>