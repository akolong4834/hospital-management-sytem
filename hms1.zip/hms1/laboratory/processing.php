<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

if (!isset($_GET['lab_order_id']) || !is_numeric($_GET['lab_order_id'])) {
    die("Invalid laboratory order.");
}

$lab_order_id = (int) $_GET['lab_order_id'];

/*
|--------------------------------------------------------------------------
| Get Laboratory Order
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        lo.lab_order_id,
        lo.visit_id,
        lo.ordered_by,
        lo.clinical_notes,
        lo.order_status,
        lo.ordered_at,
        lo.completed_at,

        v.visit_number,
        v.visit_date,
        v.department,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone

    FROM laboratory_orders lo

    INNER JOIN patient_visits v
        ON lo.visit_id = v.visit_id

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    WHERE lo.lab_order_id = ?

    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$lab_order_id]);

$order = $stmt->fetch();

if (!$order) {
    die("Laboratory order not found.");
}

/*
|--------------------------------------------------------------------------
| Get Ordered Tests
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        loi.order_item_id,
        loi.lab_order_id,
        loi.test_id,
        loi.test_price,
        loi.item_status,
        loi.result,
        loi.result_unit,
        loi.reference_range,
        loi.result_notes,
        loi.performed_at,

        lt.test_code,
        lt.test_name,
        lt.category,
        lt.specimen_type

    FROM laboratory_order_items loi

    INNER JOIN laboratory_tests lt
        ON loi.test_id = lt.test_id

    WHERE loi.lab_order_id = ?

    ORDER BY loi.order_item_id ASC
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$lab_order_id]);

$tests = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Count Test Statuses
|--------------------------------------------------------------------------
*/

$total_tests = count($tests);

$completed_tests = 0;
$pending_tests = 0;

foreach ($tests as $test) {

    if ($test['item_status'] === 'Completed') {
        $completed_tests++;
    } else {
        $pending_tests++;
    }
}

/*
|--------------------------------------------------------------------------
| Automatically change Ordered → Processing
|--------------------------------------------------------------------------
*/

if ($order['order_status'] === 'Ordered') {

    $stmt = $pdo->prepare("
        UPDATE laboratory_orders
        SET order_status = 'Processing'
        WHERE lab_order_id = ?
    ");

    $stmt->execute([$lab_order_id]);

    $order['order_status'] = 'Processing';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Laboratory Processing</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        .card {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
            color: #1f2937;
        }

        h2 {
            color: #374151;
        }

        .patient-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .info {
            padding: 10px;
            background: #f9fafb;
            border-radius: 5px;
        }

        .info strong {
            display: block;
            color: #555;
            margin-bottom: 4px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #f3f4f6;
        }

        .status {
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
        }

        .ordered {
            background: #fff3cd;
            color: #856404;
        }

        .processing {
            background: #cfe2ff;
            color: #084298;
        }

        .completed {
            background: #d1e7dd;
            color: #0f5132;
        }

        .cancelled {
            background: #f8d7da;
            color: #842029;
        }

        .btn {
            display: inline-block;
            padding: 8px 14px;
            text-decoration: none;
            border-radius: 5px;
            color: white;
            background: #0d6efd;
        }

        .btn:hover {
            background: #0b5ed7;
        }

        .btn-secondary {
            background: #6c757d;
        }

        .summary {
            display: flex;
            gap: 20px;
            margin-top: 15px;
        }

        .summary-box {
            padding: 15px 25px;
            background: #f8f9fa;
            border-radius: 6px;
            text-align: center;
        }

        .summary-box strong {
            font-size: 24px;
            display: block;
        }

        @media(max-width: 800px) {

            .patient-grid {
                grid-template-columns: 1fr;
            }

            table {
                font-size: 13px;
            }

        }

    </style>

</head>

<body>

<div class="container">

    <div class="card">

        <h1>Laboratory Processing</h1>

        <a href="queue.php" class="btn btn-secondary">
            ← Laboratory Queue
        </a>

    </div>


    <!-- PATIENT INFORMATION -->

    <div class="card">

        <h2>Patient Information</h2>

        <div class="patient-grid">

            <div class="info">
                <strong>Patient Number</strong>
                <?= htmlspecialchars($order['patient_number']) ?>
            </div>

            <div class="info">
                <strong>Patient Name</strong>
                <?= htmlspecialchars(
                    trim(
                        $order['first_name'] . ' ' .
                        $order['middle_name'] . ' ' .
                        $order['last_name']
                    )
                ) ?>
            </div>

            <div class="info">
                <strong>Gender</strong>
                <?= htmlspecialchars($order['gender']) ?>
            </div>

            <div class="info">
                <strong>Date of Birth</strong>
                <?= htmlspecialchars($order['date_of_birth']) ?>
            </div>

            <div class="info">
                <strong>Phone</strong>
                <?= htmlspecialchars($order['phone']) ?>
            </div>

            <div class="info">
                <strong>Visit Number</strong>
                <?= htmlspecialchars($order['visit_number']) ?>
            </div>

        </div>

    </div>


    <!-- ORDER INFORMATION -->

    <div class="card">

        <h2>Laboratory Order</h2>

        <div class="patient-grid">

            <div class="info">
                <strong>Order ID</strong>
                LAB-<?= htmlspecialchars($order['lab_order_id']) ?>
            </div>

            <div class="info">
                <strong>Order Date</strong>
                <?= htmlspecialchars($order['ordered_at']) ?>
            </div>

            <div class="info">
                <strong>Order Status</strong>

                <span class="status processing">
                    <?= htmlspecialchars($order['order_status']) ?>
                </span>

            </div>

        </div>

        <?php if (!empty($order['clinical_notes'])): ?>

            <div style="margin-top:20px;">

                <strong>Clinical Notes / Investigations Requested</strong>

                <p>
                    <?= nl2br(htmlspecialchars($order['clinical_notes'])) ?>
                </p>

            </div>

        <?php endif; ?>


        <div class="summary">

            <div class="summary-box">

                <strong><?= $total_tests ?></strong>

                Total Tests

            </div>

            <div class="summary-box">

                <strong><?= $completed_tests ?></strong>

                Completed

            </div>

            <div class="summary-box">

                <strong><?= $pending_tests ?></strong>

                Pending

            </div>

        </div>

    </div>


    <!-- TESTS -->

    <div class="card">

        <h2>Ordered Laboratory Tests</h2>

        <?php if (empty($tests)): ?>

            <p>No laboratory tests found for this order.</p>

        <?php else: ?>

            <table>

                <thead>

                    <tr>

                        <th>#</th>

                        <th>Test Code</th>

                        <th>Test Name</th>

                        <th>Category</th>

                        <th>Specimen</th>

                        <th>Status</th>

                        <th>Action</th>

                    </tr>

                </thead>

                <tbody>

                <?php foreach ($tests as $index => $test): ?>

                    <tr>

                        <td>
                            <?= $index + 1 ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($test['test_code']) ?>
                        </td>

                        <td>
                            <strong>
                                <?= htmlspecialchars($test['test_name']) ?>
                            </strong>
                        </td>

                        <td>
                            <?= htmlspecialchars($test['category'] ?? '') ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($test['specimen_type'] ?? '') ?>
                        </td>

                        <td>

                            <?php

                            $status_class = strtolower(
                                $test['item_status']
                            );

                            ?>

                            <span class="status <?= $status_class ?>">

                                <?= htmlspecialchars(
                                    $test['item_status']
                                ) ?>

                            </span>

                        </td>

                        <td>

                            <?php if ($test['item_status'] === 'Completed'): ?>

                                <a
                                    href="result.php?order_item_id=<?= $test['order_item_id'] ?>"
                                    class="btn"
                                >
                                    View / Edit Result
                                </a>

                            <?php else: ?>

                                <a
                                    href="result.php?order_item_id=<?= $test['order_item_id'] ?>"
                                    class="btn"
                                >
                                    Enter Result
                                </a>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        <?php endif; ?>

    </div>

</div>

</body>

</html>