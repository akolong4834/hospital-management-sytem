<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: orders.php");
    exit();
}

/*
|--------------------------------------------------------------------------
| Get submitted IDs
|--------------------------------------------------------------------------
*/
$lab_order_id = isset($_POST['lab_order_id'])
    ? (int) $_POST['lab_order_id']
    : 0;

$order_item_id = isset($_POST['order_item_id'])
    ? (int) $_POST['order_item_id']
    : 0;

$result = isset($_POST['result'])
    ? trim($_POST['result'])
    : '';

$result_unit = isset($_POST['result_unit'])
    ? trim($_POST['result_unit'])
    : '';

$reference_range = isset($_POST['reference_range'])
    ? trim($_POST['reference_range'])
    : '';

$result_notes = isset($_POST['result_notes'])
    ? trim($_POST['result_notes'])
    : '';

$performed_by = isset($_SESSION['user_id'])
    ? (int) $_SESSION['user_id']
    : null;


/*
|--------------------------------------------------------------------------
| Validate laboratory order
|--------------------------------------------------------------------------
*/
if ($lab_order_id <= 0) {
    die("Invalid laboratory order: Laboratory Order ID is missing.");
}


/*
|--------------------------------------------------------------------------
| Validate order item
|--------------------------------------------------------------------------
*/
if ($order_item_id <= 0) {
    die("Invalid laboratory order: Laboratory Order Item ID is missing.");
}


/*
|--------------------------------------------------------------------------
| Validate result
|--------------------------------------------------------------------------
*/
if ($result === '') {
    die("Please enter the laboratory result.");
}


try {

    /*
    |--------------------------------------------------------------------------
    | Confirm that the laboratory order exists
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->prepare("
        SELECT
            lo.lab_order_id,
            lo.visit_id,
            lo.order_status
        FROM laboratory_orders lo
        WHERE lo.lab_order_id = ?
        LIMIT 1
    ");

    $stmt->execute([$lab_order_id]);

    $order = $stmt->fetch();

    if (!$order) {
        die(
            "Invalid laboratory order: Laboratory order #" .
            htmlspecialchars($lab_order_id) .
            " does not exist."
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Confirm that the order item belongs to this order
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->prepare("
        SELECT
            loi.order_item_id,
            loi.lab_order_id,
            loi.test_id,
            loi.item_status,
            lt.test_name
        FROM laboratory_order_items loi

        INNER JOIN laboratory_tests lt
            ON loi.test_id = lt.test_id

        WHERE loi.order_item_id = ?
        AND loi.lab_order_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $order_item_id,
        $lab_order_id
    ]);

    $item = $stmt->fetch();

    if (!$item) {
        die(
            "Invalid laboratory order: The selected laboratory test does not belong to this laboratory order."
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Update laboratory result
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->prepare("
        UPDATE laboratory_order_items

        SET
            result = ?,
            result_unit = ?,
            reference_range = ?,
            result_notes = ?,
            item_status = 'Completed',
            performed_by = ?,
            performed_at = NOW()

        WHERE order_item_id = ?
        AND lab_order_id = ?
    ");

    $stmt->execute([
        $result,
        $result_unit,
        $reference_range,
        $result_notes,
        $performed_by,
        $order_item_id,
        $lab_order_id
    ]);


    /*
    |--------------------------------------------------------------------------
    | Check whether all laboratory tests are completed
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM laboratory_order_items
        WHERE lab_order_id = ?
        AND item_status <> 'Completed'
    ");

    $stmt->execute([$lab_order_id]);

    $remaining = (int) $stmt->fetchColumn();


    /*
    |--------------------------------------------------------------------------
    | All tests completed
    |--------------------------------------------------------------------------
    */
    if ($remaining === 0) {

        $stmt = $pdo->prepare("
            UPDATE laboratory_orders

            SET
                order_status = 'Completed',
                completed_at = NOW()

            WHERE lab_order_id = ?
        ");

        $stmt->execute([$lab_order_id]);


        /*
        |--------------------------------------------------------------------------
        | Move patient to Pharmacy
        |--------------------------------------------------------------------------
        */
        $stmt = $pdo->prepare("
            UPDATE patient_visits
            SET status = 'Pharmacy'
            WHERE visit_id = ?
        ");

        $stmt->execute([
            $order['visit_id']
        ]);


        /*
        |--------------------------------------------------------------------------
        | Redirect to laboratory orders
        |--------------------------------------------------------------------------
        */
        header("Location: orders.php?success=completed");
        exit();

    } else {

        /*
        |--------------------------------------------------------------------------
        | Some tests are still pending
        |--------------------------------------------------------------------------
        */
        $stmt = $pdo->prepare("
            UPDATE laboratory_orders

            SET order_status = 'Processing'

            WHERE lab_order_id = ?
        ");

        $stmt->execute([
            $lab_order_id
        ]);


        header(
            "Location: processing.php?lab_order_id=" .
            urlencode($lab_order_id) .
            "&success=result_saved"
        );

        exit();
    }


} catch (PDOException $e) {

    die(
        "Database error while saving laboratory result: " .
        htmlspecialchars($e->getMessage())
    );
}
?>