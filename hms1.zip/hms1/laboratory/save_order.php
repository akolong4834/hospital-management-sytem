<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: queue.php");
    exit();
}

/*
|--------------------------------------------------------------------------
| Get submitted visit ID
|--------------------------------------------------------------------------
*/
$visit_id = isset($_POST['visit_id']) ? (int) $_POST['visit_id'] : 0;

/*
|--------------------------------------------------------------------------
| Get selected laboratory tests
|--------------------------------------------------------------------------
*/
$test_ids = isset($_POST['test_ids']) && is_array($_POST['test_ids'])
    ? $_POST['test_ids']
    : [];

$clinical_notes = isset($_POST['clinical_notes'])
    ? trim($_POST['clinical_notes'])
    : '';

/*
|--------------------------------------------------------------------------
| Validate visit
|--------------------------------------------------------------------------
*/
if ($visit_id <= 0) {
    die("Invalid laboratory order: Visit ID is missing or invalid.");
}

/*
|--------------------------------------------------------------------------
| Validate selected tests
|--------------------------------------------------------------------------
*/
if (empty($test_ids)) {
    die("Invalid laboratory order: Please select at least one laboratory test.");
}

/*
|--------------------------------------------------------------------------
| Get current user
|--------------------------------------------------------------------------
*/
$ordered_by = isset($_SESSION['user_id'])
    ? (int) $_SESSION['user_id']
    : null;

try {

    /*
    |--------------------------------------------------------------------------
    | Confirm that the visit exists
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->prepare("
        SELECT
            v.visit_id,
            v.visit_number,
            v.patient_id
        FROM patient_visits v
        WHERE v.visit_id = ?
        LIMIT 1
    ");

    $stmt->execute([$visit_id]);

    $visit = $stmt->fetch();

    if (!$visit) {
        die("Invalid laboratory order: The selected patient visit does not exist.");
    }

    /*
    |--------------------------------------------------------------------------
    | Check that selected laboratory tests actually exist
    |--------------------------------------------------------------------------
    */
    $valid_tests = [];

    $test_stmt = $pdo->prepare("
        SELECT
            test_id,
            test_name,
            price
        FROM laboratory_tests
        WHERE test_id = ?
        AND status = 'Active'
        LIMIT 1
    ");

    foreach ($test_ids as $test_id) {

        $test_id = (int) $test_id;

        if ($test_id <= 0) {
            continue;
        }

        $test_stmt->execute([$test_id]);

        $test = $test_stmt->fetch();

        if ($test) {
            $valid_tests[] = $test;
        }
    }

    if (empty($valid_tests)) {
        die("Invalid laboratory order: No valid laboratory tests were selected.");
    }

    /*
    |--------------------------------------------------------------------------
    | Begin transaction
    |--------------------------------------------------------------------------
    */
    $pdo->beginTransaction();

    /*
    |--------------------------------------------------------------------------
    | Create laboratory order
    |--------------------------------------------------------------------------
    */
    $stmt = $pdo->prepare("
        INSERT INTO laboratory_orders
        (
            visit_id,
            ordered_by,
            clinical_notes,
            order_status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            'Ordered'
        )
    ");

    $stmt->execute([
        $visit_id,
        $ordered_by,
        $clinical_notes
    ]);

    $lab_order_id = $pdo->lastInsertId();

    if (!$lab_order_id) {
        throw new Exception("Laboratory order could not be created.");
    }

    /*
    |--------------------------------------------------------------------------
    | Insert laboratory order items
    |--------------------------------------------------------------------------
    */
    $item_stmt = $pdo->prepare("
        INSERT INTO laboratory_order_items
        (
            lab_order_id,
            test_id,
            test_price,
            item_status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            'Ordered'
        )
    ");

    foreach ($valid_tests as $test) {

        $item_stmt->execute([
            $lab_order_id,
            $test['test_id'],
            $test['price']
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Update patient visit status
    |--------------------------------------------------------------------------
    */
    $visit_stmt = $pdo->prepare("
        UPDATE patient_visits
        SET status = 'Laboratory'
        WHERE visit_id = ?
    ");

    $visit_stmt->execute([$visit_id]);

    /*
    |--------------------------------------------------------------------------
    | Commit transaction
    |--------------------------------------------------------------------------
    */
    $pdo->commit();

    /*
    |--------------------------------------------------------------------------
    | Go to laboratory processing
    |--------------------------------------------------------------------------
    */
    header(
        "Location: processing.php?lab_order_id=" .
        urlencode($lab_order_id)
    );

    exit();

} catch (Exception $e) {

    /*
    |--------------------------------------------------------------------------
    | Roll back transaction if active
    |--------------------------------------------------------------------------
    */
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    die(
        "Laboratory order could not be created. " .
        htmlspecialchars($e->getMessage())
    );
}
?>