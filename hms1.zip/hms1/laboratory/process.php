<?php
$title='Process Laboratory Order';
require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$id=(int)($_GET['id']??0);
$s=$pdo->prepare("SELECT lo.*,v.visit_no,p.patient_no,CONCAT_WS(' ',p.first_name,p.middle_name,p.last_name) patient_name FROM lab_orders lo JOIN patient_visits v ON v.id=lo.visit_id JOIN patients p ON p.id=v.patient_id WHERE lo.id=?");$s->execute([$id]);$o=$s->fetch();if(!$o)exit('Order not found.');
$q=$pdo->prepare("SELECT loi.*,lt.test_name,lt.specimen_type,lr.result_value,lr.reference_range,lr.unit,lr.interpretation FROM lab_order_items loi JOIN lab_tests lt ON lt.id=loi.lab_test_id LEFT JOIN lab_results lr ON lr.lab_order_item_id=loi.id WHERE loi.lab_order_id=?");$q->execute([$id]);$items=$q->fetchAll();?>
<div class="card p-4"><div class="alert alert-light border"><b><?=htmlspecialchars($o['patient_name'])?></b> | <?=$o['patient_no']?> | Order <?=$o['order_no']?></div>
<form method="post" action="save_result.php"><input type="hidden" name="order_id" value="<?=$id?>">
<?php foreach($items as $i):?><div class="border rounded p-3 mb-3"><h6><?=htmlspecialchars($i['test_name'])?> <small class="text-muted">(<?=$i['specimen_type']?>)</small></h6><input type="hidden" name="item_id[]" value="<?=$i['id']?>">
<div class="row g-2"><div class="col-md-6"><label class="form-label">Result</label><textarea class="form-control" name="result_value[]"><?=htmlspecialchars($i['result_value']??'')?></textarea></div><div class="col-md-3"><label class="form-label">Reference Range</label><input class="form-control" name="reference_range[]" value="<?=htmlspecialchars($i['reference_range']??'')?>"></div><div class="col-md-3"><label class="form-label">Unit</label><input class="form-control" name="unit[]" value="<?=htmlspecialchars($i['unit']??'')?>"></div><div class="col-12"><label class="form-label">Interpretation</label><textarea class="form-control" name="interpretation[]"><?=htmlspecialchars($i['interpretation']??'')?></textarea></div></div></div><?php endforeach;?>
<button class="btn btn-success">Save Results & Complete Order</button></form></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>