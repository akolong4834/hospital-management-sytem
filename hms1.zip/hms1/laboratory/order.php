<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

check_authentication();


/*
|--------------------------------------------------------------------------
| Get Visit ID
|--------------------------------------------------------------------------
*/

$visit_id = isset($_GET['visit_id'])
    ? (int) $_GET['visit_id']
    : 0;

if ($visit_id <= 0) {
    die("Invalid visit ID.");
}


/*
|--------------------------------------------------------------------------
| Get Patient and Consultation Information
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.department,
        v.chief_complaint,
        v.status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,

        c.consultation_id,
        c.diagnosis,
        c.investigations_requested

    FROM patient_visits v

    INNER JOIN patients p
        ON p.patient_id = v.patient_id

    LEFT JOIN consultations c
        ON c.visit_id = v.visit_id

    WHERE v.visit_id = ?

    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$visit_id]);

$patient = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$patient) {
    die("Patient visit was not found.");
}


/*
|--------------------------------------------------------------------------
| Get Available Laboratory Tests
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        test_id,
        test_code,
        test_name,
        category,
        specimen_type,
        price
    FROM laboratory_tests
    WHERE status = 'Active'
    ORDER BY category ASC, test_name ASC
");

$tests = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Patient Name
|--------------------------------------------------------------------------
*/

$full_name = trim(
    $patient['first_name'] . ' ' .
    ($patient['middle_name'] ?? '') . ' ' .
    $patient['last_name']
);


/*
|--------------------------------------------------------------------------
| Calculate Age
|--------------------------------------------------------------------------
*/

$age = '';

if (!empty($patient['date_of_birth'])) {

    $dob = new DateTime($patient['date_of_birth']);
    $today = new DateTime();

    $age = $today->diff($dob)->y;
}

?>

<?php require_once __DIR__ . '/../includes/header.php'; ?>


<div class="container-fluid">


    <!-- PAGE HEADER -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                Create Laboratory Order
            </h2>

            <p class="text-muted mb-0">
                Select laboratory investigations for this patient
            </p>

        </div>


        <a
            href="queue.php"
            class="btn btn-secondary"
        >
            Back to Laboratory Queue
        </a>

    </div>


    <!-- PATIENT INFORMATION -->

    <div class="card shadow-sm mb-4">

        <div class="card-header bg-primary text-white">

            <strong>
                Patient Information
            </strong>

        </div>


        <div class="card-body">

            <div class="row">


                <div class="col-md-3">

                    <label class="text-muted">
                        Patient Name
                    </label>

                    <h5>
                        <?= htmlspecialchars($full_name); ?>
                    </h5>

                </div>


                <div class="col-md-2">

                    <label class="text-muted">
                        Patient No.
                    </label>

                    <h6>
                        <?= htmlspecialchars(
                            $patient['patient_number']
                        ); ?>
                    </h6>

                </div>


                <div class="col-md-2">

                    <label class="text-muted">
                        Visit No.
                    </label>

                    <h6>
                        <?= htmlspecialchars(
                            $patient['visit_number']
                        ); ?>
                    </h6>

                </div>


                <div class="col-md-1">

                    <label class="text-muted">
                        Age
                    </label>

                    <h6>
                        <?= htmlspecialchars($age); ?>
                    </h6>

                </div>


                <div class="col-md-2">

                    <label class="text-muted">
                        Gender
                    </label>

                    <h6>
                        <?= htmlspecialchars(
                            $patient['gender']
                        ); ?>
                    </h6>

                </div>


                <div class="col-md-2">

                    <label class="text-muted">
                        Phone
                    </label>

                    <h6>
                        <?= htmlspecialchars(
                            $patient['phone']
                        ); ?>
                    </h6>

                </div>


            </div>

        </div>

    </div>


    <!-- CLINICAL INFORMATION -->

    <div class="card shadow-sm mb-4">

        <div class="card-header bg-info text-white">

            <strong>
                Clinical Information
            </strong>

        </div>


        <div class="card-body">

            <div class="row">


                <div class="col-md-6">

                    <label class="form-label">
                        Chief Complaint
                    </label>

                    <textarea
                        class="form-control"
                        rows="4"
                        readonly
                    ><?= htmlspecialchars(
                        $patient['chief_complaint'] ?? ''
                    ); ?></textarea>

                </div>


                <div class="col-md-6">

                    <label class="form-label">
                        Clinical Diagnosis
                    </label>

                    <textarea
                        class="form-control"
                        rows="4"
                        readonly
                    ><?= htmlspecialchars(
                        $patient['diagnosis'] ?? ''
                    ); ?></textarea>

                </div>


            </div>


            <div class="mt-3">

                <label class="form-label">
                    Investigations Requested by Clinician
                </label>

                <textarea
                    class="form-control"
                    rows="4"
                    readonly
                ><?= htmlspecialchars(
                    $patient['investigations_requested'] ?? ''
                ); ?></textarea>

            </div>

        </div>

    </div>


    <!-- LABORATORY ORDER -->

    <form
        method="POST"
        action="save_order.php"
    >

        <input
            type="hidden"
            name="visit_id"
            value="<?= (int) $patient['visit_id']; ?>"
        >


        <div class="card shadow-sm mb-4">

            <div class="card-header bg-success text-white">

                <strong>
                    Select Laboratory Tests
                </strong>

            </div>


            <div class="card-body">


                <?php if (empty($tests)): ?>

                    <div class="alert alert-warning">

                        <strong>
                            No laboratory tests are available.
                        </strong>

                        <br>

                        Please add laboratory tests to the
                        <code>laboratory_tests</code> table.

                    </div>

                <?php else: ?>


                    <div class="table-responsive">

                        <table class="table table-bordered table-hover">

                            <thead class="table-light">

                                <tr>

                                    <th style="width: 60px;">
                                        Select
                                    </th>

                                    <th>
                                        Code
                                    </th>

                                    <th>
                                        Laboratory Test
                                    </th>

                                    <th>
                                        Category
                                    </th>

                                    <th>
                                        Specimen
                                    </th>

                                    <th>
                                        Price
                                    </th>

                                </tr>

                            </thead>


                            <tbody>


                            <?php foreach ($tests as $test): ?>

                                <tr>

                                    <td class="text-center">

                                        <input
                                            type="checkbox"
                                            name="test_ids[]"
                                            value="<?= (int) $test['test_id']; ?>"
                                            class="form-check-input test-checkbox"
                                        >

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $test['test_code']
                                        ); ?>

                                    </td>


                                    <td>

                                        <strong>
                                            <?= htmlspecialchars(
                                                $test['test_name']
                                            ); ?>
                                        </strong>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $test['category'] ?? ''
                                        ); ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $test['specimen_type'] ?? ''
                                        ); ?>

                                    </td>


                                    <td>

                                        KSh
                                        <?= number_format(
                                            (float) $test['price'],
                                            2
                                        ); ?>

                                    </td>


                                </tr>

                            <?php endforeach; ?>


                            </tbody>

                        </table>

                    </div>


                <?php endif; ?>


                <!-- NOTES -->

                <div class="mt-4">

                    <label class="form-label">

                        Laboratory Order Notes

                    </label>


                    <textarea
                        name="clinical_notes"
                        class="form-control"
                        rows="4"
                        placeholder="Enter any additional instructions for the laboratory..."
                    ></textarea>

                </div>


            </div>

        </div>


        <!-- ORDER TOTAL -->

        <div class="card shadow-sm mb-4">

            <div class="card-body">

                <div class="row align-items-center">

                    <div class="col-md-8">

                        <h5 class="mb-1">
                            Selected Tests
                        </h5>

                        <span
                            id="selectedCount"
                            class="text-muted"
                        >
                            0 test(s) selected
                        </span>

                    </div>


                    <div class="col-md-4 text-end">

                        <h4>

                            Total:

                            <span id="totalAmount">
                                KSh 0.00
                            </span>

                        </h4>

                    </div>

                </div>

            </div>

        </div>


        <!-- ACTIONS -->

        <div class="d-flex justify-content-between mb-5">


            <a
                href="queue.php"
                class="btn btn-secondary"
            >
                Cancel
            </a>


            <button
                type="submit"
                class="btn btn-success btn-lg"
                <?= empty($tests) ? 'disabled' : ''; ?>
            >
                Create Laboratory Order
            </button>


        </div>


    </form>


</div>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const checkboxes =
        document.querySelectorAll('.test-checkbox');

    const selectedCount =
        document.getElementById('selectedCount');

    const totalAmount =
        document.getElementById('totalAmount');


    function calculateTotal() {

        let total = 0;
        let count = 0;


        checkboxes.forEach(function (checkbox) {

            if (checkbox.checked) {

                count++;

                const row =
                    checkbox.closest('tr');

                const priceCell =
                    row.querySelector('td:nth-child(6)');

                if (priceCell) {

                    const priceText =
                        priceCell.textContent
                            .replace('KSh', '')
                            .replace(/,/g, '')
                            .trim();

                    const price =
                        parseFloat(priceText);

                    if (!isNaN(price)) {
                        total += price;
                    }

                }

            }

        });


        selectedCount.textContent =
            count + ' test(s) selected';


        totalAmount.textContent =
            'KSh ' +
            total.toLocaleString(
                'en-KE',
                {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            );

    }


    checkboxes.forEach(function (checkbox) {

        checkbox.addEventListener(
            'change',
            calculateTotal
        );

    });


});

</script>


<?php require_once __DIR__ . '/../includes/footer.php'; ?>