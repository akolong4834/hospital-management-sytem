-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2026 at 02:20 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `bill_id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` int(10) UNSIGNED NOT NULL,
  `bill_number` varchar(50) NOT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount_paid` decimal(12,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00',
  `bill_status` enum('Unpaid','Partially Paid','Paid','Cancelled') NOT NULL DEFAULT 'Unpaid',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` (`bill_id`, `visit_id`, `bill_number`, `subtotal`, `discount`, `total_amount`, `amount_paid`, `balance`, `bill_status`, `created_by`, `created_at`, `updated_at`) VALUES
(2, 14, 'INV-20260929-0001', '2000.00', '0.00', '2000.00', '2000.00', '0.00', 'Paid', 1, '2026-09-29 09:28:05', '2026-09-29 09:30:46');

-- --------------------------------------------------------

--
-- Table structure for table `bill_items`
--

CREATE TABLE `bill_items` (
  `bill_item_id` bigint(20) UNSIGNED NOT NULL,
  `bill_id` bigint(20) UNSIGNED NOT NULL,
  `item_type` enum('Consultation','Laboratory','Medicine','Procedure','Other') NOT NULL DEFAULT 'Other',
  `description` varchar(255) NOT NULL,
  `reference_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `unit_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill_items`
--

INSERT INTO `bill_items` (`bill_item_id`, `bill_id`, `item_type`, `description`, `reference_id`, `quantity`, `unit_price`, `total_price`, `created_at`) VALUES
(1, 2, 'Laboratory', 'Blood Sugar', 43, 1, '200.00', '200.00', '2026-09-29 09:28:05'),
(2, 2, 'Laboratory', 'Malaria Test', 44, 1, '300.00', '300.00', '2026-09-29 09:28:05'),
(3, 2, 'Medicine', 'iburofen - 500 - 3', 4, 10, '100.00', '1000.00', '2026-09-29 09:28:05'),
(4, 2, 'Consultation', 'Medical consultation', NULL, 1, '500.00', '500.00', '2026-09-29 09:28:05');

-- --------------------------------------------------------

--
-- Table structure for table `consultations`
--

CREATE TABLE `consultations` (
  `consultation_id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `clinician_id` int(10) UNSIGNED DEFAULT NULL,
  `history_of_presenting_illness` text COLLATE utf8mb4_unicode_ci,
  `past_medical_history` text COLLATE utf8mb4_unicode_ci,
  `physical_examination` text COLLATE utf8mb4_unicode_ci,
  `assessment` text COLLATE utf8mb4_unicode_ci,
  `treatment_plan` text COLLATE utf8mb4_unicode_ci,
  `follow_up_date` date DEFAULT NULL,
  `status` enum('Open','Completed') COLLATE utf8mb4_unicode_ci DEFAULT 'Open',
  `consultation_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `family_history` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `social_history` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `examination_findings` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `diagnosis` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `differential_diagnosis` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `investigations_requested` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `laboratory_required` enum('No','Yes') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'No',
  `follow_up_instructions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `referral_required` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `referral_notes` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `consultation_status` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `consultations`
--

INSERT INTO `consultations` (`consultation_id`, `visit_id`, `clinician_id`, `history_of_presenting_illness`, `past_medical_history`, `physical_examination`, `assessment`, `treatment_plan`, `follow_up_date`, `status`, `consultation_date`, `updated_at`, `family_history`, `social_history`, `examination_findings`, `diagnosis`, `differential_diagnosis`, `investigations_requested`, `laboratory_required`, `follow_up_instructions`, `referral_required`, `referral_notes`, `consultation_status`) VALUES
(1, 6, 1, NULL, '', NULL, NULL, '', NULL, 'Open', '2026-09-23 12:09:33', '2026-09-23 12:10:01', '', '', '', '', '', '', 'No', '', 'No', '', 'Completed'),
(2, 7, 1, NULL, '', NULL, NULL, '', NULL, 'Open', '2026-09-23 12:18:30', '2026-09-23 12:18:30', '', '', '', '', '', '', 'No', '', 'No', '', 'Completed'),
(3, 8, 1, NULL, '', NULL, NULL, '', NULL, 'Open', '2026-09-23 13:42:29', '2026-09-23 13:42:29', '', '', '', 'possible malaria', '', 'malaria test blood count', 'Yes', '', 'Yes', '', 'Completed'),
(4, 9, 1, NULL, '', NULL, NULL, '', NULL, 'Open', '2026-09-23 16:11:38', '2026-09-23 16:11:38', '', '', '', 'possible syphilis orHIV', '', 'possible HIV', 'Yes', '', 'No', '', 'Completed'),
(5, 10, 1, NULL, 'lots of malaria and diahorea', NULL, NULL, '', NULL, 'Open', '2026-09-25 09:09:57', '2026-09-25 09:09:57', 'history of cancer', '', 'suseptable to stis', 'malaria hiv test', '', 'malaria test hiv test', 'Yes', '', 'No', '', 'Completed'),
(6, 11, 1, NULL, 'nil', NULL, NULL, '', NULL, 'Open', '2026-09-28 09:31:31', '2026-09-28 09:31:31', 'no hx of chronic illness', 'nil', 'fgc', 'nns', 'mal', 'mrdt\r\nfhg', 'Yes', 'tca after 1 week', 'No', '', 'Completed'),
(7, 14, 1, NULL, 'occuring allergies', NULL, NULL, '', NULL, 'Open', '2026-09-29 09:14:53', '2026-09-29 09:14:53', '', '', '', 'allergy to protein', '', 'malaria sugar test', 'Yes', 'come after every week', 'No', '', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `laboratory_orders`
--

CREATE TABLE `laboratory_orders` (
  `lab_order_id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` int(10) UNSIGNED NOT NULL,
  `ordered_by` int(10) UNSIGNED DEFAULT NULL,
  `clinical_notes` text COLLATE utf8mb4_unicode_ci,
  `order_status` enum('Ordered','Processing','Completed','Cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'Ordered',
  `ordered_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `completed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `laboratory_orders`
--

INSERT INTO `laboratory_orders` (`lab_order_id`, `visit_id`, `ordered_by`, `clinical_notes`, `order_status`, `ordered_at`, `completed_at`) VALUES
(1, 1, 1, '', 'Ordered', '2026-09-23 08:48:25', NULL),
(2, 1, 1, '', 'Processing', '2026-09-23 09:04:08', NULL),
(3, 8, 1, '', 'Completed', '2026-09-23 13:43:15', '2026-09-23 13:44:06'),
(4, 8, 1, '', 'Ordered', '2026-09-23 14:19:41', NULL),
(5, 8, 1, '', 'Ordered', '2026-09-23 14:59:07', NULL),
(6, 8, 1, '', 'Ordered', '2026-09-23 15:50:38', NULL),
(7, 8, 1, '', 'Ordered', '2026-09-23 15:53:04', NULL),
(8, 8, 1, '', 'Completed', '2026-09-23 15:56:53', '2026-09-23 16:23:02'),
(9, 8, 1, '', 'Completed', '2026-09-23 15:58:59', '2026-09-23 16:22:03'),
(10, 8, 1, '', 'Completed', '2026-09-23 15:59:25', '2026-09-23 16:06:23'),
(11, 8, 1, '', 'Completed', '2026-09-23 16:00:24', '2026-09-23 16:04:46'),
(12, 9, 1, '', 'Completed', '2026-09-23 16:12:05', '2026-09-23 16:13:28'),
(13, 10, 1, '', 'Completed', '2026-09-25 09:10:30', '2026-09-25 09:11:17'),
(14, 11, 1, '', 'Completed', '2026-09-28 09:32:46', '2026-09-28 09:33:49'),
(15, 14, 1, '', 'Completed', '2026-09-29 09:15:52', '2026-09-29 09:16:30');

-- --------------------------------------------------------

--
-- Table structure for table `laboratory_order_items`
--

CREATE TABLE `laboratory_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `lab_order_id` bigint(20) UNSIGNED NOT NULL,
  `test_id` int(10) UNSIGNED NOT NULL,
  `test_price` decimal(10,2) DEFAULT '0.00',
  `item_status` enum('Ordered','Processing','Completed','Cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'Ordered',
  `result` text COLLATE utf8mb4_unicode_ci,
  `result_unit` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_range` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result_notes` text COLLATE utf8mb4_unicode_ci,
  `performed_by` int(10) UNSIGNED DEFAULT NULL,
  `performed_at` datetime DEFAULT NULL,
  `verified_by` int(10) UNSIGNED DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `laboratory_order_items`
--

INSERT INTO `laboratory_order_items` (`order_item_id`, `lab_order_id`, `test_id`, `test_price`, `item_status`, `result`, `result_unit`, `reference_range`, `result_notes`, `performed_by`, `performed_at`, `verified_by`, `verified_at`) VALUES
(1, 1, 4, '200.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 1, 14, '400.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 1, 5, '200.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 1, 7, '300.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 1, 1, '500.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 1, 2, '200.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 1, 3, '300.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 1, 8, '300.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 1, 9, '500.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 2, 4, '200.00', 'Completed', 'normal', '3.6', '3-6 g/dl', '', 1, '2026-09-23 09:12:04', NULL, NULL),
(11, 2, 14, '400.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 2, 5, '200.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 2, 7, '300.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 2, 1, '500.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 2, 2, '200.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 2, 3, '300.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 2, 8, '300.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 2, 9, '500.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 3, 1, '500.00', 'Completed', 'positive malaria', '', '', '', 1, '2026-09-23 13:43:48', NULL, NULL),
(20, 3, 3, '300.00', 'Completed', 'blood okay', '', '', '', 1, '2026-09-23 13:44:06', NULL, NULL),
(21, 4, 14, '400.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, 4, 6, '200.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 4, 1, '500.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 5, 12, '400.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, 6, 13, '700.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, 6, 15, '400.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 7, 5, '200.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 7, 1, '500.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 7, 3, '300.00', 'Ordered', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 8, 5, '200.00', 'Completed', 'blood normal', '', '', '', 1, '2026-09-23 16:22:35', NULL, NULL),
(31, 8, 1, '500.00', 'Completed', 'blood normal', '', '', '', 1, '2026-09-23 16:22:49', NULL, NULL),
(32, 8, 3, '300.00', 'Completed', 'blood normal', '', '', '', 1, '2026-09-23 16:23:02', NULL, NULL),
(33, 9, 5, '200.00', 'Completed', 'blood sugar normal', '', '', '', 1, '2026-09-23 16:21:22', NULL, NULL),
(34, 9, 1, '500.00', 'Completed', 'blood normal', '', '', '', 1, '2026-09-23 16:21:44', NULL, NULL),
(35, 9, 3, '300.00', 'Completed', 'blood normal', '', '', '', 1, '2026-09-23 16:22:03', NULL, NULL),
(36, 10, 12, '400.00', 'Completed', 'blood is clean', '', '', '', 1, '2026-09-23 16:06:23', NULL, NULL),
(37, 11, 12, '400.00', 'Completed', 'blood full of puss', '500 g/dl', '', '', 1, '2026-09-23 16:04:46', NULL, NULL),
(38, 12, 9, '500.00', 'Completed', 'HIV negative', '', '', '', 1, '2026-09-23 16:13:28', NULL, NULL),
(39, 13, 3, '300.00', 'Completed', 'malaria positive hiv non reactive', '', '', '', 1, '2026-09-25 09:10:59', NULL, NULL),
(40, 13, 9, '500.00', 'Completed', 'hiv test non reactive', '', '', '', 1, '2026-09-25 09:11:17', NULL, NULL),
(41, 14, 1, '500.00', 'Completed', 'wbc 10\r\nhb 11\r\nplt 200', '', '', '', 1, '2026-09-28 09:33:34', NULL, NULL),
(42, 14, 3, '300.00', 'Completed', 'postive', '', '', '', 1, '2026-09-28 09:33:49', NULL, NULL),
(43, 15, 4, '200.00', 'Completed', 'normal', '', '', '', 1, '2026-09-29 09:16:11', NULL, NULL),
(44, 15, 3, '300.00', 'Completed', 'positive', '', '', '', 1, '2026-09-29 09:16:30', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `laboratory_tests`
--

CREATE TABLE `laboratory_tests` (
  `test_id` int(10) UNSIGNED NOT NULL,
  `test_code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specimen_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) DEFAULT '0.00',
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `laboratory_tests`
--

INSERT INTO `laboratory_tests` (`test_id`, `test_code`, `test_name`, `category`, `specimen_type`, `description`, `price`, `status`, `created_at`) VALUES
(1, 'FBC', 'Full Blood Count', 'Haematology', 'Blood', NULL, '500.00', 'Active', '2026-09-22 11:17:47'),
(2, 'HB', 'Haemoglobin', 'Haematology', 'Blood', NULL, '200.00', 'Active', '2026-09-22 11:17:47'),
(3, 'MAL', 'Malaria Test', 'Parasitology', 'Blood', NULL, '300.00', 'Active', '2026-09-22 11:17:47'),
(4, 'BS', 'Blood Sugar', 'Clinical Chemistry', 'Blood', NULL, '200.00', 'Active', '2026-09-22 11:17:47'),
(5, 'RBS', 'Random Blood Sugar', 'Clinical Chemistry', 'Blood', NULL, '200.00', 'Active', '2026-09-22 11:17:47'),
(6, 'FBS', 'Fasting Blood Sugar', 'Clinical Chemistry', 'Blood', NULL, '200.00', 'Active', '2026-09-22 11:17:47'),
(7, 'URINALYSIS', 'Urinalysis', 'Clinical Chemistry', 'Urine', NULL, '300.00', 'Active', '2026-09-22 11:17:47'),
(8, 'STOOL', 'Stool Examination', 'Parasitology', 'Stool', NULL, '300.00', 'Active', '2026-09-22 11:17:47'),
(9, 'HIV', 'HIV Test', 'Serology', 'Blood', NULL, '500.00', 'Active', '2026-09-22 11:17:47'),
(10, 'HBV', 'Hepatitis B Surface Antigen', 'Serology', 'Blood', NULL, '500.00', 'Active', '2026-09-22 11:17:47'),
(11, 'HCV', 'Hepatitis C Test', 'Serology', 'Blood', NULL, '500.00', 'Active', '2026-09-22 11:17:47'),
(12, 'WIDAL', 'Widal Test', 'Serology', 'Blood', NULL, '400.00', 'Active', '2026-09-22 11:17:47'),
(13, 'CRP', 'C-Reactive Protein', 'Clinical Chemistry', 'Blood', NULL, '700.00', 'Active', '2026-09-22 11:17:47'),
(14, 'UREA', 'Blood Urea', 'Clinical Chemistry', 'Blood', NULL, '400.00', 'Active', '2026-09-22 11:17:47'),
(15, 'CREAT', 'Creatinine', 'Clinical Chemistry', 'Blood', NULL, '400.00', 'Active', '2026-09-22 11:17:47');

-- --------------------------------------------------------

--
-- Table structure for table `lab_orders`
--

CREATE TABLE `lab_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `consultation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ordered_by` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('Ordered','Sample Collected','Processing','Completed','Cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'Ordered',
  `clinical_notes` text COLLATE utf8mb4_unicode_ci,
  `ordered_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_order_items`
--

CREATE TABLE `lab_order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lab_order_id` bigint(20) UNSIGNED NOT NULL,
  `lab_test_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('Pending','Sample Collected','Processing','Completed','Cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_results`
--

CREATE TABLE `lab_results` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lab_order_item_id` bigint(20) UNSIGNED NOT NULL,
  `result_value` text COLLATE utf8mb4_unicode_ci,
  `reference_range` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interpretation` text COLLATE utf8mb4_unicode_ci,
  `performed_by` int(10) UNSIGNED DEFAULT NULL,
  `result_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `verified_by` int(10) UNSIGNED DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lab_tests`
--

CREATE TABLE `lab_tests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `test_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `specimen_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `turnaround_hours` decimal(6,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lab_tests`
--

INSERT INTO `lab_tests` (`id`, `test_code`, `test_name`, `category`, `price`, `specimen_type`, `turnaround_hours`, `is_active`) VALUES
(1, 'FBC', 'Full Blood Count', 'Haematology', '500.00', 'Blood', NULL, 1),
(2, 'RBS', 'Random Blood Sugar', 'Biochemistry', '150.00', 'Blood', NULL, 1),
(3, 'URINALYSIS', 'Urinalysis', 'Routine', '300.00', 'Urine', NULL, 1),
(4, 'MALARIA', 'Malaria Test', 'Parasitology', '300.00', 'Blood', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `medicine_id` int(10) UNSIGNED NOT NULL,
  `medicine_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medicine_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `generic_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dosage_form` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `strength` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selling_price` decimal(10,2) DEFAULT '0.00',
  `stock_quantity` int(11) DEFAULT '0',
  `reorder_level` int(11) DEFAULT '0',
  `status` enum('Active','Inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `quantity_prescribed` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`medicine_id`, `medicine_code`, `medicine_name`, `generic_name`, `category`, `dosage_form`, `strength`, `unit`, `selling_price`, `stock_quantity`, `reorder_level`, `status`, `created_at`, `updated_at`, `quantity_prescribed`) VALUES
(1, 'IBU500', 'iburofen', 'brufen', '', '', '500mg', 'tablet', '100.00', 42, 10, 'Active', '2026-09-23 10:39:36', '2026-09-30 12:58:14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `medicine_stock`
--

CREATE TABLE `medicine_stock` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `medicine_id` bigint(20) UNSIGNED NOT NULL,
  `batch_no` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `unit_cost` decimal(12,2) DEFAULT '0.00',
  `received_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `patient_id` int(10) UNSIGNED NOT NULL,
  `patient_number` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `id_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_county` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `village` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_of_kin_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_of_kin_relationship` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_of_kin_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blood_group` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allergies` text COLLATE utf8mb4_unicode_ci,
  `emergency_contact` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`patient_id`, `patient_number`, `first_name`, `middle_name`, `last_name`, `gender`, `date_of_birth`, `id_number`, `phone`, `email`, `county`, `sub_county`, `village`, `occupation`, `next_of_kin_name`, `next_of_kin_relationship`, `next_of_kin_phone`, `blood_group`, `allergies`, `emergency_contact`, `created_at`, `updated_at`) VALUES
(1, 'PT-2026-00001', 'Akolong', 'Kennedy', 'Ekiru', 'Male', '2026-09-15', '28293645', '0714167374', 'jakolongkennedy@gmail.com', '', '', '', '', 'Akolong Kennedy Ekiru', '', '', 'B-', '', '', '2026-09-22 09:36:57', '2026-09-22 09:36:57'),
(2, 'PT-2026-00002', 'david', 'elimlim', 'Ekiru', 'Male', '2026-01-09', '37227085', '0714167374', 'jakolongkennedy@gmail.com', 'TURKANA', 'TURKANA SOUTH', '', '', 'Akolong Kennedy Ekiru', '', '', 'A+', '', '', '2026-09-22 10:03:10', '2026-09-22 10:03:10'),
(3, 'PT-2026-00003', 'kavoko', 'eregae', 'Ekiru', 'Male', '2026-09-21', '37227083', '0714167374', 'jakolongkennedy@gmail.com', 'turkana', 'TURKANA SOUTH', 'town', 'farmer', 'Akolong Kennedy Ekiru', '', '', '', '', '', '2026-09-28 09:21:04', '2026-09-28 09:21:04'),
(4, 'PT-2026-00004', 'dj', '', 'shiti', 'Male', '2005-10-11', NULL, '12345678', NULL, '', '', '', '', '', '', '', 'AB+', '', '', '2026-09-29 09:09:59', '2026-09-29 09:09:59');

-- --------------------------------------------------------

--
-- Table structure for table `patient_visits`
--

CREATE TABLE `patient_visits` (
  `visit_id` int(10) UNSIGNED NOT NULL,
  `visit_number` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patient_id` int(10) UNSIGNED NOT NULL,
  `visit_date` date NOT NULL,
  `visit_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Outpatient',
  `department` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Cash',
  `chief_complaint` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Registered',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patient_visits`
--

INSERT INTO `patient_visits` (`visit_id`, `visit_number`, `patient_id`, `visit_date`, `visit_type`, `department`, `payment_category`, `chief_complaint`, `status`, `created_at`, `updated_at`) VALUES
(1, 'V-2026-00001', 1, '2026-09-22', 'Outpatient', 'General Outpatient', 'Cash', 'flu dry cough high temperature', 'Laboratory', '2026-09-22 09:39:11', '2026-09-23 08:48:25'),
(2, 'V-2026-00002', 2, '2026-09-22', 'Outpatient', 'General Outpatient', 'Cash', 'rhinitis', 'Completed', '2026-09-22 10:04:20', '2026-09-22 10:56:59'),
(3, 'V-2026-00003', 1, '2026-09-22', 'Outpatient', 'General Outpatient', 'Cash', '', 'Completed', '2026-09-22 11:04:55', '2026-09-22 11:06:14'),
(4, 'V-2026-00004', 1, '2026-09-22', 'Review', 'General Outpatient', 'Cash', '', 'Completed', '2026-09-22 11:37:17', '2026-09-22 11:39:29'),
(5, 'V-2026-00005', 2, '2026-09-23', 'Outpatient', 'General Outpatient', 'Cash', '', 'Completed', '2026-09-23 11:17:51', '2026-09-23 11:19:32'),
(6, 'V-2026-00006', 2, '2026-09-23', 'Outpatient', 'General Outpatient', 'Cash', '', 'Completed', '2026-09-23 11:43:53', '2026-09-23 11:48:35'),
(7, 'V-2026-00007', 1, '2026-09-23', 'Outpatient', 'General Outpatient', 'Cash', '', 'Completed', '2026-09-23 12:11:23', '2026-09-23 12:18:30'),
(8, 'V-2026-00008', 2, '2026-09-23', 'Outpatient', 'General Outpatient', 'Cash', '', 'Billing', '2026-09-23 12:14:39', '2026-09-30 12:57:44'),
(9, 'V-2026-00009', 1, '2026-09-23', 'Outpatient', 'Emergency', 'Cash', '', 'Billing', '2026-09-23 16:07:23', '2026-09-30 12:58:14'),
(10, 'V-2026-00010', 1, '2026-09-25', 'Outpatient', 'General Outpatient', 'Cash', '', 'Billing', '2026-09-25 09:07:41', '2026-09-28 08:57:54'),
(11, 'V-2026-00011', 3, '2026-09-28', 'Outpatient', 'General Outpatient', 'Cash', 'dizziness,fever', 'Billing', '2026-09-28 09:21:53', '2026-09-28 09:38:26'),
(12, 'V-2026-00012', 3, '2026-09-28', 'Outpatient', 'General Outpatient', 'Cash', '', 'Registered', '2026-09-28 09:22:05', '2026-09-28 09:22:06'),
(13, 'V-2026-00013', 3, '2026-09-28', 'Outpatient', 'General Outpatient', 'Cash', '', 'Registered', '2026-09-28 09:22:24', '2026-09-28 09:22:25'),
(14, 'V-2026-00014', 4, '2026-09-29', 'Outpatient', 'General Outpatient', 'Cash', 'follow up', 'Completed', '2026-09-29 09:10:26', '2026-09-29 09:30:46');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` bigint(20) UNSIGNED NOT NULL,
  `bill_id` bigint(20) UNSIGNED NOT NULL,
  `receipt_number` varchar(50) NOT NULL,
  `payment_method` enum('Cash','M-Pesa','Card','Insurance','Bank','Other') NOT NULL DEFAULT 'Cash',
  `amount` decimal(12,2) NOT NULL,
  `transaction_reference` varchar(100) DEFAULT NULL,
  `payment_notes` text,
  `received_by` int(10) UNSIGNED DEFAULT NULL,
  `payment_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `bill_id`, `receipt_number`, `payment_method`, `amount`, `transaction_reference`, `payment_notes`, `received_by`, `payment_date`) VALUES
(1, 2, 'RCT-20260929-0001', 'Cash', '2000.00', NULL, NULL, 1, '2026-09-29 09:30:46');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `permission_name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`permission_id`, `permission_name`, `description`, `created_at`) VALUES
(1, 'patients.view', 'View patient records', '2026-09-30 12:29:56'),
(2, 'patients.create', 'Register new patients', '2026-09-30 12:29:56'),
(3, 'patients.edit', 'Edit patient information', '2026-09-30 12:29:56'),
(4, 'visits.create', 'Create patient visits', '2026-09-30 12:29:56'),
(5, 'visits.view', 'View patient visits', '2026-09-30 12:29:56'),
(6, 'triage.view', 'View triage queue', '2026-09-30 12:29:56'),
(7, 'triage.create', 'Perform patient triage', '2026-09-30 12:29:56'),
(8, 'consultation.view', 'View consultation queue', '2026-09-30 12:29:56'),
(9, 'consultation.create', 'Perform patient consultation', '2026-09-30 12:29:56'),
(10, 'laboratory.view', 'View laboratory queue', '2026-09-30 12:29:56'),
(11, 'laboratory.order', 'Create laboratory orders', '2026-09-30 12:29:56'),
(12, 'laboratory.process', 'Process laboratory tests', '2026-09-30 12:29:56'),
(13, 'laboratory.results', 'Enter laboratory results', '2026-09-30 12:29:56'),
(14, 'pharmacy.view', 'View pharmacy queue', '2026-09-30 12:29:56'),
(15, 'pharmacy.prescribe', 'Create prescriptions', '2026-09-30 12:29:56'),
(16, 'pharmacy.dispense', 'Dispense medicines', '2026-09-30 12:29:56'),
(17, 'pharmacy.stock', 'Manage pharmacy stock', '2026-09-30 12:29:56'),
(18, 'billing.view', 'View billing', '2026-09-30 12:29:56'),
(19, 'billing.create', 'Create bills', '2026-09-30 12:29:56'),
(20, 'billing.payment', 'Receive payments', '2026-09-30 12:29:56'),
(21, 'billing.receipt', 'View and print receipts', '2026-09-30 12:29:56'),
(22, 'reports.view', 'View system reports', '2026-09-30 12:29:56'),
(23, 'users.view', 'View system users', '2026-09-30 12:29:56'),
(24, 'users.create', 'Create system users', '2026-09-30 12:29:56'),
(25, 'users.edit', 'Edit system users', '2026-09-30 12:29:56'),
(26, 'users.delete', 'Deactivate system users', '2026-09-30 12:29:56'),
(27, 'system.settings', 'Manage system settings', '2026-09-30 12:29:56');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `prescription_id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` int(10) UNSIGNED NOT NULL,
  `prescribed_by` int(10) UNSIGNED DEFAULT NULL,
  `prescription_notes` text COLLATE utf8mb4_unicode_ci,
  `prescription_status` enum('Pending','Processing','Completed','Cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `prescribed_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `completed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`prescription_id`, `visit_id`, `prescribed_by`, `prescription_notes`, `prescription_status`, `prescribed_at`, `completed_at`) VALUES
(6, 10, 1, '', 'Pending', '2026-09-25 09:26:41', NULL),
(7, 10, 1, '', 'Completed', '2026-09-28 08:42:17', NULL),
(8, 11, 1, '', 'Completed', '2026-09-28 09:37:49', NULL),
(9, 14, 1, 'take two morning and evening', 'Completed', '2026-09-29 09:18:07', NULL),
(10, 8, 1, '', 'Completed', '2026-09-30 12:57:36', NULL),
(11, 9, 1, '', 'Completed', '2026-09-30 12:58:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `prescription_items`
--

CREATE TABLE `prescription_items` (
  `prescription_item_id` bigint(20) UNSIGNED NOT NULL,
  `prescription_id` bigint(20) UNSIGNED NOT NULL,
  `medicine_id` int(10) UNSIGNED NOT NULL,
  `dosage` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequency` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT '0',
  `instructions` text COLLATE utf8mb4_unicode_ci,
  `unit_price` decimal(10,2) DEFAULT '0.00',
  `quantity_dispensed` int(11) DEFAULT '0',
  `item_status` enum('Pending','Dispensed','Partial','Cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `dispensed_by` int(10) UNSIGNED DEFAULT NULL,
  `dispensed_at` datetime DEFAULT NULL,
  `quantity_prescribed` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `prescription_items`
--

INSERT INTO `prescription_items` (`prescription_item_id`, `prescription_id`, `medicine_id`, `dosage`, `frequency`, `route`, `duration`, `quantity`, `instructions`, `unit_price`, `quantity_dispensed`, `item_status`, `dispensed_by`, `dispensed_at`, `quantity_prescribed`) VALUES
(1, 6, 1, '500', '3', 'Oral', '3', 0, '', '0.00', 0, 'Pending', NULL, NULL, 1),
(2, 7, 1, '500', '3', 'Oral', '3', 0, '', '0.00', 1, 'Dispensed', NULL, NULL, 1),
(3, 8, 1, '50', '3', 'Oral', '3', 0, '', '0.00', 1, 'Dispensed', NULL, NULL, 1),
(4, 9, 1, '500', '3', 'IV', '3', 0, '', '0.00', 10, 'Dispensed', NULL, NULL, 10),
(5, 10, 1, '500', '3', 'Oral', '3', 0, '', '0.00', 1, 'Dispensed', NULL, NULL, 1),
(6, 11, 1, '500', '3', 'Oral', '3', 0, '', '0.00', 1, 'Dispensed', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `description`, `status`, `created_at`) VALUES
(1, 'Administrator', 'Full access to the hospital management system', 'Active', '2026-09-30 12:28:57'),
(2, 'Receptionist', 'Patient registration and reception operations', 'Active', '2026-09-30 12:28:57'),
(3, 'Nurse', 'Triage and nursing operations', 'Active', '2026-09-30 12:28:57'),
(4, 'Clinician', 'Consultation and clinical operations', 'Active', '2026-09-30 12:28:57'),
(5, 'Laboratory', 'Laboratory investigations and results', 'Active', '2026-09-30 12:28:57'),
(6, 'Pharmacist', 'Prescriptions, dispensing and pharmacy stock', 'Active', '2026-09-30 12:28:57'),
(7, 'Cashier', 'Billing, payments and receipts', 'Active', '2026-09-30 12:28:57'),
(8, 'Records Officer', 'Patient records and medical records management', 'Active', '2026-09-30 12:28:57');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int(10) NOT NULL,
  `permission_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 5),
(4, 1),
(4, 5),
(4, 6),
(4, 8),
(4, 9),
(4, 10),
(4, 11),
(4, 14),
(4, 15),
(5, 1),
(5, 10),
(5, 11),
(5, 12),
(5, 13),
(6, 1),
(6, 14),
(6, 15),
(6, 16),
(6, 17),
(7, 1),
(7, 5),
(7, 18),
(7, 19),
(7, 20),
(7, 21),
(7, 22),
(8, 1),
(8, 2),
(8, 3),
(8, 5),
(8, 22);

-- --------------------------------------------------------

--
-- Table structure for table `triage`
--

CREATE TABLE `triage` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `weight_kg` decimal(6,2) DEFAULT NULL,
  `height_cm` decimal(6,2) DEFAULT NULL,
  `temperature_c` decimal(4,1) DEFAULT NULL,
  `systolic_bp` smallint(5) UNSIGNED DEFAULT NULL,
  `diastolic_bp` smallint(5) UNSIGNED DEFAULT NULL,
  `pulse_bpm` smallint(5) UNSIGNED DEFAULT NULL,
  `respiratory_rate` smallint(5) UNSIGNED DEFAULT NULL,
  `spo2_percent` decimal(5,2) DEFAULT NULL,
  `pain_score` tinyint(3) UNSIGNED DEFAULT NULL,
  `symptoms` text COLLATE utf8mb4_unicode_ci,
  `priority` enum('Routine','Urgent','Emergency') COLLATE utf8mb4_unicode_ci DEFAULT 'Routine',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `assessed_by` int(10) UNSIGNED DEFAULT NULL,
  `assessed_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `triage`
--

INSERT INTO `triage` (`id`, `visit_id`, `weight_kg`, `height_cm`, `temperature_c`, `systolic_bp`, `diastolic_bp`, `pulse_bpm`, `respiratory_rate`, `spo2_percent`, `pain_score`, `symptoms`, `priority`, `notes`, `assessed_by`, `assessed_at`) VALUES
(1, 6, NULL, NULL, '34.0', NULL, NULL, NULL, NULL, NULL, NULL, '', 'Urgent', '', 1, '2026-09-23 11:44:48'),
(2, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'Routine', '', 1, '2026-09-23 12:13:32'),
(3, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'Routine', '', 1, '2026-09-23 12:15:05'),
(4, 9, '65.00', '182.00', '37.0', NULL, NULL, NULL, NULL, NULL, 6, '', 'Urgent', '', 1, '2026-09-23 16:08:27'),
(5, 10, NULL, NULL, '40.0', NULL, NULL, NULL, NULL, NULL, 8, '', 'Emergency', '', 1, '2026-09-25 09:08:10'),
(6, 11, '1.00', '47.00', '36.5', NULL, NULL, NULL, 70, '98.00', 9, 'dizzinness', 'Routine', 'sicklooking', 1, '2026-09-28 09:26:13'),
(7, 14, '65.00', '182.00', '40.0', 120, 76, NULL, NULL, NULL, 6, 'fever rashes red eyes dry lips', 'Urgent', '', 1, '2026-09-29 09:11:41');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` enum('Active','Inactive','Suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Active',
  `role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Receptionist'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `role_id`, `username`, `password_hash`, `full_name`, `email`, `phone`, `is_active`, `created_at`, `updated_at`, `status`, `role`) VALUES
(1, 1, 'admin', '$2y$10$9nrkh72HQN3MBifsRybVK.MntCNEhwCxATB.QvqzU6vkI02ntk2CS', 'System Administrator', NULL, NULL, 1, '2026-09-21 06:02:54', '2026-09-30 10:31:36', 'Active', 'Administrator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bills`
--
ALTER TABLE `bills`
  ADD PRIMARY KEY (`bill_id`),
  ADD UNIQUE KEY `bill_number` (`bill_number`),
  ADD KEY `idx_bill_visit` (`visit_id`),
  ADD KEY `idx_bill_status` (`bill_status`);

--
-- Indexes for table `bill_items`
--
ALTER TABLE `bill_items`
  ADD PRIMARY KEY (`bill_item_id`),
  ADD KEY `idx_bill_item_bill` (`bill_id`),
  ADD KEY `idx_bill_item_type` (`item_type`);

--
-- Indexes for table `consultations`
--
ALTER TABLE `consultations`
  ADD PRIMARY KEY (`consultation_id`),
  ADD UNIQUE KEY `visit_id` (`visit_id`),
  ADD KEY `fk_consult_clinician` (`clinician_id`);

--
-- Indexes for table `laboratory_orders`
--
ALTER TABLE `laboratory_orders`
  ADD PRIMARY KEY (`lab_order_id`),
  ADD KEY `idx_lab_order_visit` (`visit_id`),
  ADD KEY `idx_lab_order_status` (`order_status`);

--
-- Indexes for table `laboratory_order_items`
--
ALTER TABLE `laboratory_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `idx_lab_item_order` (`lab_order_id`),
  ADD KEY `idx_lab_item_test` (`test_id`);

--
-- Indexes for table `laboratory_tests`
--
ALTER TABLE `laboratory_tests`
  ADD PRIMARY KEY (`test_id`),
  ADD UNIQUE KEY `test_code` (`test_code`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`medicine_id`),
  ADD UNIQUE KEY `medicine_code` (`medicine_code`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `patient_number` (`patient_number`),
  ADD UNIQUE KEY `uq_patient_id_number` (`id_number`),
  ADD KEY `idx_patient_name` (`last_name`,`first_name`),
  ADD KEY `idx_patient_phone` (`phone`);

--
-- Indexes for table `patient_visits`
--
ALTER TABLE `patient_visits`
  ADD PRIMARY KEY (`visit_id`),
  ADD UNIQUE KEY `visit_number` (`visit_number`),
  ADD KEY `idx_visit_patient` (`patient_id`),
  ADD KEY `idx_visit_date_status` (`visit_date`,`status`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD UNIQUE KEY `receipt_number` (`receipt_number`),
  ADD KEY `idx_payment_bill` (`bill_id`),
  ADD KEY `idx_payment_method` (`payment_method`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD UNIQUE KEY `permission_name` (`permission_name`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`prescription_id`),
  ADD KEY `idx_prescription_visit` (`visit_id`),
  ADD KEY `idx_prescription_status` (`prescription_status`);

--
-- Indexes for table `prescription_items`
--
ALTER TABLE `prescription_items`
  ADD PRIMARY KEY (`prescription_item_id`),
  ADD KEY `idx_prescription_item_prescription` (`prescription_id`),
  ADD KEY `idx_prescription_item_medicine` (`medicine_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`);

--
-- Indexes for table `triage`
--
ALTER TABLE `triage`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `visit_id` (`visit_id`),
  ADD KEY `idx_triage_priority` (`priority`),
  ADD KEY `fk_triage_user` (`assessed_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bills`
--
ALTER TABLE `bills`
  MODIFY `bill_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bill_items`
--
ALTER TABLE `bill_items`
  MODIFY `bill_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `consultations`
--
ALTER TABLE `consultations`
  MODIFY `consultation_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `laboratory_orders`
--
ALTER TABLE `laboratory_orders`
  MODIFY `lab_order_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `laboratory_order_items`
--
ALTER TABLE `laboratory_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `laboratory_tests`
--
ALTER TABLE `laboratory_tests`
  MODIFY `test_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `medicine_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `patient_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patient_visits`
--
ALTER TABLE `patient_visits`
  MODIFY `visit_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `permission_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `prescription_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `prescription_items`
--
ALTER TABLE `prescription_items`
  MODIFY `prescription_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `triage`
--
ALTER TABLE `triage`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bills`
--
ALTER TABLE `bills`
  ADD CONSTRAINT `fk_bill_visit` FOREIGN KEY (`visit_id`) REFERENCES `patient_visits` (`visit_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bill_items`
--
ALTER TABLE `bill_items`
  ADD CONSTRAINT `fk_bill_item_bill` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`bill_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `laboratory_orders`
--
ALTER TABLE `laboratory_orders`
  ADD CONSTRAINT `fk_lab_order_visit` FOREIGN KEY (`visit_id`) REFERENCES `patient_visits` (`visit_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `laboratory_order_items`
--
ALTER TABLE `laboratory_order_items`
  ADD CONSTRAINT `fk_lab_item_order` FOREIGN KEY (`lab_order_id`) REFERENCES `laboratory_orders` (`lab_order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_lab_item_test` FOREIGN KEY (`test_id`) REFERENCES `laboratory_tests` (`test_id`) ON UPDATE CASCADE;

--
-- Constraints for table `patient_visits`
--
ALTER TABLE `patient_visits`
  ADD CONSTRAINT `fk_visit_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`) ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payment_bill` FOREIGN KEY (`bill_id`) REFERENCES `bills` (`bill_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD CONSTRAINT `fk_prescription_visit` FOREIGN KEY (`visit_id`) REFERENCES `patient_visits` (`visit_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prescription_items`
--
ALTER TABLE `prescription_items`
  ADD CONSTRAINT `fk_prescription_item_medicine` FOREIGN KEY (`medicine_id`) REFERENCES `medicines` (`medicine_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prescription_item_prescription` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`prescription_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
