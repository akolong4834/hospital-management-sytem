INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r
JOIN permissions p
WHERE r.role_name = 'Cashier'
AND p.permission_name IN (
    'patients.view',
    'visits.view',
    'billing.view',
    'billing.create',
    'billing.payment',
    'billing.receipt',
    'reports.view'
);