<?php
require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

/*
|--------------------------------------------------------------------------
| Billing Statistics
|--------------------------------------------------------------------------
*/

$stats = [
    'total_bills' => 0,
    'unpaid_bills' => 0,
    'partial_bills' => 0,
    'paid_bills' => 0,
    'total_billed' => 0,
    'total_paid' => 0,
    'total_balance' => 0,
    'today_payments' => 0,
    'today_amount' => 0
];

/* Total bills */
$stmt = $pdo->query("
    SELECT
        COUNT(*) AS total_bills,
        COALESCE(SUM(total_amount), 0) AS total_billed,
        COALESCE(SUM(amount_paid), 0) AS total_paid,
        COALESCE(SUM(balance), 0) AS total_balance
    FROM bills
    WHERE bill_status <> 'Cancelled'
");

$row = $stmt->fetch();

if ($row) {
    $stats['total_bills'] = (int)$row['total_bills'];
    $stats['total_billed'] = (float)$row['total_billed'];
    $stats['total_paid'] = (float)$row['total_paid'];
    $stats['total_balance'] = (float)$row['total_balance'];
}

/* Bill statuses */
$stmt = $pdo->query("
    SELECT bill_status, COUNT(*) AS total
    FROM bills
    GROUP BY bill_status
");

while ($row = $stmt->fetch()) {

    if ($row['bill_status'] === 'Unpaid') {
        $stats['unpaid_bills'] = (int)$row['total'];
    }

    if ($row['bill_status'] === 'Partially Paid') {
        $stats['partial_bills'] = (int)$row['total'];
    }

    if ($row['bill_status'] === 'Paid') {
        $stats['paid_bills'] = (int)$row['total'];
    }
}

/* Today's payments */
$stmt = $pdo->query("
    SELECT
        COUNT(*) AS total_payments,
        COALESCE(SUM(amount), 0) AS total_amount
    FROM payments
    WHERE DATE(payment_date) = CURDATE()
");

$row = $stmt->fetch();

if ($row) {
    $stats['today_payments'] = (int)$row['total_payments'];
    $stats['today_amount'] = (float)$row['total_amount'];
}

/*
|--------------------------------------------------------------------------
| Recent Payments
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        p.payment_id,
        p.receipt_number,
        p.payment_method,
        p.amount,
        p.payment_date,

        b.bill_id,
        b.bill_number,

        v.visit_number,

        pt.patient_number,
        pt.first_name,
        pt.middle_name,
        pt.last_name

    FROM payments p

    INNER JOIN bills b
        ON p.bill_id = b.bill_id

    INNER JOIN patient_visits v
        ON b.visit_id = v.visit_id

    INNER JOIN patients pt
        ON v.patient_id = pt.patient_id

    ORDER BY p.payment_id DESC

    LIMIT 10
");

$recent_payments = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Recent Bills
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        b.bill_id,
        b.bill_number,
        b.total_amount,
        b.amount_paid,
        b.balance,
        b.bill_status,
        b.created_at,

        v.visit_number,

        pt.patient_number,
        pt.first_name,
        pt.middle_name,
        pt.last_name

    FROM bills b

    INNER JOIN patient_visits v
        ON b.visit_id = v.visit_id

    INNER JOIN patients pt
        ON v.patient_id = pt.patient_id

    ORDER BY b.bill_id DESC

    LIMIT 10
");

$recent_bills = $stmt->fetchAll();

function patientName($row)
{
    return trim(
        $row['first_name'] . ' ' .
        ($row['middle_name'] ?? '') . ' ' .
        $row['last_name']
    );
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Billing Dashboard</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f5f7fb;
        }

        .dashboard-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.06);
        }

        .stat-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.06);
        }

        .stat-number {
            font-size: 28px;
            font-weight: 700;
        }

        .stat-label {
            color: #6c757d;
            font-size: 14px;
        }

        .table td,
        .table th {
            vertical-align: middle;
        }

        .money {
            font-weight: 600;
        }

    </style>

</head>

<body>

<div class="container-fluid py-4">

    <!-- HEADER -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                Billing Dashboard
            </h2>

            <p class="text-muted mb-0">
                Financial overview and payment management
            </p>

        </div>

        <div class="d-flex gap-2">

            <a
                href="index.php"
                class="btn btn-primary"
            >
                Billing Queue
            </a>

            <a
                href="payment_history.php"
                class="btn btn-success"
            >
                Payment History
            </a>

        </div>

    </div>


    <!-- STATISTICS -->

    <div class="row g-3 mb-4">

        <div class="col-md-3">

            <div class="card stat-card">

                <div class="card-body">

                    <div class="stat-label">
                        Total Bills
                    </div>

                    <div class="stat-number">
                        <?= number_format($stats['total_bills']) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card stat-card">

                <div class="card-body">

                    <div class="stat-label">
                        Total Billed
                    </div>

                    <div class="stat-number">
                        Ksh <?= number_format(
                            $stats['total_billed'],
                            2
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card stat-card">

                <div class="card-body">

                    <div class="stat-label">
                        Total Collected
                    </div>

                    <div class="stat-number text-success">
                        Ksh <?= number_format(
                            $stats['total_paid'],
                            2
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card stat-card">

                <div class="card-body">

                    <div class="stat-label">
                        Outstanding Balance
                    </div>

                    <div class="stat-number text-danger">
                        Ksh <?= number_format(
                            $stats['total_balance'],
                            2
                        ) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- SECOND ROW -->

    <div class="row g-3 mb-4">

        <div class="col-md-3">

            <div class="card dashboard-card">

                <div class="card-body">

                    <h6 class="text-muted">
                        Unpaid Bills
                    </h6>

                    <h3 class="text-danger">
                        <?= number_format(
                            $stats['unpaid_bills']
                        ) ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card dashboard-card">

                <div class="card-body">

                    <h6 class="text-muted">
                        Partially Paid
                    </h6>

                    <h3 class="text-warning">
                        <?= number_format(
                            $stats['partial_bills']
                        ) ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card dashboard-card">

                <div class="card-body">

                    <h6 class="text-muted">
                        Fully Paid
                    </h6>

                    <h3 class="text-success">
                        <?= number_format(
                            $stats['paid_bills']
                        ) ?>
                    </h3>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card dashboard-card">

                <div class="card-body">

                    <h6 class="text-muted">
                        Today's Collections
                    </h6>

                    <h3 class="text-primary">
                        Ksh <?= number_format(
                            $stats['today_amount'],
                            2
                        ) ?>
                    </h3>

                    <small class="text-muted">
                        <?= $stats['today_payments'] ?>
                        payment(s)
                    </small>

                </div>

            </div>

        </div>

    </div>


    <!-- RECENT PAYMENTS -->

    <div class="card dashboard-card mb-4">

        <div class="card-header bg-white">

            <div class="d-flex justify-content-between">

                <strong>
                    Recent Payments
                </strong>

                <a href="payment_history.php">
                    View All
                </a>

            </div>

        </div>

        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover mb-0">

                    <thead class="table-light">

                        <tr>

                            <th>Receipt</th>

                            <th>Patient</th>

                            <th>Bill</th>

                            <th>Method</th>

                            <th>Amount</th>

                            <th>Date</th>

                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (!$recent_payments): ?>

                        <tr>

                            <td
                                colspan="7"
                                class="text-center py-4 text-muted"
                            >
                                No payments recorded yet.
                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($recent_payments as $payment): ?>

                            <tr>

                                <td>
                                    <?= htmlspecialchars(
                                        $payment['receipt_number']
                                    ) ?>
                                </td>

                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            patientName($payment)
                                        ) ?>
                                    </strong>

                                    <br>

                                    <small class="text-muted">
                                        <?= htmlspecialchars(
                                            $payment['patient_number']
                                        ) ?>
                                    </small>

                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $payment['bill_number']
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $payment['payment_method']
                                    ) ?>
                                </td>

                                <td class="money text-success">
                                    Ksh <?= number_format(
                                        $payment['amount'],
                                        2
                                    ) ?>
                                </td>

                                <td>
                                    <?= date(
                                        'd M Y H:i',
                                        strtotime(
                                            $payment['payment_date']
                                        )
                                    ) ?>
                                </td>

                                <td>

                                    <a
                                        href="receipt.php?payment_id=<?= (int)$payment['payment_id'] ?>"
                                        class="btn btn-sm btn-outline-primary"
                                    >
                                        Receipt
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>


    <!-- RECENT BILLS -->

    <div class="card dashboard-card">

        <div class="card-header bg-white">

            <strong>
                Recent Bills
            </strong>

        </div>

        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover mb-0">

                    <thead class="table-light">

                        <tr>

                            <th>Bill No.</th>

                            <th>Patient</th>

                            <th>Total</th>

                            <th>Paid</th>

                            <th>Balance</th>

                            <th>Status</th>

                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (!$recent_bills): ?>

                        <tr>

                            <td
                                colspan="7"
                                class="text-center py-4 text-muted"
                            >
                                No bills created yet.
                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($recent_bills as $bill): ?>

                            <tr>

                                <td>
                                    <?= htmlspecialchars(
                                        $bill['bill_number']
                                    ) ?>
                                </td>

                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            patientName($bill)
                                        ) ?>
                                    </strong>

                                    <br>

                                    <small class="text-muted">
                                        <?= htmlspecialchars(
                                            $bill['patient_number']
                                        ) ?>
                                    </small>

                                </td>

                                <td>
                                    Ksh <?= number_format(
                                        $bill['total_amount'],
                                        2
                                    ) ?>
                                </td>

                                <td class="text-success">
                                    Ksh <?= number_format(
                                        $bill['amount_paid'],
                                        2
                                    ) ?>
                                </td>

                                <td class="text-danger">
                                    Ksh <?= number_format(
                                        $bill['balance'],
                                        2
                                    ) ?>
                                </td>

                                <td>

                                    <?php if ($bill['bill_status'] === 'Paid'): ?>

                                        <span class="badge bg-success">
                                            Paid
                                        </span>

                                    <?php elseif ($bill['bill_status'] === 'Partially Paid'): ?>

                                        <span class="badge bg-warning text-dark">
                                            Partially Paid
                                        </span>

                                    <?php elseif ($bill['bill_status'] === 'Cancelled'): ?>

                                        <span class="badge bg-secondary">
                                            Cancelled
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-danger">
                                            Unpaid
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <a
                                        href="invoice.php?bill_id=<?= (int)$bill['bill_id'] ?>"
                                        class="btn btn-sm btn-outline-primary"
                                    >
                                        View
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

</body>
</html>