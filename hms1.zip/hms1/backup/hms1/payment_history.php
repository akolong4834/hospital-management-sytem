<?php
require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

/*
|--------------------------------------------------------------------------
| Search Filters
|--------------------------------------------------------------------------
*/

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$payment_method = isset($_GET['payment_method'])
    ? trim($_GET['payment_method'])
    : '';

$date_from = isset($_GET['date_from'])
    ? trim($_GET['date_from'])
    : '';

$date_to = isset($_GET['date_to'])
    ? trim($_GET['date_to'])
    : '';

$where = [];
$params = [];

/*
|--------------------------------------------------------------------------
| Search
|--------------------------------------------------------------------------
*/

if ($search !== '') {

    $where[] = "
        (
            p.receipt_number LIKE ?
            OR b.bill_number LIKE ?
            OR v.visit_number LIKE ?
            OR pt.patient_number LIKE ?
            OR CONCAT(
                pt.first_name,
                ' ',
                COALESCE(pt.middle_name, ''),
                ' ',
                pt.last_name
            ) LIKE ?
        )
    ";

    $searchTerm = '%' . $search . '%';

    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

/*
|--------------------------------------------------------------------------
| Payment Method
|--------------------------------------------------------------------------
*/

if ($payment_method !== '') {

    $where[] = "p.payment_method = ?";

    $params[] = $payment_method;
}

/*
|--------------------------------------------------------------------------
| Date From
|--------------------------------------------------------------------------
*/

if ($date_from !== '') {

    $where[] = "DATE(p.payment_date) >= ?";

    $params[] = $date_from;
}

/*
|--------------------------------------------------------------------------
| Date To
|--------------------------------------------------------------------------
*/

if ($date_to !== '') {

    $where[] = "DATE(p.payment_date) <= ?";

    $params[] = $date_to;
}

/*
|--------------------------------------------------------------------------
| WHERE Clause
|--------------------------------------------------------------------------
*/

$whereSql = '';

if (!empty($where)) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

/*
|--------------------------------------------------------------------------
| Get Payments
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        p.payment_id,
        p.receipt_number,
        p.payment_method,
        p.amount,
        p.transaction_reference,
        p.payment_notes,
        p.payment_date,

        b.bill_id,
        b.bill_number,
        b.total_amount,
        b.amount_paid,
        b.balance,
        b.bill_status,

        v.visit_number,

        pt.patient_number,
        pt.first_name,
        pt.middle_name,
        pt.last_name,
        pt.phone

    FROM payments p

    INNER JOIN bills b
        ON p.bill_id = b.bill_id

    INNER JOIN patient_visits v
        ON b.visit_id = v.visit_id

    INNER JOIN patients pt
        ON v.patient_id = pt.patient_id

    $whereSql

    ORDER BY p.payment_id DESC

    LIMIT 500
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$payments = $stmt->fetchAll();

/*
|--------------------------------------------------------------------------
| Summary
|--------------------------------------------------------------------------
*/

$total_transactions = count($payments);
$total_collected = 0;

foreach ($payments as $payment) {
    $total_collected += (float)$payment['amount'];
}

function fullPatientName($row)
{
    return trim(
        $row['first_name'] . ' ' .
        ($row['middle_name'] ?? '') . ' ' .
        $row['last_name']
    );
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Payment History</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f5f7fb;
        }

        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.06);
        }

        .summary-number {
            font-size: 25px;
            font-weight: 700;
        }

        .table td,
        .table th {
            vertical-align: middle;
        }

    </style>

</head>

<body>

<div class="container-fluid py-4">

    <!-- HEADER -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="mb-1">
                Payment History
            </h2>

            <p class="text-muted mb-0">
                Search and review all patient payments
            </p>

        </div>

        <div class="d-flex gap-2">

            <a
                href="dashboard.php"
                class="btn btn-secondary"
            >
                Dashboard
            </a>

            <a
                href="index.php"
                class="btn btn-primary"
            >
                Billing Queue
            </a>

        </div>

    </div>


    <!-- FILTERS -->

    <div class="card mb-4">

        <div class="card-body">

            <form method="GET">

                <div class="row g-3">

                    <div class="col-md-4">

                        <label class="form-label">
                            Search
                        </label>

                        <input
                            type="text"
                            name="search"
                            class="form-control"
                            value="<?= htmlspecialchars($search) ?>"
                            placeholder="Patient, receipt, bill or visit number"
                        >

                    </div>


                    <div class="col-md-2">

                        <label class="form-label">
                            Payment Method
                        </label>

                        <select
                            name="payment_method"
                            class="form-select"
                        >

                            <option value="">
                                All Methods
                            </option>

                            <?php
                            $methods = [
                                'Cash',
                                'M-Pesa',
                                'Card',
                                'Insurance',
                                'Bank',
                                'Other'
                            ];
                            ?>

                            <?php foreach ($methods as $method): ?>

                                <option
                                    value="<?= htmlspecialchars($method) ?>"
                                    <?= $payment_method === $method
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= htmlspecialchars($method) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="col-md-2">

                        <label class="form-label">
                            From
                        </label>

                        <input
                            type="date"
                            name="date_from"
                            class="form-control"
                            value="<?= htmlspecialchars($date_from) ?>"
                        >

                    </div>


                    <div class="col-md-2">

                        <label class="form-label">
                            To
                        </label>

                        <input
                            type="date"
                            name="date_to"
                            class="form-control"
                            value="<?= htmlspecialchars($date_to) ?>"
                        >

                    </div>


                    <div class="col-md-2 d-flex align-items-end">

                        <div class="d-flex gap-2 w-100">

                            <button
                                type="submit"
                                class="btn btn-primary flex-fill"
                            >
                                Search
                            </button>

                            <a
                                href="payment_history.php"
                                class="btn btn-outline-secondary"
                            >
                                Clear
                            </a>

                        </div>

                    </div>

                </div>

            </form>

        </div>

    </div>


    <!-- SUMMARY -->

    <div class="row g-3 mb-4">

        <div class="col-md-4">

            <div class="card">

                <div class="card-body">

                    <div class="text-muted">
                        Transactions Found
                    </div>

                    <div class="summary-number">
                        <?= number_format($total_transactions) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card">

                <div class="card-body">

                    <div class="text-muted">
                        Total Collected
                    </div>

                    <div class="summary-number text-success">
                        Ksh <?= number_format(
                            $total_collected,
                            2
                        ) ?>
                    </div>

                </div>

            </div>

        </div>


        <div class="col-md-4">

            <div class="card">

                <div class="card-body">

                    <div class="text-muted">
                        Report Period
                    </div>

                    <div class="summary-number">

                        <?php if ($date_from || $date_to): ?>

                            <?= htmlspecialchars(
                                $date_from ?: 'Beginning'
                            ) ?>

                            -

                            <?= htmlspecialchars(
                                $date_to ?: 'Today'
                            ) ?>

                        <?php else: ?>

                            All Dates

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- PAYMENT TABLE -->

    <div class="card">

        <div class="card-header bg-white">

            <strong>
                Payment Transactions
            </strong>

        </div>

        <div class="card-body p-0">

            <div class="table-responsive">

                <table class="table table-hover table-striped mb-0">

                    <thead class="table-dark">

                        <tr>

                            <th>#</th>

                            <th>Receipt</th>

                            <th>Date</th>

                            <th>Patient</th>

                            <th>Patient No.</th>

                            <th>Bill No.</th>

                            <th>Method</th>

                            <th>Reference</th>

                            <th>Amount</th>

                            <th>Bill Balance</th>

                            <th>Action</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php if (!$payments): ?>

                        <tr>

                            <td
                                colspan="11"
                                class="text-center py-5 text-muted"
                            >
                                No payment records found.
                            </td>

                        </tr>

                    <?php else: ?>

                        <?php foreach ($payments as $index => $payment): ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>

                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            $payment['receipt_number']
                                        ) ?>
                                    </strong>

                                </td>

                                <td>

                                    <?= date(
                                        'd/m/Y',
                                        strtotime(
                                            $payment['payment_date']
                                        )
                                    ) ?>

                                    <br>

                                    <small class="text-muted">

                                        <?= date(
                                            'H:i',
                                            strtotime(
                                                $payment['payment_date']
                                            )
                                        ) ?>

                                    </small>

                                </td>

                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            fullPatientName($payment)
                                        ) ?>
                                    </strong>

                                    <?php if (!empty($payment['phone'])): ?>

                                        <br>

                                        <small class="text-muted">
                                            <?= htmlspecialchars(
                                                $payment['phone']
                                            ) ?>
                                        </small>

                                    <?php endif; ?>

                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $payment['patient_number']
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $payment['bill_number']
                                    ) ?>
                                </td>

                                <td>

                                    <?php
                                    $badgeClass = 'bg-secondary';

                                    if ($payment['payment_method'] === 'Cash') {
                                        $badgeClass = 'bg-success';
                                    } elseif ($payment['payment_method'] === 'M-Pesa') {
                                        $badgeClass = 'bg-primary';
                                    } elseif ($payment['payment_method'] === 'Card') {
                                        $badgeClass = 'bg-info text-dark';
                                    } elseif ($payment['payment_method'] === 'Insurance') {
                                        $badgeClass = 'bg-warning text-dark';
                                    }
                                    ?>

                                    <span class="badge <?= $badgeClass ?>">
                                        <?= htmlspecialchars(
                                            $payment['payment_method']
                                        ) ?>
                                    </span>

                                </td>

                                <td>

                                    <?php if (
                                        !empty(
                                            $payment['transaction_reference']
                                        )
                                    ): ?>

                                        <?= htmlspecialchars(
                                            $payment['transaction_reference']
                                        ) ?>

                                    <?php else: ?>

                                        <span class="text-muted">
                                            —
                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td class="text-success fw-bold">

                                    Ksh <?= number_format(
                                        $payment['amount'],
                                        2
                                    ) ?>

                                </td>

                                <td>

                                    <?php if (
                                        (float)$payment['balance'] <= 0
                                    ): ?>

                                        <span class="badge bg-success">
                                            Paid
                                        </span>

                                    <?php else: ?>

                                        <span class="text-danger fw-bold">

                                            Ksh <?= number_format(
                                                $payment['balance'],
                                                2
                                            ) ?>

                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <div class="d-flex gap-1">

                                        <a
                                            href="receipt.php?payment_id=<?= (int)$payment['payment_id'] ?>"
                                            class="btn btn-sm btn-outline-primary"
                                        >
                                            Receipt
                                        </a>

                                        <a
                                            href="invoice.php?bill_id=<?= (int)$payment['bill_id'] ?>"
                                            class="btn btn-sm btn-outline-secondary"
                                        >
                                            Bill
                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

</body>
</html>