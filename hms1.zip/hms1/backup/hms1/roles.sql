CREATE TABLE IF NOT EXISTS roles (
    role_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255) NULL,
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS permissions (
    permission_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    permission_name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;





INSERT IGNORE INTO roles
    (role_name, description)
VALUES
    ('Administrator', 'Full access to the hospital management system'),
    ('Receptionist', 'Patient registration and reception operations'),
    ('Nurse', 'Triage and nursing operations'),
    ('Clinician', 'Consultation and clinical operations'),
    ('Laboratory', 'Laboratory investigations and results'),
    ('Pharmacist', 'Prescriptions, dispensing and pharmacy stock'),
    ('Cashier', 'Billing, payments and receipts'),
    ('Records Officer', 'Patient records and medical records management');
	
	
	
	INSERT IGNORE INTO permissions
    (permission_name, description)
VALUES

('patients.view',
 'View patient records'),

('patients.create',
 'Register new patients'),

('patients.edit',
 'Edit patient information'),

('visits.create',
 'Create patient visits'),

('visits.view',
 'View patient visits'),

('triage.view',
 'View triage queue'),

('triage.create',
 'Perform patient triage'),

('consultation.view',
 'View consultation queue'),

('consultation.create',
 'Perform patient consultation'),

('laboratory.view',
 'View laboratory queue'),

('laboratory.order',
 'Create laboratory orders'),

('laboratory.process',
 'Process laboratory tests'),

('laboratory.results',
 'Enter laboratory results'),

('pharmacy.view',
 'View pharmacy queue'),

('pharmacy.prescribe',
 'Create prescriptions'),

('pharmacy.dispense',
 'Dispense medicines'),

('pharmacy.stock',
 'Manage pharmacy stock'),

('billing.view',
 'View billing'),

('billing.create',
 'Create bills'),

('billing.payment',
 'Receive payments'),

('billing.receipt',
 'View and print receipts'),

('reports.view',
 'View system reports'),

('users.view',
 'View system users'),

('users.create',
 'Create system users'),

('users.edit',
 'Edit system users'),

('users.delete',
 'Deactivate system users'),

('system.settings',
 'Manage system settings');