INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r
JOIN permissions p
WHERE r.role_name = 'Pharmacist'
AND p.permission_name IN (
    'patients.view',
    'pharmacy.view',
    'pharmacy.prescribe',
    'pharmacy.dispense',
    'pharmacy.stock'
);