INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id
FROM roles r
JOIN permissions p
WHERE r.role_name = 'Clinician'
AND p.permission_name IN (
    'patients.view',
    'visits.view',
    'triage.view',
    'consultation.view',
    'consultation.create',
    'laboratory.view',
    'laboratory.order',
    'pharmacy.view',
    'pharmacy.prescribe'
);