<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

require_role('Administrator');

/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$patients = (int)$pdo
    ->query("SELECT COUNT(*) FROM patients")
    ->fetchColumn();

$visits_today = (int)$pdo
    ->query("
        SELECT COUNT(*)
        FROM patient_visits
        WHERE visit_date = CURDATE()
    ")
    ->fetchColumn();

$users = (int)$pdo
    ->query("
        SELECT COUNT(*)
        FROM users
        WHERE status = 'Active'
    ")
    ->fetchColumn();

$pending_bills = (int)$pdo
    ->query("
        SELECT COUNT(*)
        FROM bills
        WHERE bill_status IN ('Unpaid','Partially Paid')
    ")
    ->fetchColumn();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Administrator Dashboard</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">

    <div class="container-fluid">

        <span class="navbar-brand">
            Hospital Management System
        </span>

        <div class="text-white">

            <?= htmlspecialchars(
                get_current_user_name()
            ) ?>

            |

            Administrator

            <a
                href="../auth/logout.php"
                class="btn btn-light btn-sm ms-2"
            >
                Logout
            </a>

        </div>

    </div>

</nav>


<div class="container-fluid py-4">

    <h2>
        Administrator Dashboard
    </h2>

    <p class="text-muted">
        System administration and overall hospital operations
    </p>


    <div class="row g-3 mt-2">

        <div class="col-md-3">

            <div class="card shadow-sm">

                <div class="card-body">

                    <h6 class="text-muted">
                        Total Patients
                    </h6>

                    <h2>
                        <?= number_format($patients) ?>
                    </h2>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card shadow-sm">

                <div class="card-body">

                    <h6 class="text-muted">
                        Today's Visits
                    </h6>

                    <h2>
                        <?= number_format($visits_today) ?>
                    </h2>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card shadow-sm">

                <div class="card-body">

                    <h6 class="text-muted">
                        Active Users
                    </h6>

                    <h2>
                        <?= number_format($users) ?>
                    </h2>

                </div>

            </div>

        </div>


        <div class="col-md-3">

            <div class="card shadow-sm">

                <div class="card-body">

                    <h6 class="text-muted">
                        Outstanding Bills
                    </h6>

                    <h2>
                        <?= number_format($pending_bills) ?>
                    </h2>

                </div>

            </div>

        </div>

    </div>


    <div class="row g-3 mt-3">

        <div class="col-md-3">

            <a
                href="../patients/"
                class="btn btn-primary w-100 p-3"
            >
                Patient Management
            </a>

        </div>

        <div class="col-md-3">

            <a
                href="../billing/dashboard.php"
                class="btn btn-success w-100 p-3"
            >
                Billing
            </a>

        </div>

        <div class="col-md-3">

            <a
                href="../laboratory/queue.php"
                class="btn btn-info w-100 p-3"
            >
                Laboratory
            </a>

        </div>

        <div class="col-md-3">

            <a
                href="../pharmacy/queue.php"
                class="btn btn-warning w-100 p-3"
            >
                Pharmacy
            </a>

        </div>

    </div>

</div>

</body>
</html>