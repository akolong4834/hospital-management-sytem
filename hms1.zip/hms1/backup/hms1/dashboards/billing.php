<?php

require_once "../includes/db.php";
require_once "../includes/auth.php";

require_role(['Administrator', 'Cashier']);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Billing Dashboard</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

</head>

<body class="bg-light">

<nav class="navbar navbar-dark bg-success">

    <div class="container-fluid">

        <span class="navbar-brand">
            Hospital Management System
        </span>

        <div class="text-white">

            <?= htmlspecialchars(
                get_current_user_name()
            ) ?>

            |

            <?= htmlspecialchars(
                get_current_user_role()
            ) ?>

            <a
                href="../auth/logout.php"
                class="btn btn-light btn-sm ms-2"
            >
                Logout
            </a>

        </div>

    </div>

</nav>


<div class="container py-4">

    <h2>
        Billing & Finance Dashboard
    </h2>

    <p class="text-muted">
        Manage bills, payments and receipts.
    </p>


    <div class="row g-3 mt-3">

        <div class="col-md-4">

            <a
                href="../billing/dashboard.php"
                class="card text-decoration-none shadow-sm"
            >

                <div class="card-body">

                    <h4>
                        Billing Dashboard
                    </h4>

                    <p class="text-muted">
                        View billing statistics and outstanding balances.
                    </p>

                </div>

            </a>

        </div>


        <div class="col-md-4">

            <a
                href="../billing/index.php"
                class="card text-decoration-none shadow-sm"
            >

                <div class="card-body">

                    <h4>
                        Billing Queue
                    </h4>

                    <p class="text-muted">
                        Create patient bills.
                    </p>

                </div>

            </a>

        </div>


        <div class="col-md-4">

            <a
                href="../billing/payment_history.php"
                class="card text-decoration-none shadow-sm"
            >

                <div class="card-body">

                    <h4>
                        Payment History
                    </h4>

                    <p class="text-muted">
                        Search payments and print receipts.
                    </p>

                </div>

            </a>

        </div>

    </div>

</div>

</body>
</html>