ALTER TABLE users
ADD COLUMN status ENUM('Active','Inactive','Suspended')
NOT NULL DEFAULT 'Active';

ALTER TABLE users
ADD COLUMN role VARCHAR(50)
NOT NULL DEFAULT 'Receptionist';