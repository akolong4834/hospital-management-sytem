<?php

require_once "includes/db.php";
require_once "includes/auth.php";

check_authentication();

$role = get_current_user_role();

switch ($role) {

    case 'Administrator':

        header("Location: dashboards/admin.php");
        break;


    case 'Receptionist':

        header("Location: dashboards/reception.php");
        break;


    case 'Nurse':

        header("Location: dashboards/nurse.php");
        break;


    case 'Clinician':

        header("Location: dashboards/clinician.php");
        break;


    case 'Laboratory':

        header("Location: dashboards/laboratory.php");
        break;


    case 'Pharmacist':

        header("Location: dashboards/pharmacy.php");
        break;


    case 'Cashier':

        header("Location: dashboards/billing.php");
        break;


    case 'Records Officer':

        header("Location: dashboards/records.php");
        break;


    default:

        session_destroy();

        header(
            "Location: /hospital_management/auth/login.php?error=role"
        );

        break;
}

exit();

?>