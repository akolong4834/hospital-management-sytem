<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

function check_authentication()
{
    if (
        !isset($_SESSION['user_id']) ||
        empty($_SESSION['user_id'])
    ) {

        header(
            "Location: /hospital_management/auth/login.php"
        );

        exit();
    }
}


/*
|--------------------------------------------------------------------------
| Current User ID
|--------------------------------------------------------------------------
*/

function get_current_user_id()
{
    return isset($_SESSION['user_id'])
        ? (int)$_SESSION['user_id']
        : null;
}


/*
|--------------------------------------------------------------------------
| Current Username
|--------------------------------------------------------------------------
*/

function get_current_username()
{
    return isset($_SESSION['username'])
        ? $_SESSION['username']
        : '';
}


/*
|--------------------------------------------------------------------------
| Current User Name
|--------------------------------------------------------------------------
*/

function get_current_user_name()
{
    if (isset($_SESSION['full_name'])) {
        return $_SESSION['full_name'];
    }

    if (isset($_SESSION['username'])) {
        return $_SESSION['username'];
    }

    return "User";
}


/*
|--------------------------------------------------------------------------
| Current Role
|--------------------------------------------------------------------------
*/

function get_current_user_role()
{
    return isset($_SESSION['role'])
        ? $_SESSION['role']
        : null;
}


/*
|--------------------------------------------------------------------------
| Check Role
|--------------------------------------------------------------------------
*/

function has_role($roles)
{
    $current_role = get_current_user_role();

    if (!$current_role) {
        return false;
    }

    if (!is_array($roles)) {
        $roles = [$roles];
    }

    return in_array($current_role, $roles, true);
}


/*
|--------------------------------------------------------------------------
| Require Role
|--------------------------------------------------------------------------
*/

function require_role($roles)
{
    check_authentication();

    if (!has_role($roles)) {

        http_response_code(403);

        die("
            <div style='
                font-family: Arial;
                padding: 40px;
                text-align: center;
            '>

                <h1>403 - Access Denied</h1>

                <p>
                    You do not have permission to access
                    this section of the system.
                </p>

                <a href='/hospital_management/dashboard.php'>
                    Return to Dashboard
                </a>

            </div>
        ");
    }
}


/*
|--------------------------------------------------------------------------
| Check Permission
|--------------------------------------------------------------------------
*/

function has_permission($permission_name)
{
    global $pdo;

    check_authentication();

    /*
    |--------------------------------------------------------------------------
    | Administrator has all permissions
    |--------------------------------------------------------------------------
    */

    if (get_current_user_role() === 'Administrator') {
        return true;
    }

    if (!$pdo) {
        return false;
    }

    $sql = "
        SELECT COUNT(*)
        FROM role_permissions rp

        INNER JOIN roles r
            ON rp.role_id = r.role_id

        INNER JOIN permissions p
            ON rp.permission_id = p.permission_id

        WHERE r.role_name = ?
        AND p.permission_name = ?
        AND r.status = 'Active'
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        get_current_user_role(),
        $permission_name
    ]);

    return (int)$stmt->fetchColumn() > 0;
}


/*
|--------------------------------------------------------------------------
| Require Permission
|--------------------------------------------------------------------------
*/

function require_permission($permission_name)
{
    check_authentication();

    if (!has_permission($permission_name)) {

        http_response_code(403);

        die("
            <div style='
                font-family: Arial;
                padding: 40px;
                text-align: center;
            '>

                <h1>403 - Access Denied</h1>

                <p>
                    You do not have permission to perform
                    this operation.
                </p>

                <a href='/hospital_management/dashboard.php'>
                    Return to Dashboard
                </a>

            </div>
        ");
    }
}


/*
|--------------------------------------------------------------------------
| CSRF Token
|--------------------------------------------------------------------------
*/

function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {

        $_SESSION['csrf_token'] = bin2hex(
            random_bytes(32)
        );
    }

    return $_SESSION['csrf_token'];
}


/*
|--------------------------------------------------------------------------
| Verify CSRF Token
|--------------------------------------------------------------------------
*/

function verify_csrf_token($token)
{
    return isset($_SESSION['csrf_token'])
        && hash_equals(
            $_SESSION['csrf_token'],
            $token
        );
}
?>