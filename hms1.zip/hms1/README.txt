HOSPITAL MANAGEMENT SYSTEM - DATABASE PACKAGE
==============================================

FILE:
database/hospital_management.sql

REQUIREMENTS
------------
- MySQL 8.x or MariaDB 10.5+
- PHP 8.1+ recommended
- Apache/Nginx for the later PHP modules
- phpMyAdmin is optional

INSTALLATION USING XAMPP + PHPMYADMIN
-------------------------------------
1. Install/start XAMPP.
2. Start Apache and MySQL.
3. Open http://localhost/phpmyadmin/
4. Click Import.
5. Select database/hospital_management.sql.
6. Click Go.
7. Confirm that database "hospital_management" was created.

ALTERNATIVE: MYSQL COMMAND LINE
--------------------------------
mysql -u root -p < database/hospital_management.sql

If your MySQL root account has no password in XAMPP, use:
mysql -u root < database/hospital_management.sql

DATABASE CONNECTION FOR THE NEXT PHP MODULES
--------------------------------------------
Database: hospital_management
Host: localhost
User: root
Password: (your MySQL password)
Port: 3306

The next PHP modules should use PDO with prepared statements and transactions.

WORKFLOW
--------
Registration
 -> Visit/Encounter
 -> Triage
 -> Consultation
 -> Laboratory and/or Prescription
 -> Pharmacy
 -> Billing
 -> Payment
 -> Receipt
 -> Completed Visit

IMPORTANT
---------
The SQL file contains the core schema and seed reference data. It does not create
a production login password. The PHP authentication module should create users
using password_hash(), never by storing plain-text passwords.

NEXT MODULES
------------
1. Database connection/configuration
2. Authentication and role-based access
3. Patient registration/search/edit/history
4. Visit creation and queues
5. Triage
6. Consultation
7. Laboratory
8. Pharmacy/inventory
9. Billing
10. Payments and receipts
11. Reports/dashboard
12. M-Pesa Daraja integration (after the core payment workflow is working)

SECURITY
--------
For production use:
- Use HTTPS.
- Use strong database credentials.
- Restrict database access.
- Use PHP sessions securely.
- Validate all input server-side.
- Use CSRF protection for forms.
- Use prepared statements.
- Keep audit logs.
- Back up the database regularly.
- Apply appropriate health-data privacy and access controls.
