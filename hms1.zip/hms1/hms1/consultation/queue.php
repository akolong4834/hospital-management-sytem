<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
check_authentication();
$sql="SELECT v.visit_id,v.visit_number,v.visit_date,v.visit_type,v.department,v.chief_complaint,
             p.patient_number,CONCAT_WS(' ',p.first_name,p.middle_name,p.last_name) AS patient_name,
             p.gender,p.phone,COALESCE(t.priority,'Routine') AS priority
      FROM patient_visits v INNER JOIN patients p ON p.patient_id=v.patient_id
      LEFT JOIN triage t ON t.visit_id=v.visit_id
      WHERE v.status='Consultation'
      ORDER BY CASE COALESCE(t.priority,'Routine') WHEN 'Emergency' THEN 1 WHEN 'Urgent' THEN 2 ELSE 3 END,v.visit_id ASC";
$rows=$pdo->query($sql)->fetchAll();
include __DIR__.'/../includes/header.php';
?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3"><div><h3 class="mb-1">Consultation Queue</h3><p class="text-muted mb-0">Patients who have completed triage and are ready for clinician review.</p></div><span class="badge bg-success"><?= count($rows) ?> ready</span></div>
  <?php if(isset($_GET['saved'])):?><div class="alert alert-success">Triage saved successfully. The patient has been moved to the consultation queue.</div><?php endif;?>
  <div class="card shadow-sm"><div class="card-body p-0">
  <?php if(!$rows):?><div class="p-4 text-center text-muted">No patients are currently waiting for consultation.</div>
  <?php else:?><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead class="table-light"><tr><th>#</th><th>Visit</th><th>Patient</th><th>Department</th><th>Complaint</th><th>Priority</th><th>Action</th></tr></thead><tbody>
  <?php foreach($rows as $i=>$r):$badge=$r['priority']==='Emergency'?'danger':($r['priority']==='Urgent'?'warning text-dark':'secondary');?>
  <tr><td><?= $i+1?></td><td><?= htmlspecialchars($r['visit_number'])?></td><td><strong><?= htmlspecialchars($r['patient_name'])?></strong><br><small class="text-muted"><?= htmlspecialchars($r['patient_number'])?></small></td><td><?= htmlspecialchars($r['department'])?></td><td><?= htmlspecialchars(mb_strimwidth($r['chief_complaint']??'',0,60,'...'))?></td><td><span class="badge bg-<?= $badge?>"><?= htmlspecialchars($r['priority'])?></span></td><td><span class="text-muted small">Consultation module next</span></td></tr>
  <?php endforeach;?></tbody></table></div><?php endif;?>
  </div></div>
</div>
<?php include __DIR__.'/../includes/footer.php'; ?>