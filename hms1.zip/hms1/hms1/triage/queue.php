<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
check_authentication();

$sql = "SELECT v.visit_id, v.visit_number, v.visit_date, v.status,
               p.patient_number,
               CONCAT_WS(' ', p.first_name, p.middle_name, p.last_name) AS patient_name,
               p.gender, p.phone,
               COALESCE(t.priority, 'Routine') AS priority,
               t.assessed_at
        FROM patient_visits v
        INNER JOIN patients p ON p.patient_id = v.patient_id
        LEFT JOIN triage t ON t.visit_id = v.visit_id
        WHERE v.status IN ('Registered','Triage')
        ORDER BY CASE COALESCE(t.priority,'Routine')
                    WHEN 'Emergency' THEN 1 WHEN 'Urgent' THEN 2 ELSE 3 END,
                 v.visit_id ASC";
$rows = $pdo->query($sql)->fetchAll();

include __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div><h3 class="mb-1">Triage Queue</h3><p class="text-muted mb-0">Patients waiting for nursing triage assessment.</p></div>
    <span class="badge bg-primary"><?= count($rows) ?> waiting</span>
  </div>
  <div class="card shadow-sm"><div class="card-body p-0">
    <?php if (!$rows): ?>
      <div class="p-4 text-center text-muted">No patients are currently waiting for triage.</div>
    <?php else: ?>
    <div class="table-responsive"><table class="table table-hover align-middle mb-0">
      <thead class="table-light"><tr><th>#</th><th>Visit</th><th>Patient</th><th>Gender</th><th>Phone</th><th>Priority</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $i => $r): ?>
        <?php $badge = $r['priority']==='Emergency'?'danger':($r['priority']==='Urgent'?'warning text-dark':'secondary'); ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><?= htmlspecialchars($r['visit_number']) ?></td>
          <td><strong><?= htmlspecialchars($r['patient_name']) ?></strong><br><small class="text-muted"><?= htmlspecialchars($r['patient_number']) ?></small></td>
          <td><?= htmlspecialchars($r['gender']) ?></td><td><?= htmlspecialchars($r['phone']) ?></td>
          <td><span class="badge bg-<?= $badge ?>"><?= htmlspecialchars($r['priority']) ?></span></td>
          <td><span class="badge bg-info text-dark"><?= htmlspecialchars($r['status']) ?></span></td>
          <td><a class="btn btn-sm btn-primary" href="assessment.php?visit_id=<?= (int)$r['visit_id'] ?>"><?= $r['assessed_at']?'Update Triage':'Assess' ?></a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div></div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>