<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
check_authentication();
if ($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: queue.php');exit;}
$visit_id=filter_input(INPUT_POST,'visit_id',FILTER_VALIDATE_INT); if(!$visit_id) die('Invalid visit ID.');
$priority=trim($_POST['priority']??'Routine'); if(!in_array($priority,['Routine','Urgent','Emergency'],true)) $priority='Routine';
function n($v){$v=trim((string)$v);return $v===''?null:$v;}
$weight=n($_POST['weight_kg']??''); $height=n($_POST['height_cm']??''); $temp=n($_POST['temperature_c']??'');
$systolic=n($_POST['systolic_bp']??''); $diastolic=n($_POST['diastolic_bp']??''); $pulse=n($_POST['pulse_bpm']??'');
$resp=n($_POST['respiratory_rate']??''); $spo2=n($_POST['spo2_percent']??''); $pain=n($_POST['pain_score']??'');
$symptoms=trim($_POST['symptoms']??''); $notes=trim($_POST['notes']??'');
try{
  $check=$pdo->prepare("SELECT visit_id FROM patient_visits WHERE visit_id=?");$check->execute([$visit_id]);if(!$check->fetchColumn())die('Visit not found.');
  $pdo->beginTransaction();
  $sql="INSERT INTO triage
    (visit_id,weight_kg,height_cm,temperature_c,systolic_bp,diastolic_bp,pulse_bpm,respiratory_rate,spo2_percent,pain_score,priority,symptoms,notes,assessed_by,assessed_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())
    ON DUPLICATE KEY UPDATE weight_kg=VALUES(weight_kg),height_cm=VALUES(height_cm),temperature_c=VALUES(temperature_c),
    systolic_bp=VALUES(systolic_bp),diastolic_bp=VALUES(diastolic_bp),pulse_bpm=VALUES(pulse_bpm),respiratory_rate=VALUES(respiratory_rate),
    spo2_percent=VALUES(spo2_percent),pain_score=VALUES(pain_score),priority=VALUES(priority),symptoms=VALUES(symptoms),
    notes=VALUES(notes),assessed_by=VALUES(assessed_by),assessed_at=NOW()";
  $stmt=$pdo->prepare($sql);$stmt->execute([$visit_id,$weight,$height,$temp,$systolic,$diastolic,$pulse,$resp,$spo2,$pain,$priority,$symptoms,$notes,$_SESSION['user_id']??null]);
  $stmt=$pdo->prepare("UPDATE patient_visits SET status='Consultation' WHERE visit_id=?");$stmt->execute([$visit_id]);
  $pdo->commit();header('Location: ../consultation/queue.php?saved=1');exit;
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();die('Unable to save triage: '.htmlspecialchars($e->getMessage()));}
