<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
check_authentication();

$visit_id = filter_input(INPUT_GET, 'visit_id', FILTER_VALIDATE_INT);
if (!$visit_id) die('Invalid visit ID.');

$stmt = $pdo->prepare("SELECT v.*, p.patient_number, p.first_name, p.middle_name, p.last_name,
                              p.gender, p.date_of_birth, p.phone, p.blood_group, p.allergies
                       FROM patient_visits v INNER JOIN patients p ON p.patient_id=v.patient_id
                       WHERE v.visit_id=?");
$stmt->execute([$visit_id]);
$visit = $stmt->fetch();
if (!$visit) die('Visit not found.');

$stmt = $pdo->prepare("SELECT * FROM triage WHERE visit_id=?");
$stmt->execute([$visit_id]);
$triage = $stmt->fetch() ?: [];

include __DIR__ . '/../includes/header.php';
function oldv($key,$default=''){ global $triage; return htmlspecialchars((string)($triage[$key]??$default)); }
?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div><h3 class="mb-1">Triage Assessment</h3><div class="text-muted"><?= htmlspecialchars($visit['visit_number']) ?> — <?= htmlspecialchars(trim($visit['first_name'].' '.$visit['middle_name'].' '.$visit['last_name'])) ?></div></div>
    <a href="queue.php" class="btn btn-outline-secondary">Back to Queue</a>
  </div>

  <div class="alert alert-light border">
    <div class="row">
      <div class="col-md-3"><strong>Patient No:</strong><br><?= htmlspecialchars($visit['patient_number']) ?></div>
      <div class="col-md-3"><strong>Gender:</strong><br><?= htmlspecialchars($visit['gender']) ?></div>
      <div class="col-md-3"><strong>Phone:</strong><br><?= htmlspecialchars($visit['phone']) ?></div>
      <div class="col-md-3"><strong>Visit Type:</strong><br><?= htmlspecialchars($visit['visit_type']) ?></div>
    </div><hr>
    <strong>Chief Complaint:</strong><div><?= nl2br(htmlspecialchars($visit['chief_complaint']??'Not recorded')) ?></div>
    <?php if (!empty($visit['allergies'])): ?><div class="mt-2"><strong>Known Allergies:</strong> <?= nl2br(htmlspecialchars($visit['allergies'])) ?></div><?php endif; ?>
  </div>

  <form method="post" action="save.php" class="card shadow-sm">
    <div class="card-header bg-primary text-white">Vital Signs & Nursing Assessment</div>
    <div class="card-body"><input type="hidden" name="visit_id" value="<?= (int)$visit_id ?>">
      <div class="row g-3">
        <div class="col-md-3"><label class="form-label">Weight (kg)</label><input type="number" step="0.01" min="0" max="500" name="weight_kg" class="form-control" value="<?= oldv('weight_kg') ?>"></div>
        <div class="col-md-3"><label class="form-label">Height (cm)</label><input type="number" step="0.1" min="0" max="250" name="height_cm" class="form-control" value="<?= oldv('height_cm') ?>"></div>
        <div class="col-md-3"><label class="form-label">Temperature (°C)</label><input type="number" step="0.1" min="25" max="45" name="temperature_c" class="form-control" value="<?= oldv('temperature_c') ?>"></div>
        <div class="col-md-3"><label class="form-label">SpO₂ (%)</label><input type="number" step="0.1" min="50" max="100" name="spo2_percent" class="form-control" value="<?= oldv('spo2_percent') ?>"></div>
        <div class="col-md-3"><label class="form-label">Systolic BP (mmHg)</label><input type="number" min="40" max="300" name="systolic_bp" class="form-control" value="<?= oldv('systolic_bp') ?>"></div>
        <div class="col-md-3"><label class="form-label">Diastolic BP (mmHg)</label><input type="number" min="20" max="200" name="diastolic_bp" class="form-control" value="<?= oldv('diastolic_bp') ?>"></div>
        <div class="col-md-3"><label class="form-label">Pulse (bpm)</label><input type="number" min="20" max="250" name="pulse_bpm" class="form-control" value="<?= oldv('pulse_bpm') ?>"></div>
        <div class="col-md-3"><label class="form-label">Respiratory Rate (/min)</label><input type="number" min="5" max="80" name="respiratory_rate" class="form-control" value="<?= oldv('respiratory_rate') ?>"></div>
        <div class="col-md-4"><label class="form-label">Pain Score (0–10)</label><input type="number" min="0" max="10" name="pain_score" class="form-control" value="<?= oldv('pain_score') ?>"></div>
        <div class="col-md-4"><label class="form-label">Priority <span class="text-danger">*</span></label>
          <select name="priority" class="form-select" required>
            <?php foreach(['Routine','Urgent','Emergency'] as $p): ?><option value="<?= $p ?>" <?= (($triage['priority']??'Routine')===$p)?'selected':'' ?>><?= $p ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4"><label class="form-label">Assessed By</label><input class="form-control" value="<?= htmlspecialchars($_SESSION['full_name']??$_SESSION['username']??'Logged-in user') ?>" readonly></div>
        <div class="col-md-6"><label class="form-label">Presenting Symptoms</label><textarea name="symptoms" class="form-control" rows="5"><?= oldv('symptoms') ?></textarea></div>
        <div class="col-md-6"><label class="form-label">Nursing Notes</label><textarea name="notes" class="form-control" rows="5"><?= oldv('notes') ?></textarea></div>
      </div>
    </div>
    <div class="card-footer d-flex justify-content-between"><a href="queue.php" class="btn btn-outline-secondary">Cancel</a><button class="btn btn-success">Save Triage & Send to Consultation</button></div>
  </form>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>