# HMS1 Triage Module

Workflow:
Registration -> New Visit -> Triage Queue -> Triage Assessment -> Consultation Queue

1. Back up the `hospital_management` database.
2. Extract this ZIP into `C:\xampp\htdocs\hms1` and merge the `triage`, `consultation`, and `database` folders.
3. Do not overwrite your existing `includes/auth.php`, `includes/header.php`, or `config/database.php`.
4. If Phase 2 already created the `triage` table, do not recreate it.
5. If it does not exist, run `database/triage_module.sql` in phpMyAdmin.

Open:
- Triage: http://localhost/hms1/triage/queue.php
- Consultation queue: http://localhost/hms1/consultation/queue.php

The module records vital signs, pain score, priority, symptoms and nursing notes, records the logged-in assessor, and changes the visit status to `Consultation` after saving.

Expected triage columns:
visit_id, weight_kg, height_cm, temperature_c, systolic_bp, diastolic_bp,
pulse_bpm, respiratory_rate, spo2_percent, pain_score, priority, symptoms,
notes, assessed_by, assessed_at.

Next stage: Consultation -> Diagnosis -> Laboratory/Prescription -> Billing -> Payment -> Receipt -> Completed
