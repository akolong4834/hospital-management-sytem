<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

check_authentication();

/*
|--------------------------------------------------------------------------
| Get medicines
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        medicine_id,
        medicine_code,
        medicine_name,
        generic_name,
        category,
        dosage_form,
        strength,
        unit,
        selling_price,
        stock_quantity,
        reorder_level,
        status,
        created_at
    FROM medicines
    ORDER BY medicine_name ASC
");

$medicines = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../includes/header.php';

?>

<div class="container-fluid mt-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3>
                Medicine Management
            </h3>

            <p class="text-muted">
                Add and manage medicines available in the pharmacy.
            </p>

        </div>

        <a href="queue.php"
           class="btn btn-secondary">

            Back to Pharmacy Queue

        </a>

    </div>


    <!-- Add Medicine Form -->

    <div class="card shadow-sm mb-4">

        <div class="card-header bg-success text-white">

            <h5 class="mb-0">
                Add New Medicine
            </h5>

        </div>

        <div class="card-body">

            <form method="POST"
                  action="save_medicine.php">

                <div class="row">

                    <div class="col-md-3 mb-3">

                        <label class="form-label">
                            Medicine Code
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            name="medicine_code"
                            class="form-control"
                            required
                            placeholder="e.g. PCM500"
                        >

                    </div>


                    <div class="col-md-5 mb-3">

                        <label class="form-label">
                            Medicine Name
                            <span class="text-danger">*</span>
                        </label>

                        <input
                            type="text"
                            name="medicine_name"
                            class="form-control"
                            required
                            placeholder="e.g. Paracetamol"
                        >

                    </div>


                    <div class="col-md-4 mb-3">

                        <label class="form-label">
                            Generic Name
                        </label>

                        <input
                            type="text"
                            name="generic_name"
                            class="form-control"
                            placeholder="e.g. Paracetamol"
                        >

                    </div>

                </div>


                <div class="row">

                    <div class="col-md-3 mb-3">

                        <label class="form-label">
                            Category
                        </label>

                        <input
                            type="text"
                            name="category"
                            class="form-control"
                            placeholder="e.g. Analgesic"
                        >

                    </div>


                    <div class="col-md-3 mb-3">

                        <label class="form-label">
                            Dosage Form
                        </label>

                        <select
                            name="dosage_form"
                            class="form-select"
                        >

                            <option value="">
                                Select Form
                            </option>

                            <option value="Tablet">
                                Tablet
                            </option>

                            <option value="Capsule">
                                Capsule
                            </option>

                            <option value="Syrup">
                                Syrup
                            </option>

                            <option value="Injection">
                                Injection
                            </option>

                            <option value="Cream">
                                Cream
                            </option>

                            <option value="Ointment">
                                Ointment
                            </option>

                            <option value="Drops">
                                Drops
                            </option>

                            <option value="Suspension">
                                Suspension
                            </option>

                            <option value="Other">
                                Other
                            </option>

                        </select>

                    </div>


                    <div class="col-md-3 mb-3">

                        <label class="form-label">
                            Strength
                        </label>

                        <input
                            type="text"
                            name="strength"
                            class="form-control"
                            placeholder="e.g. 500mg"
                        >

                    </div>


                    <div class="col-md-3 mb-3">

                        <label class="form-label">
                            Unit
                        </label>

                        <input
                            type="text"
                            name="unit"
                            class="form-control"
                            placeholder="e.g. Tablet"
                        >

                    </div>

                </div>


                <div class="row">

                    <div class="col-md-4 mb-3">

                        <label class="form-label">
                            Selling Price (KSh)
                        </label>

                        <input
                            type="number"
                            name="selling_price"
                            class="form-control"
                            min="0"
                            step="0.01"
                            value="0"
                        >

                    </div>


                    <div class="col-md-4 mb-3">

                        <label class="form-label">
                            Initial Stock Quantity
                        </label>

                        <input
                            type="number"
                            name="stock_quantity"
                            class="form-control"
                            min="0"
                            value="0"
                        >

                    </div>


                    <div class="col-md-4 mb-3">

                        <label class="form-label">
                            Reorder Level
                        </label>

                        <input
                            type="number"
                            name="reorder_level"
                            class="form-control"
                            min="0"
                            value="0"
                        >

                    </div>

                </div>


                <button type="submit"
                        class="btn btn-success">

                    Save Medicine

                </button>

            </form>

        </div>

    </div>


    <!-- Medicine List -->

    <div class="card shadow-sm">

        <div class="card-header">

            <h5 class="mb-0">
                Medicine List
            </h5>

        </div>

        <div class="card-body">

            <?php if (empty($medicines)): ?>

                <div class="alert alert-info">
                    No medicines have been entered yet.
                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered table-hover">

                        <thead class="table-light">

                            <tr>

                                <th>#</th>
                                <th>Code</th>
                                <th>Medicine</th>
                                <th>Generic Name</th>
                                <th>Category</th>
                                <th>Form</th>
                                <th>Strength</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Status</th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($medicines as $index => $medicine): ?>

                            <tr>

                                <td>
                                    <?= $index + 1; ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $medicine['medicine_code']
                                    ); ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= htmlspecialchars(
                                            $medicine['medicine_name']
                                        ); ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $medicine['generic_name'] ?? ''
                                    ); ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $medicine['category'] ?? ''
                                    ); ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $medicine['dosage_form'] ?? ''
                                    ); ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $medicine['strength'] ?? ''
                                    ); ?>
                                </td>

                                <td>
                                    KSh
                                    <?= number_format(
                                        (float) $medicine['selling_price'],
                                        2
                                    ); ?>
                                </td>

                                <td>

                                    <?php if (
                                        (int) $medicine['stock_quantity']
                                        <=
                                        (int) $medicine['reorder_level']
                                    ): ?>

                                        <span class="badge bg-danger">

                                            <?= (int) $medicine['stock_quantity']; ?>

                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-success">

                                            <?= (int) $medicine['stock_quantity']; ?>

                                        </span>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    <?php if (
                                        $medicine['status'] === 'Active'
                                    ): ?>

                                        <span class="badge bg-success">
                                            Active
                                        </span>

                                    <?php else: ?>

                                        <span class="badge bg-secondary">
                                            Inactive
                                        </span>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

<?php

require_once __DIR__ . '/../includes/footer.php';

?>