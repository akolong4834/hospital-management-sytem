<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: queue.php");
    exit();
}

$prescription_id = isset($_POST['prescription_id'])
    ? (int) $_POST['prescription_id']
    : 0;

$quantities = isset($_POST['quantity'])
    ? $_POST['quantity']
    : [];

$dispensing_notes = isset($_POST['dispensing_notes'])
    ? trim($_POST['dispensing_notes'])
    : '';

if ($prescription_id <= 0) {
    die("Invalid prescription ID.");
}

try {

    /*
    |--------------------------------------------------------------------------
    | START TRANSACTION
    |--------------------------------------------------------------------------
    */

    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | GET PRESCRIPTION
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            prescription_id,
            visit_id,
            prescription_status
        FROM prescriptions
        WHERE prescription_id = ?
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->execute([$prescription_id]);

    $prescription = $stmt->fetch();

    if (!$prescription) {
        throw new Exception("Prescription not found.");
    }


    /*
    |--------------------------------------------------------------------------
    | CHECK PRESCRIPTION STATUS
    |--------------------------------------------------------------------------
    */

    if ($prescription['prescription_status'] === 'Completed') {

        throw new Exception(
            "This prescription has already been completed."
        );
    }

    if ($prescription['prescription_status'] === 'Cancelled') {

        throw new Exception(
            "This prescription has been cancelled."
        );
    }


    /*
    |--------------------------------------------------------------------------
    | GET PRESCRIPTION ITEMS AND LOCK STOCK ROWS
    |--------------------------------------------------------------------------
    */

    $itemStmt = $pdo->prepare("
        SELECT
            pi.prescription_item_id,
            pi.medicine_id,
            pi.quantity_prescribed,
            pi.quantity_dispensed,
            pi.item_status,

            m.medicine_name,
            m.stock_quantity

        FROM prescription_items pi

        INNER JOIN medicines m
            ON pi.medicine_id = m.medicine_id

        WHERE pi.prescription_id = ?

        FOR UPDATE
    ");

    $itemStmt->execute([$prescription_id]);

    $items = $itemStmt->fetchAll();

    if (empty($items)) {

        throw new Exception(
            "No medicines found for this prescription."
        );
    }


    /*
    |--------------------------------------------------------------------------
    | PROCESS EACH MEDICINE
    |--------------------------------------------------------------------------
    */

    $dispensedSomething = false;

    foreach ($items as $item) {

        $item_id = (int) $item['prescription_item_id'];

        $medicine_id = (int) $item['medicine_id'];

        $prescribed = (int) $item['quantity_prescribed'];

        $already_dispensed =
            (int) $item['quantity_dispensed'];

        $current_stock =
            (int) $item['stock_quantity'];


        /*
        | Skip items already completely dispensed
        */

        if ($item['item_status'] === 'Dispensed') {
            continue;
        }


        /*
        | Get quantity entered by pharmacist
        */

        $quantity = isset($quantities[$item_id])
            ? (int) $quantities[$item_id]
            : 0;


        /*
        | Skip zero quantity
        */

        if ($quantity <= 0) {
            continue;
        }


        /*
        |--------------------------------------------------------------------------
        | CALCULATE REMAINING PRESCRIPTION
        |--------------------------------------------------------------------------
        */

        $remaining =
            $prescribed - $already_dispensed;

        if ($remaining < 0) {
            $remaining = 0;
        }


        /*
        | Cannot dispense more than prescribed
        */

        if ($quantity > $remaining) {

            throw new Exception(
                "Cannot dispense "
                . $quantity
                . " units of "
                . $item['medicine_name']
                . ". Only "
                . $remaining
                . " remaining."
            );
        }


        /*
        |--------------------------------------------------------------------------
        | CHECK STOCK
        |--------------------------------------------------------------------------
        */

        if ($current_stock < $quantity) {

            throw new Exception(
                "Insufficient stock for "
                . $item['medicine_name']
                . ". Available stock: "
                . $current_stock
                . ". Requested: "
                . $quantity
                . "."
            );
        }


        /*
        |--------------------------------------------------------------------------
        | DEDUCT MEDICINE STOCK
        |--------------------------------------------------------------------------
        */

        $stockStmt = $pdo->prepare("
            UPDATE medicines
            SET stock_quantity = stock_quantity - ?
            WHERE medicine_id = ?
            AND stock_quantity >= ?
        ");

        $stockStmt->execute([
            $quantity,
            $medicine_id,
            $quantity
        ]);

        if ($stockStmt->rowCount() !== 1) {

            throw new Exception(
                "Unable to deduct stock for "
                . $item['medicine_name']
                . "."
            );
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE DISPENSED QUANTITY
        |--------------------------------------------------------------------------
        */

        $new_dispensed =
            $already_dispensed + $quantity;


        /*
        |--------------------------------------------------------------------------
        | DETERMINE ITEM STATUS
        |--------------------------------------------------------------------------
        */

        if ($new_dispensed >= $prescribed) {

            $item_status = 'Dispensed';

        } else {

            $item_status = 'Pending';
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE PRESCRIPTION ITEM
        |--------------------------------------------------------------------------
        */

        $updateItem = $pdo->prepare("
            UPDATE prescription_items

            SET
                quantity_dispensed = ?,
                item_status = ?

            WHERE prescription_item_id = ?
        ");

        $updateItem->execute([
            $new_dispensed,
            $item_status,
            $item_id
        ]);


        $dispensedSomething = true;
    }


    /*
    |--------------------------------------------------------------------------
    | ENSURE SOMETHING WAS DISPENSED
    |--------------------------------------------------------------------------
    */

    if (!$dispensedSomething) {

        throw new Exception(
            "No medicine quantity was entered for dispensing."
        );
    }


    /*
    |--------------------------------------------------------------------------
    | CHECK WHETHER ALL MEDICINES ARE FULLY DISPENSED
    |--------------------------------------------------------------------------
    */

    $checkStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM prescription_items
        WHERE prescription_id = ?
        AND item_status != 'Dispensed'
    ");

    $checkStmt->execute([$prescription_id]);

    $remainingItems =
        (int) $checkStmt->fetchColumn();


    /*
    |--------------------------------------------------------------------------
    | UPDATE PRESCRIPTION STATUS
    |--------------------------------------------------------------------------
    */

    if ($remainingItems === 0) {

        $prescription_status = 'Completed';

    } else {

        $prescription_status = 'Dispensing';
    }


    /*
    |--------------------------------------------------------------------------
    | UPDATE PRESCRIPTION
    |--------------------------------------------------------------------------
    */

    if ($dispensing_notes !== '') {

        $updatePrescription = $pdo->prepare("
            UPDATE prescriptions

            SET
                prescription_status = ?,
                prescription_notes = ?

            WHERE prescription_id = ?
        ");

        $updatePrescription->execute([
            $prescription_status,
            $dispensing_notes,
            $prescription_id
        ]);

    } else {

        $updatePrescription = $pdo->prepare("
            UPDATE prescriptions

            SET prescription_status = ?

            WHERE prescription_id = ?
        ");

        $updatePrescription->execute([
            $prescription_status,
            $prescription_id
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | MOVE VISIT TO BILLING WHEN COMPLETED
    |--------------------------------------------------------------------------
    */

    if ($remainingItems === 0) {

        $updateVisit = $pdo->prepare("
            UPDATE patient_visits

            SET status = 'Billing'

            WHERE visit_id = ?
        ");

        $updateVisit->execute([
            $prescription['visit_id']
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | COMMIT TRANSACTION
    |--------------------------------------------------------------------------
    */

    $pdo->commit();


    /*
    |--------------------------------------------------------------------------
    | RETURN TO PRESCRIPTION VIEW
    |--------------------------------------------------------------------------
    */

    header(
        "Location: prescription_view.php?prescription_id="
        . $prescription_id
    );

    exit();


} catch (Exception $e) {

    /*
    |--------------------------------------------------------------------------
    | ROLLBACK IF ERROR
    |--------------------------------------------------------------------------
    */

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    ?>

    <!DOCTYPE html>

    <html>

    <head>

        <title>Dispensing Error</title>

        <meta charset="UTF-8">

        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
            rel="stylesheet"
        >

    </head>

    <body class="bg-light">

    <div class="container mt-5">

        <div class="card shadow">

            <div class="card-header bg-danger text-white">

                <h4 class="mb-0">
                    Medicine Dispensing Failed
                </h4>

            </div>

            <div class="card-body">

                <div class="alert alert-danger">

                    <?= htmlspecialchars(
                        $e->getMessage()
                    ) ?>

                </div>

                <a
                    href="prescription_view.php?prescription_id=<?= $prescription_id ?>"
                    class="btn btn-primary"
                >
                    ← Return to Prescription
                </a>

            </div>

        </div>

    </div>

    </body>

    </html>

    <?php

}
?>