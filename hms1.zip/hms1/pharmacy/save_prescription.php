<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: queue.php");
    exit();
}

$visit_id = isset($_POST['visit_id']) ? (int) $_POST['visit_id'] : 0;

if ($visit_id <= 0) {
    die("Invalid visit.");
}

$medicines = isset($_POST['medicine_id']) ? $_POST['medicine_id'] : [];
$quantities = isset($_POST['quantity']) ? $_POST['quantity'] : [];
$dosages = isset($_POST['dosage']) ? $_POST['dosage'] : [];
$frequencies = isset($_POST['frequency']) ? $_POST['frequency'] : [];
$durations = isset($_POST['duration']) ? $_POST['duration'] : [];
$routes = isset($_POST['route']) ? $_POST['route'] : [];
$instructions = isset($_POST['instructions']) ? $_POST['instructions'] : [];

$prescription_notes = isset($_POST['prescription_notes'])
    ? trim($_POST['prescription_notes'])
    : '';

if (empty($medicines)) {
    die("Please add at least one medicine.");
}

try {

    $pdo->beginTransaction();

    /* ---------------------------------------------------------
       1. Verify that the visit exists
    --------------------------------------------------------- */

    $stmt = $pdo->prepare("
        SELECT visit_id, patient_id, status
        FROM patient_visits
        WHERE visit_id = ?
        LIMIT 1
    ");

    $stmt->execute([$visit_id]);

    $visit = $stmt->fetch();

    if (!$visit) {
        throw new Exception("Patient visit not found.");
    }

    /* ---------------------------------------------------------
       2. Create prescription
    --------------------------------------------------------- */

    $prescribed_by = isset($_SESSION['user_id'])
        ? (int) $_SESSION['user_id']
        : null;

    $stmt = $pdo->prepare("
        INSERT INTO prescriptions
        (
            visit_id,
            prescribed_by,
            prescription_status,
            prescription_notes
        )
        VALUES
        (
            ?,
            ?,
            'Pending',
            ?
        )
    ");

    $stmt->execute([
        $visit_id,
        $prescribed_by,
        $prescription_notes
    ]);

    $prescription_id = $pdo->lastInsertId();

    /* ---------------------------------------------------------
       3. Insert prescription items
    --------------------------------------------------------- */

    $itemStmt = $pdo->prepare("
        INSERT INTO prescription_items
        (
            prescription_id,
            medicine_id,
            quantity_prescribed,
            dosage,
            frequency,
            duration,
            route,
            instructions,
            quantity_dispensed,
            item_status
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            0,
            'Pending'
        )
    ");

    /* ---------------------------------------------------------
       4. Validate medicines and stock
    --------------------------------------------------------- */

    foreach ($medicines as $index => $medicine_id) {

        $medicine_id = (int) $medicine_id;

        if ($medicine_id <= 0) {
            continue;
        }

        $quantity = isset($quantities[$index])
            ? (int) $quantities[$index]
            : 0;

        if ($quantity <= 0) {
            throw new Exception(
                "Invalid quantity for medicine at row " . ($index + 1)
            );
        }

        $dosage = isset($dosages[$index])
            ? trim($dosages[$index])
            : '';

        $frequency = isset($frequencies[$index])
            ? trim($frequencies[$index])
            : '';

        $duration = isset($durations[$index])
            ? trim($durations[$index])
            : '';

        $route = isset($routes[$index])
            ? trim($routes[$index])
            : '';

        $instruction = isset($instructions[$index])
            ? trim($instructions[$index])
            : '';

        /* Check medicine */

        $medicineStmt = $pdo->prepare("
            SELECT
                medicine_id,
                medicine_name,
                selling_price,
                stock_quantity,
                status
            FROM medicines
            WHERE medicine_id = ?
            LIMIT 1
        ");

        $medicineStmt->execute([$medicine_id]);

        $medicine = $medicineStmt->fetch();

        if (!$medicine) {
            throw new Exception(
                "Selected medicine could not be found."
            );
        }

        /* Check active status */

        if ($medicine['status'] !== 'Active') {
            throw new Exception(
                "Medicine '{$medicine['medicine_name']}' is inactive."
            );
        }

        /* Check available stock */

        if ((int)$medicine['stock_quantity'] < $quantity) {

            throw new Exception(
                "Insufficient stock for '{$medicine['medicine_name']}'. "
                . "Available stock: "
                . $medicine['stock_quantity']
                . ", requested: "
                . $quantity
            );
        }

        /* Insert prescription item */

        $itemStmt->execute([
            $prescription_id,
            $medicine_id,
            $quantity,
            $dosage,
            $frequency,
            $duration,
            $route,
            $instruction
        ]);
    }

    /* ---------------------------------------------------------
       5. Make sure at least one item was inserted
    --------------------------------------------------------- */

    $checkStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM prescription_items
        WHERE prescription_id = ?
    ");

    $checkStmt->execute([$prescription_id]);

    $itemCount = (int) $checkStmt->fetchColumn();

    if ($itemCount === 0) {
        throw new Exception("No valid medicines were added.");
    }

    /* ---------------------------------------------------------
       6. Update visit status
    --------------------------------------------------------- */

    $updateVisit = $pdo->prepare("
        UPDATE patient_visits
        SET status = 'Pharmacy'
        WHERE visit_id = ?
    ");

    $updateVisit->execute([$visit_id]);

    /* ---------------------------------------------------------
       7. Commit
    --------------------------------------------------------- */

    $pdo->commit();

    header(
        "Location: prescription_view.php?prescription_id="
        . $prescription_id
    );

    exit();

} catch (Exception $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    die(
        "Prescription could not be saved: "
        . htmlspecialchars($e->getMessage())
    );
}
?>