<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

/*
|--------------------------------------------------------------------------
| Get patients currently waiting for Pharmacy
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.department,
        v.status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.phone,

        c.consultation_id,
        c.diagnosis,
        c.treatment_plan,
        c.laboratory_required,
        c.consultation_status

    FROM patient_visits v

    INNER JOIN patients p
        ON v.patient_id = p.patient_id

    LEFT JOIN consultations c
        ON v.visit_id = c.visit_id

    WHERE v.status = 'Pharmacy'

    ORDER BY v.updated_at ASC
";

$stmt = $pdo->query($sql);

$patients = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>Pharmacy Queue - HMS</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

</head>

<body>

<div class="container-fluid mt-4">

    <!-- Header -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3>
                Pharmacy Queue
            </h3>

            <p class="text-muted mb-0">
                Patients ready for pharmacy services
            </p>

        </div>

        <div>

            <a
                href="../index.php"
                class="btn btn-secondary"
            >
                Dashboard
            </a>

        </div>

    </div>


    <!-- Queue count -->

    <div class="alert alert-info">

        <strong>
            <?php echo count($patients); ?>
        </strong>

        patient(s) currently waiting for Pharmacy.

    </div>


    <!-- Pharmacy Queue -->

    <div class="card shadow-sm">

        <div class="card-header bg-primary text-white">

            <strong>
                Pharmacy Patients
            </strong>

        </div>

        <div class="card-body">

            <?php if (empty($patients)): ?>

                <div class="alert alert-success">

                    No patients are currently waiting for pharmacy.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-light">

                            <tr>

                                <th>#</th>

                                <th>Patient No.</th>

                                <th>Patient Name</th>

                                <th>Gender</th>

                                <th>Phone</th>

                                <th>Visit No.</th>

                                <th>Visit Date</th>

                                <th>Diagnosis</th>

                                <th>Lab</th>

                                <th>Status</th>

                                <th>Action</th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($patients as $index => $patient): ?>

                            <tr>

                                <td>
                                    <?php echo $index + 1; ?>
                                </td>


                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $patient['patient_number']
                                    );
                                    ?>
                                </td>


                                <td>

                                    <strong>

                                        <?php
                                        echo htmlspecialchars(
                                            trim(
                                                $patient['first_name'] . ' ' .
                                                $patient['middle_name'] . ' ' .
                                                $patient['last_name']
                                            )
                                        );
                                        ?>

                                    </strong>

                                </td>


                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $patient['gender']
                                    );
                                    ?>
                                </td>


                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $patient['phone']
                                    );
                                    ?>
                                </td>


                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $patient['visit_number']
                                    );
                                    ?>
                                </td>


                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $patient['visit_date']
                                    );
                                    ?>
                                </td>


                                <td>

                                    <?php

                                    if (!empty($patient['diagnosis'])) {

                                        echo nl2br(
                                            htmlspecialchars(
                                                $patient['diagnosis']
                                            )
                                        );

                                    } else {

                                        echo '<span class="text-muted">
                                                Not recorded
                                              </span>';

                                    }

                                    ?>

                                </td>


                                <td>

                                    <?php

                                    if ($patient['laboratory_required'] === 'Yes') {

                                        echo '<span class="badge bg-success">
                                                Completed
                                              </span>';

                                    } else {

                                        echo '<span class="badge bg-secondary">
                                                Not Required
                                              </span>';

                                    }

                                    ?>

                                </td>


                                <td>

                                    <span class="badge bg-warning text-dark">

                                        <?php
                                        echo htmlspecialchars(
                                            $patient['status']
                                        );
                                        ?>

                                    </span>

                                </td>


                                <td>

                                    <a
                                        href="prescription.php?visit_id=<?php echo (int)$patient['visit_id']; ?>"
                                        class="btn btn-sm btn-primary"
                                    >

                                        Open Pharmacy

                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>

</body>

</html>