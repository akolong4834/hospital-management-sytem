<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$prescription_id = isset($_GET['prescription_id'])
    ? (int) $_GET['prescription_id']
    : 0;

if ($prescription_id <= 0) {
    die("Invalid prescription ID.");
}

try {

    /*
    |--------------------------------------------------------------------------
    | GET PRESCRIPTION
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            pr.prescription_id,
            pr.visit_id,
            pr.prescribed_by,
            pr.prescription_status,
            pr.prescription_notes,
            pr.prescribed_at,

            v.visit_number,
            v.visit_date,
            v.status AS visit_status,

            p.patient_id,
            p.patient_number,
            p.first_name,
            p.middle_name,
            p.last_name,
            p.gender,
            p.phone,

            c.diagnosis

        FROM prescriptions pr

        INNER JOIN patient_visits v
            ON pr.visit_id = v.visit_id

        INNER JOIN patients p
            ON v.patient_id = p.patient_id

        LEFT JOIN consultations c
            ON v.visit_id = c.visit_id

        WHERE pr.prescription_id = ?

        ORDER BY c.consultation_id DESC

        LIMIT 1
    ");

    $stmt->execute([$prescription_id]);

    $prescription = $stmt->fetch();

    if (!$prescription) {
        die("Prescription not found.");
    }


    /*
    |--------------------------------------------------------------------------
    | GET PRESCRIPTION ITEMS
    |--------------------------------------------------------------------------
    */

    $itemStmt = $pdo->prepare("
        SELECT
            pi.prescription_item_id,
            pi.medicine_id,
            pi.quantity_prescribed,
            pi.dosage,
            pi.frequency,
            pi.duration,
            pi.route,
            pi.instructions,
            pi.quantity_dispensed,
            pi.item_status,

            m.medicine_code,
            m.medicine_name,
            m.generic_name,
            m.dosage_form,
            m.strength,
            m.unit,
            m.selling_price,
            m.stock_quantity

        FROM prescription_items pi

        INNER JOIN medicines m
            ON pi.medicine_id = m.medicine_id

        WHERE pi.prescription_id = ?

        ORDER BY pi.prescription_item_id ASC
    ");

    $itemStmt->execute([$prescription_id]);

    $items = $itemStmt->fetchAll();


} catch (PDOException $e) {

    die(
        "Database error: "
        . htmlspecialchars($e->getMessage())
    );
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Dispense Medicines
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f4f6f9;
        }

        .container-main {
            max-width: 1400px;
            margin: auto;
        }

        .header {
            background: #198754;
            color: white;
            padding: 20px;
            border-radius: 10px;
        }

        .card {
            border: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .medicine-table th {
            background: #198754;
            color: white;
            vertical-align: middle;
        }

        .medicine-table td {
            vertical-align: middle;
        }

        .stock-good {
            color: #198754;
            font-weight: bold;
        }

        .stock-low {
            color: #dc3545;
            font-weight: bold;
        }

        .patient-name {
            font-size: 20px;
            font-weight: 600;
        }

    </style>

</head>

<body>

<div class="container-fluid py-4 container-main">


    <!-- =====================================================
         HEADER
    ====================================================== -->

    <div class="header mb-4">

        <div class="row align-items-center">

            <div class="col-md-8">

                <h3 class="mb-1">
                    💊 Pharmacy Dispensing
                </h3>

                <div>
                    Prescription No:
                    <strong>
                        #<?= htmlspecialchars($prescription_id) ?>
                    </strong>
                </div>

            </div>

            <div class="col-md-4 text-md-end">

                <a
                    href="prescription_view.php?prescription_id=<?= $prescription_id ?>"
                    class="btn btn-light"
                >
                    ← Prescription
                </a>

                <a
                    href="queue.php"
                    class="btn btn-dark"
                >
                    Pharmacy Queue
                </a>

            </div>

        </div>

    </div>


    <!-- =====================================================
         PATIENT INFORMATION
    ====================================================== -->

    <div class="card mb-4">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Patient Information
            </h5>

        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-3">

                    <small class="text-muted">
                        Patient Number
                    </small>

                    <div>
                        <strong>
                            <?= htmlspecialchars(
                                $prescription['patient_number']
                            ) ?>
                        </strong>
                    </div>

                </div>


                <div class="col-md-4">

                    <small class="text-muted">
                        Patient Name
                    </small>

                    <div class="patient-name">

                        <?= htmlspecialchars(
                            $prescription['first_name']
                        ) ?>

                        <?php if (
                            !empty($prescription['middle_name'])
                        ): ?>

                            <?= htmlspecialchars(
                                $prescription['middle_name']
                            ) ?>

                        <?php endif; ?>

                        <?= htmlspecialchars(
                            $prescription['last_name']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-2">

                    <small class="text-muted">
                        Gender
                    </small>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['gender'] ?? ''
                        ) ?>
                    </div>

                </div>


                <div class="col-md-3">

                    <small class="text-muted">
                        Phone
                    </small>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['phone'] ?? ''
                        ) ?>
                    </div>

                </div>

            </div>

            <hr>

            <div class="row">

                <div class="col-md-4">

                    <strong>Visit Number:</strong>

                    <?= htmlspecialchars(
                        $prescription['visit_number']
                    ) ?>

                </div>

                <div class="col-md-4">

                    <strong>Diagnosis:</strong>

                    <?= htmlspecialchars(
                        $prescription['diagnosis']
                        ?? 'Not specified'
                    ) ?>

                </div>

                <div class="col-md-4">

                    <strong>Prescription Status:</strong>

                    <span class="badge bg-primary">

                        <?= htmlspecialchars(
                            $prescription['prescription_status']
                        ) ?>

                    </span>

                </div>

            </div>

        </div>

    </div>


    <!-- =====================================================
         DISPENSING FORM
    ====================================================== -->

    <form
        method="POST"
        action="save_dispensing.php"
    >

        <input
            type="hidden"
            name="prescription_id"
            value="<?= $prescription_id ?>"
        >


        <div class="card mb-4">

            <div class="card-header bg-white">

                <h5 class="mb-0">
                    Medicines to Dispense
                </h5>

            </div>


            <div class="card-body p-0">

                <?php if (empty($items)): ?>

                    <div class="alert alert-warning m-3">

                        No medicines are attached to this prescription.

                    </div>

                <?php else: ?>

                    <div class="table-responsive">

                        <table class="table table-bordered medicine-table mb-0">

                            <thead>

                            <tr>

                                <th>#</th>

                                <th>Medicine</th>

                                <th>Strength</th>

                                <th>Prescribed</th>

                                <th>Already Dispensed</th>

                                <th>Available Stock</th>

                                <th>Quantity to Dispense</th>

                                <th>Dosage</th>

                                <th>Frequency</th>

                                <th>Duration</th>

                                <th>Status</th>

                            </tr>

                            </thead>

                            <tbody>

                            <?php foreach (
                                $items as $index => $item
                            ): ?>

                                <?php

                                $prescribed =
                                    (int) $item[
                                        'quantity_prescribed'
                                    ];

                                $dispensed =
                                    (int) $item[
                                        'quantity_dispensed'
                                    ];

                                $stock =
                                    (int) $item[
                                        'stock_quantity'
                                    ];

                                $remaining =
                                    $prescribed - $dispensed;

                                if ($remaining < 0) {
                                    $remaining = 0;
                                }

                                ?>

                                <tr>

                                    <td>
                                        <?= $index + 1 ?>
                                    </td>


                                    <td>

                                        <strong>

                                            <?= htmlspecialchars(
                                                $item['medicine_name']
                                            ) ?>

                                        </strong>

                                        <br>

                                        <small class="text-muted">

                                            <?= htmlspecialchars(
                                                $item['medicine_code']
                                            ) ?>

                                        </small>

                                        <?php if (
                                            !empty(
                                                $item['generic_name']
                                            )
                                        ): ?>

                                            <br>

                                            <small class="text-muted">

                                                Generic:
                                                <?= htmlspecialchars(
                                                    $item[
                                                        'generic_name'
                                                    ]
                                                ) ?>

                                            </small>

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $item['strength'] ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <strong>
                                            <?= $prescribed ?>
                                        </strong>

                                        <?php if (
                                            !empty(
                                                $item['unit']
                                            )
                                        ): ?>

                                            <?= htmlspecialchars(
                                                $item['unit']
                                            ) ?>

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <?= $dispensed ?>

                                    </td>


                                    <td>

                                        <?php if ($stock > 0): ?>

                                            <span class="stock-good">

                                                <?= $stock ?>

                                            </span>

                                        <?php else: ?>

                                            <span class="stock-low">

                                                OUT OF STOCK

                                            </span>

                                        <?php endif; ?>

                                    </td>


                                    <td style="min-width:150px;">

                                        <?php if (
                                            $item['item_status']
                                            === 'Dispensed'
                                        ): ?>

                                            <input
                                                type="number"
                                                class="form-control"
                                                value="<?= $dispensed ?>"
                                                readonly
                                            >

                                            <input
                                                type="hidden"
                                                name="quantity[<?= $item['prescription_item_id'] ?>]"
                                                value="0"
                                            >

                                        <?php elseif (
                                            $stock <= 0
                                        ): ?>

                                            <input
                                                type="number"
                                                class="form-control"
                                                value="0"
                                                readonly
                                            >

                                            <input
                                                type="hidden"
                                                name="quantity[<?= $item['prescription_item_id'] ?>]"
                                                value="0"
                                            >

                                        <?php else: ?>

                                            <input
                                                type="number"
                                                name="quantity[<?= $item['prescription_item_id'] ?>]"
                                                class="form-control"
                                                min="0"
                                                max="<?= min(
                                                    $remaining,
                                                    $stock
                                                ) ?>"
                                                value="<?= min(
                                                    $remaining,
                                                    $stock
                                                ) ?>"
                                            >

                                            <small class="text-muted">

                                                Max:
                                                <?= min(
                                                    $remaining,
                                                    $stock
                                                ) ?>

                                            </small>

                                        <?php endif; ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $item['dosage'] ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $item['frequency'] ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $item['duration'] ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <?php

                                        if (
                                            $item['item_status']
                                            === 'Dispensed'
                                        ) {

                                            $badge =
                                                'bg-success';

                                        } elseif (
                                            $stock <= 0
                                        ) {

                                            $badge =
                                                'bg-danger';

                                        } else {

                                            $badge =
                                                'bg-warning text-dark';
                                        }

                                        ?>

                                        <span
                                            class="badge <?= $badge ?>"
                                        >

                                            <?= htmlspecialchars(
                                                $item[
                                                    'item_status'
                                                ]
                                            ) ?>

                                        </span>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                            </tbody>

                        </table>

                    </div>

                <?php endif; ?>

            </div>

        </div>


        <!-- =================================================
             DISPENSING NOTES
        ================================================== -->

        <div class="card mb-4">

            <div class="card-header bg-white">

                <h5 class="mb-0">
                    Dispensing Notes
                </h5>

            </div>

            <div class="card-body">

                <textarea
                    name="dispensing_notes"
                    class="form-control"
                    rows="4"
                    placeholder="Enter any dispensing notes..."
                ></textarea>

            </div>

        </div>


        <!-- =================================================
             ACTIONS
        ================================================== -->

        <div class="card mb-4">

            <div class="card-body">

                <div class="d-flex gap-2">

                    <a
                        href="prescription_view.php?prescription_id=<?= $prescription_id ?>"
                        class="btn btn-secondary"
                    >
                        Cancel
                    </a>

                    <?php if (
                        $prescription['prescription_status']
                        !== 'Completed'
                        &&
                        $prescription['prescription_status']
                        !== 'Cancelled'
                    ): ?>

                        <button
                            type="submit"
                            class="btn btn-success"
                            onclick="return confirm(
                                'Are you sure you want to dispense these medicines? Stock will be deducted.'
                            );"
                        >
                            💊 Confirm Dispensing
                        </button>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </form>

</div>

</body>

</html>