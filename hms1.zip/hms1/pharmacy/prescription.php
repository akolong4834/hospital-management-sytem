<?php
require_once "../includes/db.php";
require_once "../includes/auth.php";

check_authentication();

if (!isset($_GET['visit_id']) || !is_numeric($_GET['visit_id'])) {
    die("Invalid visit ID.");
}

$visit_id = (int) $_GET['visit_id'];

/*
|--------------------------------------------------------------------------
| Get Visit, Patient and Consultation Details
|--------------------------------------------------------------------------
*/
$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.department,
        v.status,
        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,
        c.consultation_id,
        c.diagnosis,
        c.treatment_plan,
        c.investigations_requested
    FROM patient_visits v
    INNER JOIN patients p
        ON p.patient_id = v.patient_id
    LEFT JOIN consultations c
        ON c.visit_id = v.visit_id
    WHERE v.visit_id = ?
    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$visit_id]);
$visit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$visit) {
    die("Visit not found.");
}

/*
|--------------------------------------------------------------------------
| Check Existing Prescription
|--------------------------------------------------------------------------
*/
$existingPrescription = null;

$stmt = $pdo->prepare("
    SELECT
        prescription_id,
        prescription_status,
        prescribed_at,
        completed_at
    FROM prescriptions
    WHERE visit_id = ?
    ORDER BY prescription_id DESC
    LIMIT 1
");

$stmt->execute([$visit_id]);
$existingPrescription = $stmt->fetch(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Get Active Medicines
|--------------------------------------------------------------------------
*/
$stmt = $pdo->query("
    SELECT
        medicine_id,
        medicine_code,
        medicine_name,
        generic_name,
        dosage_form,
        strength,
        unit,
        selling_price,
        stock_quantity
    FROM medicines
    WHERE status = 'Active'
    ORDER BY medicine_name ASC
");

$medicines = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Create Prescription - HMS</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: auto;
        }

        .card {
            background: #fff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
            color: #1f2937;
        }

        h2 {
            color: #374151;
            font-size: 20px;
        }

        .patient-info {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }

        .info-box {
            background: #f8fafc;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
        }

        .info-box strong {
            display: block;
            color: #374151;
            margin-bottom: 5px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            vertical-align: top;
        }

        th {
            background: #1f4e78;
            color: white;
            text-align: left;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 9px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #198754;
            color: white;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-info {
            background: #0d6efd;
            color: white;
        }

        .actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }

        .medicine-price {
            font-size: 12px;
            color: #198754;
            margin-top: 4px;
        }

        .stock-info {
            font-size: 12px;
            color: #555;
            margin-top: 4px;
        }

        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
        }

        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .remove-btn {
            white-space: nowrap;
        }

        @media (max-width: 900px) {
            .patient-info {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .patient-info {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<div class="container">

    <div class="card">
        <h1>Create Prescription</h1>

        <?php if ($existingPrescription): ?>

            <div class="alert alert-warning">
                <strong>Existing Prescription Found</strong><br>

                Prescription ID:
                <strong>
                    #<?= htmlspecialchars($existingPrescription['prescription_id']) ?>
                </strong>
                <br>

                Status:
                <strong>
                    <?= htmlspecialchars($existingPrescription['prescription_status']) ?>
                </strong>
                <br>

                Date:
                <?= htmlspecialchars($existingPrescription['prescribed_at']) ?>
            </div>

        <?php endif; ?>

        <div class="patient-info">

            <div class="info-box">
                <strong>Patient Number</strong>
                <?= htmlspecialchars($visit['patient_number']) ?>
            </div>

            <div class="info-box">
                <strong>Patient Name</strong>
                <?= htmlspecialchars(
                    trim(
                        $visit['first_name'] . ' ' .
                        $visit['middle_name'] . ' ' .
                        $visit['last_name']
                    )
                ) ?>
            </div>

            <div class="info-box">
                <strong>Gender</strong>
                <?= htmlspecialchars($visit['gender'] ?? '') ?>
            </div>

            <div class="info-box">
                <strong>Phone</strong>
                <?= htmlspecialchars($visit['phone'] ?? '') ?>
            </div>

            <div class="info-box">
                <strong>Visit Number</strong>
                <?= htmlspecialchars($visit['visit_number'] ?? '') ?>
            </div>

            <div class="info-box">
                <strong>Visit Date</strong>
                <?= htmlspecialchars($visit['visit_date'] ?? '') ?>
            </div>

            <div class="info-box">
                <strong>Department</strong>
                <?= htmlspecialchars($visit['department'] ?? '') ?>
            </div>

            <div class="info-box">
                <strong>Visit Status</strong>
                <?= htmlspecialchars($visit['status'] ?? '') ?>
            </div>

        </div>
    </div>


    <div class="card">

        <h2>Clinical Information</h2>

        <div class="info-box">
            <strong>Diagnosis</strong>
            <?= nl2br(htmlspecialchars($visit['diagnosis'] ?? 'Not recorded')) ?>
        </div>

        <br>

        <div class="info-box">
            <strong>Treatment Plan</strong>
            <?= nl2br(htmlspecialchars($visit['treatment_plan'] ?? 'Not recorded')) ?>
        </div>

        <br>

        <div class="info-box">
            <strong>Investigations Requested</strong>
            <?= nl2br(htmlspecialchars($visit['investigations_requested'] ?? 'None')) ?>
        </div>

    </div>


    <form method="POST" action="save_prescription.php">

        <input type="hidden" name="visit_id" value="<?= $visit_id ?>">

        <div class="card">

            <h2>Prescription Medicines</h2>

            <div class="table-container">

                <table id="prescriptionTable">

                    <thead>
                        <tr>
                            <th style="width: 25%;">Medicine</th>
                            <th>Dosage</th>
                            <th>Frequency</th>
                            <th>Route</th>
                            <th>Duration</th>
                            <th>Quantity</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody id="medicineRows">

                        <tr class="medicine-row">

                            <td>

                                <select name="medicine_id[]" class="medicine-select" required>

                                    <option value="">-- Select Medicine --</option>

                                    <?php foreach ($medicines as $medicine): ?>

                                        <option
                                            value="<?= $medicine['medicine_id'] ?>"
                                            data-price="<?= htmlspecialchars($medicine['selling_price']) ?>"
                                            data-stock="<?= htmlspecialchars($medicine['stock_quantity']) ?>"
                                        >
                                            <?= htmlspecialchars($medicine['medicine_name']) ?>

                                            <?php if (!empty($medicine['strength'])): ?>
                                                - <?= htmlspecialchars($medicine['strength']) ?>
                                            <?php endif; ?>

                                            (Stock:
                                            <?= htmlspecialchars($medicine['stock_quantity']) ?>)
                                        </option>

                                    <?php endforeach; ?>

                                </select>

                                <div class="medicine-price"></div>
                                <div class="stock-info"></div>

                            </td>

                            <td>
                                <input
                                    type="text"
                                    name="dosage[]"
                                    placeholder="e.g. 500mg"
                                    required
                                >
                            </td>

                            <td>
                                <input
                                    type="text"
                                    name="frequency[]"
                                    placeholder="e.g. 2 times daily"
                                    required
                                >
                            </td>

                            <td>

                                <select name="route[]" required>

                                    <option value="">Select Route</option>
                                    <option value="Oral">Oral</option>
                                    <option value="IV">IV</option>
                                    <option value="IM">IM</option>
                                    <option value="SC">SC</option>
                                    <option value="Topical">Topical</option>
                                    <option value="Ophthalmic">Ophthalmic</option>
                                    <option value="Otic">Otic</option>
                                    <option value="Rectal">Rectal</option>
                                    <option value="Other">Other</option>

                                </select>

                            </td>

                            <td>
                                <input
                                    type="text"
                                    name="duration[]"
                                    placeholder="e.g. 5 days"
                                    required
                                >
                            </td>

                            <td>
                                <input
                                    type="number"
                                    name="quantity[]"
                                    min="1"
                                    value="1"
                                    required
                                >
                            </td>

                            <td>
                                <button
                                    type="button"
                                    class="btn btn-danger remove-btn"
                                    onclick="removeRow(this)"
                                >
                                    Remove
                                </button>
                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

            <br>

            <button
                type="button"
                class="btn btn-info"
                onclick="addMedicineRow()"
            >
                + Add Medicine
            </button>

        </div>


        <div class="card">

            <h2>Prescription Notes</h2>

            <textarea
                name="prescription_notes"
                rows="5"
                placeholder="Enter additional prescription instructions or notes..."
            ></textarea>

        </div>


        <div class="actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Save Prescription
            </button>

            <a
                href="queue.php"
                class="btn btn-secondary"
            >
                Back to Pharmacy Queue
            </a>

        </div>

    </form>

</div>


<script>

function updateMedicineInfo(select) {

    const row = select.closest('.medicine-row');

    const option = select.options[select.selectedIndex];

    const priceElement = row.querySelector('.medicine-price');
    const stockElement = row.querySelector('.stock-info');

    if (!option || !option.value) {

        priceElement.innerHTML = '';
        stockElement.innerHTML = '';

        return;
    }

    const price = option.getAttribute('data-price');
    const stock = option.getAttribute('data-stock');

    priceElement.innerHTML =
        'Price: KSh ' + parseFloat(price).toFixed(2);

    stockElement.innerHTML =
        'Available Stock: ' + stock;
}


function attachMedicineEvents(row) {

    const select = row.querySelector('.medicine-select');

    select.addEventListener('change', function () {

        updateMedicineInfo(this);

    });

}


function addMedicineRow() {

    const tbody = document.getElementById('medicineRows');

    const firstRow = tbody.querySelector('.medicine-row');

    const newRow = firstRow.cloneNode(true);

    newRow.querySelectorAll('input').forEach(function(input) {

        if (input.type === 'number') {

            input.value = 1;

        } else {

            input.value = '';

        }

    });

    newRow.querySelectorAll('select').forEach(function(select) {

        select.selectedIndex = 0;

    });

    newRow.querySelector('.medicine-price').innerHTML = '';
    newRow.querySelector('.stock-info').innerHTML = '';

    tbody.appendChild(newRow);

    attachMedicineEvents(newRow);
}


function removeRow(button) {

    const tbody = document.getElementById('medicineRows');

    const rows = tbody.querySelectorAll('.medicine-row');

    if (rows.length <= 1) {

        alert('At least one medicine is required.');

        return;
    }

    button.closest('.medicine-row').remove();
}


document.querySelectorAll('.medicine-row').forEach(function(row) {

    attachMedicineEvents(row);

});

</script>

</body>
</html>