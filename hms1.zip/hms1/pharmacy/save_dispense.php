<?php
require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/auth.php';require_login();
$rxid=(int)($_POST['prescription_id']??0);$items=$_POST['item_id']??[];$qtys=$_POST['quantity']??[];
$pdo->beginTransaction();
try{
 $get=$pdo->prepare("SELECT quantity_prescribed,quantity_dispensed FROM prescription_items WHERE id=? AND prescription_id=? FOR UPDATE");
 $up=$pdo->prepare("UPDATE prescription_items SET quantity_dispensed=quantity_dispensed+? WHERE id=?");
 $disp=$pdo->prepare("INSERT INTO dispensing(prescription_item_id,quantity,dispensed_by,notes) VALUES(?,?,?,?)");
 foreach($items as $i=>$item){$qty=max(0,(int)($qtys[$i]??0));if(!$qty)continue;$get->execute([(int)$item,$rxid]);$x=$get->fetch();if(!$x)continue;$remain=(int)$x['quantity_prescribed']-(int)$x['quantity_dispensed'];if($qty>$remain)throw new Exception('Dispensing quantity exceeds prescription.');$up->execute([$qty,(int)$item]);$disp->execute([(int)$item,$qty,$_SESSION['user_id'],'Dispensed through HMS']);}
 $check=$pdo->prepare("SELECT SUM(quantity_prescribed)=SUM(quantity_dispensed) FROM prescription_items WHERE prescription_id=?");$check->execute([$rxid]);$complete=(bool)$check->fetchColumn();
 $pdo->prepare("UPDATE prescriptions SET status=? WHERE id=?")->execute([$complete?'Dispensed':'Partially Dispensed',$rxid]);
 $v=$pdo->prepare("SELECT visit_id FROM prescriptions WHERE id=?");$v->execute([$rxid]);$vid=(int)$v->fetchColumn();
 $pdo->prepare("UPDATE patient_visits SET status='Billing' WHERE id=?")->execute([$vid]);
 $pdo->commit();header('Location: ../billing/create_invoice.php?visit_id='.$vid);exit;
}catch(Throwable $e){$pdo->rollBack();http_response_code(400);exit('Could not dispense: '.$e->getMessage());}