<?php

session_start();

require_once "../includes/db.php";
require_once "../includes/auth.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$prescription_id = isset($_GET['prescription_id'])
    ? (int) $_GET['prescription_id']
    : 0;

if ($prescription_id <= 0) {
    die("Invalid prescription.");
}

try {

    /* ---------------------------------------------------------
       GET PRESCRIPTION + PATIENT + VISIT INFORMATION
    --------------------------------------------------------- */

    $stmt = $pdo->prepare("
        SELECT
            pr.prescription_id,
            pr.visit_id,
            pr.prescribed_by,
            pr.prescription_status,
            pr.prescription_notes,
            pr.prescribed_at,

            v.visit_number,
            v.visit_date,
            v.visit_type,
            v.department,
            v.status AS visit_status,

            p.patient_id,
            p.patient_number,
            p.first_name,
            p.middle_name,
            p.last_name,
            p.gender,
            p.date_of_birth,
            p.phone,
            p.id_number,

            c.diagnosis,
            c.treatment_plan

        FROM prescriptions pr

        INNER JOIN patient_visits v
            ON pr.visit_id = v.visit_id

        INNER JOIN patients p
            ON v.patient_id = p.patient_id

        LEFT JOIN consultations c
            ON v.visit_id = c.visit_id

        WHERE pr.prescription_id = ?

        ORDER BY c.consultation_id DESC

        LIMIT 1
    ");

    $stmt->execute([$prescription_id]);

    $prescription = $stmt->fetch();

    if (!$prescription) {
        die("Prescription not found.");
    }

    /* ---------------------------------------------------------
       GET PRESCRIPTION ITEMS
    --------------------------------------------------------- */

    $itemStmt = $pdo->prepare("
        SELECT
            pi.prescription_item_id,
            pi.medicine_id,
            pi.quantity_prescribed,
            pi.dosage,
            pi.frequency,
            pi.duration,
            pi.route,
            pi.instructions,
            pi.quantity_dispensed,
            pi.item_status,

            m.medicine_code,
            m.medicine_name,
            m.generic_name,
            m.dosage_form,
            m.strength,
            m.unit,
            m.selling_price,
            m.stock_quantity

        FROM prescription_items pi

        INNER JOIN medicines m
            ON pi.medicine_id = m.medicine_id

        WHERE pi.prescription_id = ?

        ORDER BY pi.prescription_item_id ASC
    ");

    $itemStmt->execute([$prescription_id]);

    $items = $itemStmt->fetchAll();

    /* ---------------------------------------------------------
       CALCULATE TOTAL
    --------------------------------------------------------- */

    $total = 0;

    foreach ($items as $item) {

        $quantity = (int) $item['quantity_prescribed'];

        $price = (float) $item['selling_price'];

        $subtotal = $quantity * $price;

        $total += $subtotal;
    }

} catch (PDOException $e) {

    die(
        "Unable to load prescription: "
        . htmlspecialchars($e->getMessage())
    );
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Prescription View -
        <?= htmlspecialchars($prescription['patient_number']) ?>
    </title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <style>

        body {
            background: #f5f7fa;
        }

        .page-header {
            background: #198754;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .patient-card {
            border-left: 5px solid #198754;
        }

        .medicine-table th {
            background: #198754;
            color: white;
        }

        .status-badge {
            font-size: 13px;
            padding: 7px 12px;
        }

        .total-box {
            font-size: 22px;
            font-weight: bold;
        }

        @media print {

            .no-print {
                display: none !important;
            }

            body {
                background: white;
            }

            .card {
                border: none !important;
            }

        }

    </style>

</head>

<body>

<div class="container-fluid py-4">

    <!-- HEADER -->

    <div class="page-header d-flex justify-content-between align-items-center">

        <div>

            <h3 class="mb-1">
                Pharmacy Prescription
            </h3>

            <div>
                Prescription No:
                <strong>
                    #<?= htmlspecialchars($prescription['prescription_id']) ?>
                </strong>
            </div>

        </div>

        <div class="no-print">

            <button
                onclick="window.print()"
                class="btn btn-light"
            >
                🖨 Print
            </button>

            <a
                href="queue.php"
                class="btn btn-dark"
            >
                Back to Pharmacy
            </a>

        </div>

    </div>


    <!-- PATIENT INFORMATION -->

    <div class="card shadow-sm patient-card mb-4">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Patient Information
            </h5>

        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-3 mb-3">

                    <strong>Patient Number</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['patient_number']
                        ) ?>
                    </div>

                </div>

                <div class="col-md-3 mb-3">

                    <strong>Patient Name</strong>

                    <div>

                        <?= htmlspecialchars(
                            $prescription['first_name']
                        ) ?>

                        <?= htmlspecialchars(
                            $prescription['middle_name'] ?? ''
                        ) ?>

                        <?= htmlspecialchars(
                            $prescription['last_name']
                        ) ?>

                    </div>

                </div>

                <div class="col-md-2 mb-3">

                    <strong>Gender</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['gender'] ?? ''
                        ) ?>
                    </div>

                </div>

                <div class="col-md-2 mb-3">

                    <strong>Date of Birth</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['date_of_birth'] ?? ''
                        ) ?>
                    </div>

                </div>

                <div class="col-md-2 mb-3">

                    <strong>Phone</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['phone'] ?? ''
                        ) ?>
                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- VISIT / CLINICAL INFORMATION -->

    <div class="card shadow-sm mb-4">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Clinical Information
            </h5>

        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-3 mb-3">

                    <strong>Visit Number</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['visit_number']
                        ) ?>
                    </div>

                </div>

                <div class="col-md-3 mb-3">

                    <strong>Visit Date</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['visit_date']
                        ) ?>
                    </div>

                </div>

                <div class="col-md-3 mb-3">

                    <strong>Visit Type</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['visit_type']
                        ) ?>
                    </div>

                </div>

                <div class="col-md-3 mb-3">

                    <strong>Department</strong>

                    <div>
                        <?= htmlspecialchars(
                            $prescription['department'] ?? ''
                        ) ?>
                    </div>

                </div>

                <div class="col-md-8">

                    <strong>Diagnosis</strong>

                    <div class="mt-1">

                        <?= nl2br(
                            htmlspecialchars(
                                $prescription['diagnosis'] ?? 'Not specified'
                            )
                        ) ?>

                    </div>

                </div>

                <div class="col-md-4">

                    <strong>Prescription Status</strong>

                    <div class="mt-1">

                        <?php

                        $status = $prescription['prescription_status'];

                        $badgeClass = 'bg-secondary';

                        if ($status === 'Pending') {
                            $badgeClass = 'bg-warning text-dark';
                        }

                        if ($status === 'Dispensing') {
                            $badgeClass = 'bg-info text-dark';
                        }

                        if ($status === 'Completed') {
                            $badgeClass = 'bg-success';
                        }

                        if ($status === 'Cancelled') {
                            $badgeClass = 'bg-danger';
                        }

                        ?>

                        <span class="badge <?= $badgeClass ?> status-badge">

                            <?= htmlspecialchars($status) ?>

                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- MEDICINES -->

    <div class="card shadow-sm mb-4">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Prescribed Medicines
            </h5>

        </div>

        <div class="card-body p-0">

            <?php if (empty($items)): ?>

                <div class="alert alert-warning m-3">

                    No medicines were prescribed.

                </div>

            <?php else: ?>

                <div class="table-responsive">

                    <table class="table table-bordered table-hover medicine-table mb-0">

                        <thead>

                        <tr>

                            <th>#</th>

                            <th>Medicine</th>

                            <th>Strength</th>

                            <th>Dosage</th>

                            <th>Frequency</th>

                            <th>Duration</th>

                            <th>Route</th>

                            <th>Qty</th>

                            <th>Price</th>

                            <th>Total</th>

                            <th>Status</th>

                        </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($items as $index => $item): ?>

                            <?php

                            $quantity =
                                (int) $item['quantity_prescribed'];

                            $price =
                                (float) $item['selling_price'];

                            $subtotal =
                                $quantity * $price;

                            ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>

                                <td>

                                    <strong>
                                        <?= htmlspecialchars(
                                            $item['medicine_name']
                                        ) ?>
                                    </strong>

                                    <br>

                                    <small class="text-muted">

                                        <?= htmlspecialchars(
                                            $item['medicine_code']
                                        ) ?>

                                        <?php if (!empty($item['generic_name'])): ?>

                                            |
                                            <?= htmlspecialchars(
                                                $item['generic_name']
                                            ) ?>

                                        <?php endif; ?>

                                    </small>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $item['strength'] ?? ''
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $item['dosage'] ?? ''
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $item['frequency'] ?? ''
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $item['duration'] ?? ''
                                    ) ?>

                                </td>

                                <td>

                                    <?= htmlspecialchars(
                                        $item['route'] ?? ''
                                    ) ?>

                                </td>

                                <td>

                                    <?= $quantity ?>

                                    <?php if (!empty($item['unit'])): ?>

                                        <small>
                                            <?= htmlspecialchars(
                                                $item['unit']
                                            ) ?>
                                        </small>

                                    <?php endif; ?>

                                </td>

                                <td>

                                    KSh
                                    <?= number_format(
                                        $price,
                                        2
                                    ) ?>

                                </td>

                                <td>

                                    <strong>

                                        KSh
                                        <?= number_format(
                                            $subtotal,
                                            2
                                        ) ?>

                                    </strong>

                                </td>

                                <td>

                                    <?php

                                    $itemStatus =
                                        $item['item_status'];

                                    $itemBadge =
                                        'bg-warning text-dark';

                                    if ($itemStatus === 'Dispensed') {
                                        $itemBadge =
                                            'bg-success';
                                    }

                                    if ($itemStatus === 'Cancelled') {
                                        $itemBadge =
                                            'bg-danger';
                                    }

                                    ?>

                                    <span
                                        class="badge <?= $itemBadge ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $itemStatus
                                        ) ?>

                                    </span>

                                </td>

                            </tr>

                            <?php if (!empty($item['instructions'])): ?>

                                <tr>

                                    <td></td>

                                    <td colspan="10">

                                        <small>

                                            <strong>
                                                Instructions:
                                            </strong>

                                            <?= htmlspecialchars(
                                                $item['instructions']
                                            ) ?>

                                        </small>

                                    </td>

                                </tr>

                            <?php endif; ?>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </div>

    </div>


    <!-- TOTAL -->

    <div class="row justify-content-end mb-4">

        <div class="col-md-4">

            <div class="card shadow-sm">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <span>
                            Total Prescription Cost
                        </span>

                        <span class="total-box">

                            KSh
                            <?= number_format(
                                $total,
                                2
                            ) ?>

                        </span>

                    </div>

                </div>

            </div>

        </div>

    </div>


    <!-- NOTES -->

    <?php if (!empty($prescription['prescription_notes'])): ?>

        <div class="card shadow-sm mb-4">

            <div class="card-header bg-white">

                <h5 class="mb-0">
                    Prescription Notes
                </h5>

            </div>

            <div class="card-body">

                <?= nl2br(
                    htmlspecialchars(
                        $prescription['prescription_notes']
                    )
                ) ?>

            </div>

        </div>

    <?php endif; ?>


    <!-- ACTIONS -->

    <div class="card shadow-sm no-print">

        <div class="card-body">

            <div class="d-flex gap-2">

                <a
                    href="queue.php"
                    class="btn btn-secondary"
                >
                    ← Pharmacy Queue
                </a>

                <button
                    onclick="window.print()"
                    class="btn btn-primary"
                >
                    🖨 Print Prescription
                </button>

                <?php if (
                    $prescription['prescription_status'] === 'Pending'
                    || $prescription['prescription_status'] === 'Dispensing'
                ): ?>

                    <a
                        href="dispense.php?prescription_id=<?= $prescription_id ?>"
                        class="btn btn-success"
                    >
                        💊 Dispense Medicines
                    </a>

                <?php endif; ?>

            </div>

        </div>

    </div>

</div>

</body>

</html>