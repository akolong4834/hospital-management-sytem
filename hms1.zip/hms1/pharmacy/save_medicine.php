<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

check_authentication();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: medicines.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| Get submitted data
|--------------------------------------------------------------------------
*/

$medicine_code = trim($_POST['medicine_code'] ?? '');
$medicine_name = trim($_POST['medicine_name'] ?? '');
$generic_name = trim($_POST['generic_name'] ?? '');
$category = trim($_POST['category'] ?? '');
$dosage_form = trim($_POST['dosage_form'] ?? '');
$strength = trim($_POST['strength'] ?? '');
$unit = trim($_POST['unit'] ?? '');

$selling_price = isset($_POST['selling_price'])
    ? (float) $_POST['selling_price']
    : 0;

$stock_quantity = isset($_POST['stock_quantity'])
    ? (int) $_POST['stock_quantity']
    : 0;

$reorder_level = isset($_POST['reorder_level'])
    ? (int) $_POST['reorder_level']
    : 0;


/*
|--------------------------------------------------------------------------
| Validate
|--------------------------------------------------------------------------
*/

if ($medicine_code === '') {
    die("Medicine code is required.");
}

if ($medicine_name === '') {
    die("Medicine name is required.");
}

if ($selling_price < 0) {
    die("Selling price cannot be negative.");
}

if ($stock_quantity < 0) {
    die("Stock quantity cannot be negative.");
}

if ($reorder_level < 0) {
    die("Reorder level cannot be negative.");
}


/*
|--------------------------------------------------------------------------
| Check duplicate medicine code
|--------------------------------------------------------------------------
*/

$checkStmt = $pdo->prepare("
    SELECT medicine_id
    FROM medicines
    WHERE medicine_code = ?
    LIMIT 1
");

$checkStmt->execute([$medicine_code]);

if ($checkStmt->fetch()) {

    die(
        "Medicine code already exists. "
        . htmlspecialchars($medicine_code)
    );
}


/*
|--------------------------------------------------------------------------
| Save medicine
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        INSERT INTO medicines
        (
            medicine_code,
            medicine_name,
            generic_name,
            category,
            dosage_form,
            strength,
            unit,
            selling_price,
            stock_quantity,
            reorder_level,
            status,
            created_at
        )
        VALUES
        (
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            ?,
            'Active',
            NOW()
        )
    ");

    $stmt->execute([
        $medicine_code,
        $medicine_name,
        $generic_name,
        $category,
        $dosage_form,
        $strength,
        $unit,
        $selling_price,
        $stock_quantity,
        $reorder_level
    ]);


    header("Location: medicines.php?saved=1");

    exit();

} catch (PDOException $e) {

    die(
        "Unable to save medicine. "
        . htmlspecialchars($e->getMessage())
    );
}

?>