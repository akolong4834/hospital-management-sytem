<?php
require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/auth.php';require_login();
$iid=(int)($_POST['invoice_id']??0);$amount=(float)($_POST['amount']??0);$method=(int)($_POST['payment_method_id']??0);$ref=trim($_POST['transaction_reference']??'');
$pdo->beginTransaction();
try{
 $s=$pdo->prepare("SELECT * FROM invoices WHERE id=? FOR UPDATE");$s->execute([$iid]);$i=$s->fetch();if(!$i)throw new Exception('Invoice not found.');if($amount<=0||$amount>$i['balance'])throw new Exception('Invalid payment amount.');
 $receipt='RCT'.date('YmdHis').random_int(100,999);
 $pdo->prepare("INSERT INTO payments(receipt_no,invoice_id,patient_id,payment_method_id,amount,transaction_reference,phone,received_by) VALUES(?,?,?,?,?,?,?,?)")->execute([$receipt,$iid,$i['patient_id'],$method,$amount,$ref?:null,trim($_POST['phone']??'')?:null,$_SESSION['user_id']]);
 $paid=(float)$i['amount_paid']+$amount;$bal=max(0,(float)$i['patient_amount']-$paid);$status=$bal<=0?'Paid':($paid>0?'Partially Paid':'Unpaid');
 $pdo->prepare("UPDATE invoices SET amount_paid=?,balance=?,status=? WHERE id=?")->execute([$paid,$bal,$status,$iid]);
 if($status==='Paid')$pdo->prepare("UPDATE patient_visits SET status='Completed' WHERE id=?")->execute([$i['visit_id']]);
 $pdo->commit();header('Location: receipt.php?receipt='.urlencode($receipt));exit;
}catch(Throwable $e){$pdo->rollBack();http_response_code(400);exit('Payment failed: '.$e->getMessage());}