<?php
$title='Patient Payment';
require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../includes/header.php';
$id=(int)($_GET['invoice_id']??0);$s=$pdo->prepare("SELECT i.*,p.patient_no,CONCAT_WS(' ',p.first_name,p.middle_name,p.last_name) patient_name FROM invoices i JOIN patients p ON p.id=i.patient_id WHERE i.id=?");$s->execute([$id]);$i=$s->fetch();if(!$i)exit('Invoice not found.');
$m=$pdo->query("SELECT id,name FROM payment_methods WHERE is_active=1 ORDER BY name")->fetchAll();?>
<div class="card p-4"><h5><?=htmlspecialchars($i['invoice_no'])?> — <?=htmlspecialchars($i['patient_name'])?></h5><p>Outstanding balance: <b>KSh <?=number_format($i['balance'],2)?></b></p>
<form method="post" action="save.php"><input type="hidden" name="invoice_id" value="<?=$id?>">
<div class="row g-3"><div class="col-md-4"><label class="form-label">Amount</label><input class="form-control" type="number" step="0.01" min="0.01" max="<?=$i['balance']?>" name="amount" value="<?=$i['balance']?>" required></div>
<div class="col-md-4"><label class="form-label">Payment Method</label><select class="form-select" name="payment_method_id" required><?php foreach($m as $x):?><option value="<?=$x['id']?>"><?=htmlspecialchars($x['name'])?></option><?php endforeach;?></select></div>
<div class="col-md-4"><label class="form-label">Transaction Reference</label><input class="form-control" name="transaction_reference" placeholder="M-Pesa receipt / card ref / bank ref"></div>
<div class="col-md-4"><label class="form-label">Payer Phone</label><input class="form-control" name="phone"></div></div>
<button class="btn btn-success mt-4">Record Payment</button></form></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>