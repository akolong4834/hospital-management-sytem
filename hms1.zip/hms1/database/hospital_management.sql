-- Hospital Management System
-- MySQL 8.x
-- Core schema for patient registration -> triage -> consultation -> laboratory/pharmacy -> billing -> payment

CREATE DATABASE IF NOT EXISTS hospital_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hospital_management;

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS audit_logs, insurance_claims, payments, payment_methods,
invoice_items, invoices, dispensing, medicine_stock, medicines,
prescription_items, prescriptions, lab_results, lab_order_items, lab_orders,
lab_tests, diagnoses, consultation_diagnoses, consultations, triage,
patient_visits, patients, users, roles;

SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE roles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role_id INT UNSIGNED NOT NULL,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(150),
    phone VARCHAR(30),
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(id)
) ENGINE=InnoDB;

CREATE TABLE patients (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    patient_no VARCHAR(30) NOT NULL UNIQUE,
    first_name VARCHAR(80) NOT NULL,
    middle_name VARCHAR(80),
    last_name VARCHAR(80) NOT NULL,
    date_of_birth DATE,
    gender ENUM('Male','Female','Other') NOT NULL,
    national_id VARCHAR(50),
    phone VARCHAR(30),
    email VARCHAR(150),
    address VARCHAR(255),
    county VARCHAR(100),
    next_of_kin_name VARCHAR(150),
    next_of_kin_phone VARCHAR(30),
    blood_group VARCHAR(10),
    insurance_provider VARCHAR(150),
    insurance_member_no VARCHAR(80),
    sha_member_no VARCHAR(80),
    allergies TEXT,
    notes TEXT,
    created_by INT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_patient_national_id (national_id),
    KEY idx_patient_name (last_name, first_name),
    KEY idx_patient_phone (phone),
    CONSTRAINT fk_patient_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE patient_visits (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    visit_no VARCHAR(40) NOT NULL UNIQUE,
    patient_id BIGINT UNSIGNED NOT NULL,
    visit_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    visit_type ENUM('Outpatient','Emergency','Inpatient','Follow-up') NOT NULL DEFAULT 'Outpatient',
    department VARCHAR(100),
    status ENUM('Registered','Triage','Consultation','Lab','Pharmacy','Billing','Completed','Cancelled') NOT NULL DEFAULT 'Registered',
    chief_complaint TEXT,
    created_by INT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_visit_patient (patient_id),
    KEY idx_visit_status (status),
    CONSTRAINT fk_visit_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    CONSTRAINT fk_visit_created_by FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE triage (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    visit_id BIGINT UNSIGNED NOT NULL UNIQUE,
    weight_kg DECIMAL(6,2),
    height_cm DECIMAL(6,2),
    temperature_c DECIMAL(4,1),
    systolic_bp SMALLINT UNSIGNED,
    diastolic_bp SMALLINT UNSIGNED,
    pulse_bpm SMALLINT UNSIGNED,
    respiratory_rate SMALLINT UNSIGNED,
    spo2_percent DECIMAL(5,2),
    pain_score TINYINT UNSIGNED,
    symptoms TEXT,
    priority ENUM('Routine','Urgent','Emergency') DEFAULT 'Routine',
    notes TEXT,
    assessed_by INT UNSIGNED,
    assessed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    KEY idx_triage_priority (priority),
    CONSTRAINT fk_triage_visit FOREIGN KEY (visit_id) REFERENCES patient_visits(id) ON DELETE CASCADE,
    CONSTRAINT fk_triage_user FOREIGN KEY (assessed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE consultations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    visit_id BIGINT UNSIGNED NOT NULL UNIQUE,
    clinician_id INT UNSIGNED,
    history_of_presenting_illness TEXT,
    past_medical_history TEXT,
    physical_examination TEXT,
    assessment TEXT,
    treatment_plan TEXT,
    follow_up_date DATE,
    status ENUM('Open','Completed') DEFAULT 'Open',
    consulted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    CONSTRAINT fk_consult_visit FOREIGN KEY (visit_id) REFERENCES patient_visits(id) ON DELETE CASCADE,
    CONSTRAINT fk_consult_clinician FOREIGN KEY (clinician_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE diagnoses (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    is_active TINYINT(1) DEFAULT 1,
    UNIQUE KEY uq_diagnosis_code (code)
) ENGINE=InnoDB;

CREATE TABLE consultation_diagnoses (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    consultation_id BIGINT UNSIGNED NOT NULL,
    diagnosis_id BIGINT UNSIGNED NOT NULL,
    diagnosis_type ENUM('Primary','Secondary') DEFAULT 'Primary',
    notes TEXT,
    UNIQUE KEY uq_consult_diagnosis (consultation_id, diagnosis_id),
    CONSTRAINT fk_cd_consult FOREIGN KEY (consultation_id) REFERENCES consultations(id) ON DELETE CASCADE,
    CONSTRAINT fk_cd_diagnosis FOREIGN KEY (diagnosis_id) REFERENCES diagnoses(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE lab_tests (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    test_code VARCHAR(40) NOT NULL UNIQUE,
    test_name VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    specimen_type VARCHAR(100),
    turnaround_hours DECIMAL(6,2),
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE lab_orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_no VARCHAR(40) NOT NULL UNIQUE,
    visit_id BIGINT UNSIGNED NOT NULL,
    consultation_id BIGINT UNSIGNED,
    ordered_by INT UNSIGNED,
    status ENUM('Ordered','Sample Collected','Processing','Completed','Cancelled') DEFAULT 'Ordered',
    clinical_notes TEXT,
    ordered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_lab_order_visit FOREIGN KEY (visit_id) REFERENCES patient_visits(id) ON DELETE CASCADE,
    CONSTRAINT fk_lab_order_consult FOREIGN KEY (consultation_id) REFERENCES consultations(id) ON DELETE SET NULL,
    CONSTRAINT fk_lab_order_user FOREIGN KEY (ordered_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE lab_order_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lab_order_id BIGINT UNSIGNED NOT NULL,
    lab_test_id BIGINT UNSIGNED NOT NULL,
    status ENUM('Pending','Sample Collected','Processing','Completed','Cancelled') DEFAULT 'Pending',
    price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    UNIQUE KEY uq_lab_order_test (lab_order_id, lab_test_id),
    CONSTRAINT fk_loi_order FOREIGN KEY (lab_order_id) REFERENCES lab_orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_loi_test FOREIGN KEY (lab_test_id) REFERENCES lab_tests(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE lab_results (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lab_order_item_id BIGINT UNSIGNED NOT NULL UNIQUE,
    result_value TEXT,
    reference_range VARCHAR(150),
    unit VARCHAR(50),
    interpretation TEXT,
    performed_by INT UNSIGNED,
    result_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified_by INT UNSIGNED,
    verified_at DATETIME NULL,
    CONSTRAINT fk_lab_result_item FOREIGN KEY (lab_order_item_id) REFERENCES lab_order_items(id) ON DELETE CASCADE,
    CONSTRAINT fk_lab_performed_by FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_lab_verified_by FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE medicines (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    medicine_code VARCHAR(40) NOT NULL UNIQUE,
    medicine_name VARCHAR(180) NOT NULL,
    generic_name VARCHAR(180),
    dosage_form VARCHAR(80),
    strength VARCHAR(80),
    unit VARCHAR(40) DEFAULT 'unit',
    selling_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    reorder_level INT UNSIGNED DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE medicine_stock (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    medicine_id BIGINT UNSIGNED NOT NULL,
    batch_no VARCHAR(80),
    expiry_date DATE,
    quantity INT NOT NULL DEFAULT 0,
    unit_cost DECIMAL(12,2) DEFAULT 0.00,
    received_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_stock_batch (medicine_id, batch_no),
    CONSTRAINT fk_stock_medicine FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE prescriptions (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    prescription_no VARCHAR(40) NOT NULL UNIQUE,
    visit_id BIGINT UNSIGNED NOT NULL,
    consultation_id BIGINT UNSIGNED,
    prescribed_by INT UNSIGNED,
    status ENUM('Pending','Partially Dispensed','Dispensed','Cancelled') DEFAULT 'Pending',
    notes TEXT,
    prescribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rx_visit FOREIGN KEY (visit_id) REFERENCES patient_visits(id) ON DELETE CASCADE,
    CONSTRAINT fk_rx_consult FOREIGN KEY (consultation_id) REFERENCES consultations(id) ON DELETE SET NULL,
    CONSTRAINT fk_rx_user FOREIGN KEY (prescribed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE prescription_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    prescription_id BIGINT UNSIGNED NOT NULL,
    medicine_id BIGINT UNSIGNED NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    duration VARCHAR(100),
    quantity_prescribed INT UNSIGNED NOT NULL,
    quantity_dispensed INT UNSIGNED NOT NULL DEFAULT 0,
    instructions TEXT,
    price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    CONSTRAINT fk_rxi_prescription FOREIGN KEY (prescription_id) REFERENCES prescriptions(id) ON DELETE CASCADE,
    CONSTRAINT fk_rxi_medicine FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE dispensing (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    prescription_item_id BIGINT UNSIGNED NOT NULL,
    stock_id BIGINT UNSIGNED,
    quantity INT UNSIGNED NOT NULL,
    dispensed_by INT UNSIGNED,
    dispensed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    CONSTRAINT fk_disp_item FOREIGN KEY (prescription_item_id) REFERENCES prescription_items(id) ON DELETE CASCADE,
    CONSTRAINT fk_disp_stock FOREIGN KEY (stock_id) REFERENCES medicine_stock(id) ON DELETE SET NULL,
    CONSTRAINT fk_disp_user FOREIGN KEY (dispensed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE invoices (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(40) NOT NULL UNIQUE,
    visit_id BIGINT UNSIGNED NOT NULL,
    patient_id BIGINT UNSIGNED NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    discount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    insurance_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    patient_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    balance DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    status ENUM('Unpaid','Partially Paid','Paid','Cancelled') DEFAULT 'Unpaid',
    due_date DATE,
    created_by INT UNSIGNED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_invoice_visit FOREIGN KEY (visit_id) REFERENCES patient_visits(id) ON DELETE RESTRICT,
    CONSTRAINT fk_invoice_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    CONSTRAINT fk_invoice_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE invoice_items (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id BIGINT UNSIGNED NOT NULL,
    service_type ENUM('Registration','Consultation','Laboratory','Pharmacy','Procedure','Other') NOT NULL,
    reference_id BIGINT UNSIGNED NULL,
    description VARCHAR(255) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
    unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    CONSTRAINT fk_invoice_item_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payment_methods (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(150),
    is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE payments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    receipt_no VARCHAR(40) NOT NULL UNIQUE,
    invoice_id BIGINT UNSIGNED NOT NULL,
    patient_id BIGINT UNSIGNED NOT NULL,
    payment_method_id INT UNSIGNED NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    transaction_reference VARCHAR(100),
    payer_name VARCHAR(150),
    phone VARCHAR(30),
    notes TEXT,
    received_by INT UNSIGNED,
    paid_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Pending','Completed','Failed','Reversed') DEFAULT 'Completed',
    UNIQUE KEY uq_payment_reference (transaction_reference),
    CONSTRAINT fk_payment_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE RESTRICT,
    CONSTRAINT fk_payment_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    CONSTRAINT fk_payment_method FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id) ON DELETE RESTRICT,
    CONSTRAINT fk_payment_user FOREIGN KEY (received_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE insurance_claims (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    invoice_id BIGINT UNSIGNED NOT NULL,
    provider_name VARCHAR(150) NOT NULL,
    member_no VARCHAR(80),
    claim_no VARCHAR(80),
    claim_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    approved_amount DECIMAL(12,2) DEFAULT 0.00,
    status ENUM('Draft','Submitted','Approved','Partially Approved','Rejected','Paid') DEFAULT 'Draft',
    submitted_at DATETIME NULL,
    paid_at DATETIME NULL,
    notes TEXT,
    CONSTRAINT fk_claim_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100),
    record_id BIGINT UNSIGNED,
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_audit_user (user_id),
    KEY idx_audit_table_record (table_name, record_id),
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Seed roles
INSERT INTO roles (name, description) VALUES
('Administrator','Full system access'),
('Receptionist','Patient registration and visits'),
('Nurse','Triage and nursing workflow'),
('Clinician','Consultation, diagnosis and prescriptions'),
('Laboratory','Laboratory orders and results'),
('Pharmacist','Pharmacy and medicine dispensing'),
('Cashier','Billing and payments'),
('Accountant','Finance and reports');

-- Seed payment methods
INSERT INTO payment_methods (name, description) VALUES
('Cash','Cash payment'),
('M-Pesa','Safaricom M-Pesa'),
('Card','Debit/Credit card'),
('Insurance','Private insurance'),
('SHA','Social Health Authority'),
('Corporate','Corporate account'),
('Bank','Bank transfer/deposit');

-- Seed sample laboratory tests
INSERT INTO lab_tests (test_code, test_name, category, price, specimen_type) VALUES
('FBC','Full Blood Count','Haematology',500,'Blood'),
('RBS','Random Blood Sugar','Biochemistry',150,'Blood'),
('URINALYSIS','Urinalysis','Routine',300,'Urine'),
('MALARIA','Malaria Test','Parasitology',300,'Blood');

-- Seed sample medicines
INSERT INTO medicines (medicine_code, medicine_name, generic_name, dosage_form, strength, unit, selling_price, reorder_level) VALUES
('PCM500','Paracetamol','Paracetamol','Tablet','500 mg','tablet',10,100),
('AMOX500','Amoxicillin','Amoxicillin','Capsule','500 mg','capsule',25,50);

-- Create a view for patient visit flow
CREATE OR REPLACE VIEW v_patient_visit_flow AS
SELECT
    v.id AS visit_id,
    v.visit_no,
    v.visit_date,
    v.status,
    p.id AS patient_id,
    p.patient_no,
    CONCAT_WS(' ', p.first_name, p.middle_name, p.last_name) AS patient_name,
    t.id AS triage_id,
    c.id AS consultation_id,
    lo.id AS lab_order_id,
    rx.id AS prescription_id,
    i.id AS invoice_id,
    i.invoice_no,
    i.patient_amount,
    i.amount_paid,
    i.balance
FROM patient_visits v
JOIN patients p ON p.id = v.patient_id
LEFT JOIN triage t ON t.visit_id = v.id
LEFT JOIN consultations c ON c.visit_id = v.id
LEFT JOIN lab_orders lo ON lo.visit_id = v.id
LEFT JOIN prescriptions rx ON rx.visit_id = v.id
LEFT JOIN invoices i ON i.visit_id = v.id;

-- End of schema
