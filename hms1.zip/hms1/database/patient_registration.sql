CREATE DATABASE IF NOT EXISTS hospital_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hospital_management;
CREATE TABLE IF NOT EXISTS patients(
 patient_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, patient_number VARCHAR(30) UNIQUE NULL,
 first_name VARCHAR(100) NOT NULL,middle_name VARCHAR(100),last_name VARCHAR(100) NOT NULL,
 gender VARCHAR(20) NOT NULL,date_of_birth DATE NOT NULL,id_number VARCHAR(100),phone VARCHAR(30) NOT NULL,
 email VARCHAR(150),county VARCHAR(100),sub_county VARCHAR(100),village VARCHAR(150),occupation VARCHAR(150),
 next_of_kin_name VARCHAR(200),next_of_kin_relationship VARCHAR(100),next_of_kin_phone VARCHAR(30),
 blood_group VARCHAR(10),allergies TEXT,emergency_contact TEXT,created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_patient_id_number(id_number),KEY idx_patient_name(last_name,first_name),KEY idx_patient_phone(phone)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS patient_visits(
 visit_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,visit_number VARCHAR(30) UNIQUE NULL,patient_id INT UNSIGNED NOT NULL,
 visit_date DATE NOT NULL,visit_type VARCHAR(50) DEFAULT 'Outpatient',department VARCHAR(150),
 payment_category VARCHAR(50) DEFAULT 'Cash',chief_complaint TEXT,status VARCHAR(50) DEFAULT 'Registered',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_visit_patient FOREIGN KEY(patient_id) REFERENCES patients(patient_id) ON UPDATE CASCADE ON DELETE RESTRICT,
 KEY idx_visit_patient(patient_id),KEY idx_visit_date_status(visit_date,status)
) ENGINE=InnoDB;