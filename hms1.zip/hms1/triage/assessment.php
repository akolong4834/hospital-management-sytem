<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

check_authentication();

$visit_id = filter_input(
    INPUT_GET,
    'visit_id',
    FILTER_VALIDATE_INT
);

if (!$visit_id) {
    die("Invalid visit ID.");
}


/*
|--------------------------------------------------------------------------
| Get Visit and Patient Details
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.department,
        v.payment_category,
        v.chief_complaint,
        v.status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,
        p.email,
        p.blood_group,
        p.allergies

    FROM patient_visits v

    INNER JOIN patients p
        ON p.patient_id = v.patient_id

    WHERE v.visit_id = ?
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$visit_id]);

$visit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$visit) {
    die("The selected visit could not be found.");
}


/*
|--------------------------------------------------------------------------
| Get Existing Triage Assessment
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT
        id,
        visit_id,
        weight_kg,
        height_cm,
        temperature_c,
        systolic_bp,
        diastolic_bp,
        pulse_bpm,
        respiratory_rate,
        spo2_percent,
        pain_score,
        symptoms,
        priority,
        notes,
        assessed_by,
        assessed_at

    FROM triage

    WHERE visit_id = ?

    LIMIT 1
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$visit_id]);

$triage = $stmt->fetch(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Helper Function
|--------------------------------------------------------------------------
*/

function field_value($field)
{
    global $triage;

    if (!$triage) {
        return '';
    }

    return htmlspecialchars(
        $triage[$field] ?? '',
        ENT_QUOTES,
        'UTF-8'
    );
}

?>

<?php include __DIR__ . '/../includes/header.php'; ?>


<div class="container-fluid py-4">


    <!-- PAGE HEADER -->

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3 class="mb-1">
                Triage Assessment
            </h3>

            <p class="text-muted mb-0">

                Patient:
                <strong>
                    <?= htmlspecialchars(
                        trim(
                            $visit['first_name'] . ' ' .
                            ($visit['middle_name'] ?? '') . ' ' .
                            $visit['last_name']
                        )
                    ) ?>
                </strong>

            </p>

        </div>


        <a
            href="queue.php"
            class="btn btn-outline-secondary"
        >
            ← Back to Queue
        </a>

    </div>



    <!-- PATIENT INFORMATION -->

    <div class="card shadow-sm mb-4">

        <div class="card-header bg-primary text-white">

            <strong>
                Patient Information
            </strong>

        </div>


        <div class="card-body">

            <div class="row g-3">

                <div class="col-md-3">

                    <label class="text-muted">
                        Patient Number
                    </label>

                    <div class="fw-bold">

                        <?= htmlspecialchars(
                            $visit['patient_number']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3">

                    <label class="text-muted">
                        Visit Number
                    </label>

                    <div class="fw-bold">

                        <?= htmlspecialchars(
                            $visit['visit_number']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3">

                    <label class="text-muted">
                        Gender
                    </label>

                    <div>

                        <?= htmlspecialchars(
                            $visit['gender']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3">

                    <label class="text-muted">
                        Phone
                    </label>

                    <div>

                        <?= htmlspecialchars(
                            $visit['phone']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3">

                    <label class="text-muted">
                        Visit Type
                    </label>

                    <div>

                        <?= htmlspecialchars(
                            $visit['visit_type']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3">

                    <label class="text-muted">
                        Department
                    </label>

                    <div>

                        <?= htmlspecialchars(
                            $visit['department']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3">

                    <label class="text-muted">
                        Payment Category
                    </label>

                    <div>

                        <?= htmlspecialchars(
                            $visit['payment_category']
                        ) ?>

                    </div>

                </div>


                <div class="col-md-3">

                    <label class="text-muted">
                        Blood Group
                    </label>

                    <div>

                        <?= htmlspecialchars(
                            $visit['blood_group'] ?? 'Not recorded'
                        ) ?>

                    </div>

                </div>

            </div>


            <hr>


            <div class="row">

                <div class="col-md-6">

                    <strong>
                        Chief Complaint
                    </strong>

                    <div class="mt-1">

                        <?= nl2br(
                            htmlspecialchars(
                                $visit['chief_complaint']
                                ?? 'Not recorded'
                            )
                        ) ?>

                    </div>

                </div>


                <div class="col-md-6">

                    <strong>
                        Known Allergies
                    </strong>

                    <div class="mt-1 text-danger">

                        <?= nl2br(
                            htmlspecialchars(
                                $visit['allergies']
                                ?? 'None recorded'
                            )
                        ) ?>

                    </div>

                </div>

            </div>

        </div>

    </div>



    <!-- TRIAGE FORM -->

    <form
        method="POST"
        action="save.php"
    >

        <input
            type="hidden"
            name="visit_id"
            value="<?= (int)$visit_id ?>"
        >


        <!-- VITAL SIGNS -->

        <div class="card shadow-sm mb-4">

            <div class="card-header bg-success text-white">

                <strong>
                    Vital Signs
                </strong>

            </div>


            <div class="card-body">

                <div class="row g-3">


                    <!-- WEIGHT -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Weight (kg)
                        </label>

                        <input
                            type="number"
                            step="0.01"
                            min="0"
                            max="500"
                            name="weight_kg"
                            class="form-control"
                            value="<?= field_value('weight_kg') ?>"
                        >

                    </div>


                    <!-- HEIGHT -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Height (cm)
                        </label>

                        <input
                            type="number"
                            step="0.01"
                            min="0"
                            max="250"
                            name="height_cm"
                            class="form-control"
                            value="<?= field_value('height_cm') ?>"
                        >

                    </div>


                    <!-- TEMPERATURE -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Temperature (°C)
                        </label>

                        <input
                            type="number"
                            step="0.1"
                            min="25"
                            max="45"
                            name="temperature_c"
                            class="form-control"
                            value="<?= field_value('temperature_c') ?>"
                        >

                    </div>


                    <!-- SPO2 -->

                    <div class="col-md-3">

                        <label class="form-label">
                            SpO₂ (%)
                        </label>

                        <input
                            type="number"
                            step="0.1"
                            min="0"
                            max="100"
                            name="spo2_percent"
                            class="form-control"
                            value="<?= field_value('spo2_percent') ?>"
                        >

                    </div>


                    <!-- BLOOD PRESSURE -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Systolic BP
                        </label>

                        <input
                            type="number"
                            min="0"
                            max="300"
                            name="systolic_bp"
                            class="form-control"
                            placeholder="e.g. 120"
                            value="<?= field_value('systolic_bp') ?>"
                        >

                        <small class="text-muted">
                            mmHg
                        </small>

                    </div>


                    <div class="col-md-3">

                        <label class="form-label">
                            Diastolic BP
                        </label>

                        <input
                            type="number"
                            min="0"
                            max="200"
                            name="diastolic_bp"
                            class="form-control"
                            placeholder="e.g. 80"
                            value="<?= field_value('diastolic_bp') ?>"
                        >

                        <small class="text-muted">
                            mmHg
                        </small>

                    </div>


                    <!-- PULSE -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Pulse Rate
                        </label>

                        <input
                            type="number"
                            min="0"
                            max="300"
                            name="pulse_bpm"
                            class="form-control"
                            placeholder="Beats per minute"
                            value="<?= field_value('pulse_bpm') ?>"
                        >

                    </div>


                    <!-- RESPIRATORY RATE -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Respiratory Rate
                        </label>

                        <input
                            type="number"
                            min="0"
                            max="100"
                            name="respiratory_rate"
                            class="form-control"
                            placeholder="Breaths/min"
                            value="<?= field_value('respiratory_rate') ?>"
                        >

                    </div>


                    <!-- PAIN SCORE -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Pain Score
                        </label>

                        <select
                            name="pain_score"
                            class="form-select"
                        >

                            <option value="">
                                Select Pain Score
                            </option>

                            <?php for ($i = 0; $i <= 10; $i++): ?>

                                <option
                                    value="<?= $i ?>"
                                    <?= (
                                        isset($triage['pain_score']) &&
                                        (string)$triage['pain_score'] === (string)$i
                                    )
                                    ? 'selected'
                                    : ''
                                    ?>
                                >
                                    <?= $i ?>
                                </option>

                            <?php endfor; ?>

                        </select>

                        <small class="text-muted">
                            0 = No pain, 10 = Worst pain
                        </small>

                    </div>


                    <!-- PRIORITY -->

                    <div class="col-md-5">

                        <label class="form-label">
                            Triage Priority
                            <span class="text-danger">*</span>
                        </label>

                        <select
                            name="priority"
                            class="form-select"
                            required
                        >

                            <?php
                            $currentPriority =
                                $triage['priority']
                                ?? 'Routine';
                            ?>


                            <option
                                value="Routine"
                                <?= $currentPriority === 'Routine'
                                    ? 'selected'
                                    : '' ?>
                            >
                                Routine
                            </option>


                            <option
                                value="Urgent"
                                <?= $currentPriority === 'Urgent'
                                    ? 'selected'
                                    : '' ?>
                            >
                                Urgent
                            </option>


                            <option
                                value="Emergency"
                                <?= $currentPriority === 'Emergency'
                                    ? 'selected'
                                    : '' ?>
                            >
                                Emergency
                            </option>

                        </select>

                    </div>

                </div>

            </div>

        </div>



        <!-- CLINICAL ASSESSMENT -->

        <div class="card shadow-sm mb-4">

            <div class="card-header bg-info text-dark">

                <strong>
                    Clinical / Nursing Assessment
                </strong>

            </div>


            <div class="card-body">

                <div class="row g-4">


                    <div class="col-md-6">

                        <label class="form-label">
                            Presenting Symptoms
                        </label>

                        <textarea
                            name="symptoms"
                            class="form-control"
                            rows="6"
                            placeholder="Record the patient's presenting symptoms..."
                        ><?= field_value('symptoms') ?></textarea>

                    </div>


                    <div class="col-md-6">

                        <label class="form-label">
                            Nursing Notes
                        </label>

                        <textarea
                            name="notes"
                            class="form-control"
                            rows="6"
                            placeholder="Record relevant observations and nursing notes..."
                        ><?= field_value('notes') ?></textarea>

                    </div>

                </div>

            </div>

        </div>



        <!-- ASSESSOR -->

        <div class="card shadow-sm mb-4">

            <div class="card-body">

                <div class="row align-items-center">

                    <div class="col-md-6">

                        <label class="form-label">
                            Assessed By
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $_SESSION['full_name']
                                ?? $_SESSION['username']
                                ?? 'Logged-in User'
                            ) ?>"
                            readonly
                        >

                    </div>


                    <div class="col-md-6">

                        <?php if ($triage): ?>

                            <label class="form-label">
                                Last Assessment
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $triage['assessed_at']
                                ) ?>"
                                readonly
                            >

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>



        <!-- BUTTONS -->

        <div class="d-flex justify-content-between mb-5">

            <a
                href="queue.php"
                class="btn btn-secondary"
            >
                Cancel
            </a>


            <button
                type="submit"
                class="btn btn-success btn-lg"
            >

                Save Triage Assessment

            </button>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../includes/footer.php'; ?>