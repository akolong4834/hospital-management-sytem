<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

check_authentication();

$sql = "
    SELECT
        v.visit_id,
        v.visit_number,
        v.visit_date,
        v.visit_type,
        v.department,
        v.chief_complaint,
        v.status,

        p.patient_id,
        p.patient_number,
        p.first_name,
        p.middle_name,
        p.last_name,
        p.gender,
        p.date_of_birth,
        p.phone,

        t.id AS triage_id,
        t.priority,
        t.assessed_at

    FROM patient_visits v

    INNER JOIN patients p
        ON p.patient_id = v.patient_id

    LEFT JOIN triage t
        ON t.visit_id = v.visit_id

    WHERE v.status IN ('Registered', 'Triage')

    ORDER BY
        CASE
            WHEN t.priority = 'Emergency' THEN 1
            WHEN t.priority = 'Urgent' THEN 2
            ELSE 3
        END,
        v.visit_id ASC
";

try {

    $stmt = $pdo->query($sql);

    $patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    die(
        "<h3>Database Error</h3>" .
        htmlspecialchars($e->getMessage())
    );
}

include __DIR__ . '/../includes/header.php';

?>

<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3 class="mb-1">
                Triage Queue
            </h3>

            <p class="text-muted mb-0">
                Patients waiting for triage assessment
            </p>

        </div>

        <span class="badge bg-primary fs-6">
            <?= count($patients) ?> Waiting
        </span>

    </div>


    <?php if (empty($patients)): ?>

        <div class="card shadow-sm">

            <div class="card-body text-center py-5">

                <h5 class="text-muted">
                    No patients waiting for triage
                </h5>

                <p class="text-muted">
                    Registered visits will appear here.
                </p>

            </div>

        </div>

    <?php else: ?>

        <div class="card shadow-sm">

            <div class="card-header bg-primary text-white">

                <strong>
                    Patients Awaiting Triage
                </strong>

            </div>

            <div class="card-body p-0">

                <div class="table-responsive">

                    <table class="table table-hover table-bordered mb-0">

                        <thead class="table-light">

                            <tr>

                                <th>#</th>
                                <th>Visit No.</th>
                                <th>Patient No.</th>
                                <th>Patient Name</th>
                                <th>Gender</th>
                                <th>Phone</th>
                                <th>Visit Type</th>
                                <th>Department</th>
                                <th>Priority</th>
                                <th>Status</th>
                                <th>Action</th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($patients as $index => $patient): ?>

                            <?php

                            $patientName = trim(
                                $patient['first_name'] . ' ' .
                                ($patient['middle_name'] ?? '') . ' ' .
                                $patient['last_name']
                            );

                            $priority = $patient['priority'] ?? 'Routine';

                            if ($priority === 'Emergency') {

                                $priorityClass = 'danger';

                            } elseif ($priority === 'Urgent') {

                                $priorityClass = 'warning text-dark';

                            } else {

                                $priorityClass = 'secondary';

                            }

                            ?>

                            <tr>

                                <td>
                                    <?= $index + 1 ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= htmlspecialchars(
                                            $patient['visit_number']
                                        ) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['patient_number']
                                    ) ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= htmlspecialchars(
                                            $patientName
                                        ) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['gender']
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['phone']
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['visit_type']
                                    ) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $patient['department']
                                    ) ?>
                                </td>

                                <td>

                                    <span class="badge bg-<?= $priorityClass ?>">

                                        <?= htmlspecialchars(
                                            $priority
                                        ) ?>

                                    </span>

                                </td>

                                <td>

                                    <span class="badge bg-info text-dark">

                                        <?= htmlspecialchars(
                                            $patient['status']
                                        ) ?>

                                    </span>

                                </td>

                                <td>

                                    <a
                                        href="assessment.php?visit_id=<?= (int)$patient['visit_id'] ?>"
                                        class="btn btn-sm btn-primary"
                                    >
                                        Assess
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    <?php endif; ?>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>