<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

check_authentication();


/*
|--------------------------------------------------------------------------
| Only allow POST requests
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header('Location: queue.php');
    exit;

}


/*
|--------------------------------------------------------------------------
| Get Visit ID
|--------------------------------------------------------------------------
*/

$visit_id = filter_input(
    INPUT_POST,
    'visit_id',
    FILTER_VALIDATE_INT
);

if (!$visit_id) {

    die("Invalid visit ID.");

}


/*
|--------------------------------------------------------------------------
| Helper for Optional Numeric Fields
|--------------------------------------------------------------------------
*/

function nullable_value($value)
{
    $value = trim((string)$value);

    return $value === '' ? null : $value;
}


/*
|--------------------------------------------------------------------------
| Get Form Data
|--------------------------------------------------------------------------
*/

$weight_kg = nullable_value(
    $_POST['weight_kg'] ?? ''
);

$height_cm = nullable_value(
    $_POST['height_cm'] ?? ''
);

$temperature_c = nullable_value(
    $_POST['temperature_c'] ?? ''
);

$systolic_bp = nullable_value(
    $_POST['systolic_bp'] ?? ''
);

$diastolic_bp = nullable_value(
    $_POST['diastolic_bp'] ?? ''
);

$pulse_bpm = nullable_value(
    $_POST['pulse_bpm'] ?? ''
);

$respiratory_rate = nullable_value(
    $_POST['respiratory_rate'] ?? ''
);

$spo2_percent = nullable_value(
    $_POST['spo2_percent'] ?? ''
);

$pain_score = nullable_value(
    $_POST['pain_score'] ?? ''
);

$symptoms = trim(
    $_POST['symptoms'] ?? ''
);

$notes = trim(
    $_POST['notes'] ?? ''
);


/*
|--------------------------------------------------------------------------
| Triage Priority
|--------------------------------------------------------------------------
*/

$priority = $_POST['priority'] ?? 'Routine';

$allowed_priorities = [
    'Routine',
    'Urgent',
    'Emergency'
];

if (!in_array($priority, $allowed_priorities, true)) {

    $priority = 'Routine';

}


/*
|--------------------------------------------------------------------------
| Logged-in User
|--------------------------------------------------------------------------
*/

$assessed_by = $_SESSION['user_id'] ?? null;


/*
|--------------------------------------------------------------------------
| Validate Visit
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        visit_id,
        patient_id,
        visit_number,
        status

    FROM patient_visits

    WHERE visit_id = ?

    LIMIT 1
");

$stmt->execute([
    $visit_id
]);

$visit = $stmt->fetch(PDO::FETCH_ASSOC);


if (!$visit) {

    die("The selected visit does not exist.");

}


/*
|--------------------------------------------------------------------------
| Save Triage
|--------------------------------------------------------------------------
*/

try {

    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | Check Whether Triage Already Exists
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT id

        FROM triage

        WHERE visit_id = ?

        LIMIT 1
    ");

    $stmt->execute([
        $visit_id
    ]);

    $existing_triage = $stmt->fetch(PDO::FETCH_ASSOC);


    /*
    |--------------------------------------------------------------------------
    | UPDATE Existing Triage
    |--------------------------------------------------------------------------
    */

    if ($existing_triage) {

        $triage_id = $existing_triage['id'];

        $sql = "
            UPDATE triage

            SET
                visit_id = ?,
                weight_kg = ?,
                height_cm = ?,
                temperature_c = ?,
                systolic_bp = ?,
                diastolic_bp = ?,
                pulse_bpm = ?,
                respiratory_rate = ?,
                spo2_percent = ?,
                pain_score = ?,
                symptoms = ?,
                priority = ?,
                notes = ?,
                assessed_by = ?,
                assessed_at = NOW()

            WHERE id = ?
        ";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([

            $visit_id,

            $weight_kg,

            $height_cm,

            $temperature_c,

            $systolic_bp,

            $diastolic_bp,

            $pulse_bpm,

            $respiratory_rate,

            $spo2_percent,

            $pain_score,

            $symptoms,

            $priority,

            $notes,

            $assessed_by,

            $triage_id

        ]);

    }


    /*
    |--------------------------------------------------------------------------
    | INSERT New Triage
    |--------------------------------------------------------------------------
    */

    else {

        $sql = "
            INSERT INTO triage
            (
                visit_id,
                weight_kg,
                height_cm,
                temperature_c,
                systolic_bp,
                diastolic_bp,
                pulse_bpm,
                respiratory_rate,
                spo2_percent,
                pain_score,
                symptoms,
                priority,
                notes,
                assessed_by,
                assessed_at
            )

            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                ?,
                NOW()
            )
        ";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([

            $visit_id,

            $weight_kg,

            $height_cm,

            $temperature_c,

            $systolic_bp,

            $diastolic_bp,

            $pulse_bpm,

            $respiratory_rate,

            $spo2_percent,

            $pain_score,

            $symptoms,

            $priority,

            $notes,

            $assessed_by

        ]);

    }


    /*
    |--------------------------------------------------------------------------
    | Move Visit to Consultation
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        UPDATE patient_visits

        SET status = 'Consultation'

        WHERE visit_id = ?
    ");

    $stmt->execute([
        $visit_id
    ]);


    /*
    |--------------------------------------------------------------------------
    | Commit Transaction
    |--------------------------------------------------------------------------
    */

    $pdo->commit();


    /*
    |--------------------------------------------------------------------------
    | Redirect to Consultation Queue
    |--------------------------------------------------------------------------
    */

    header(
        'Location: ../consultation/queue.php?saved=1'
    );

    exit;


} catch (PDOException $e) {


    /*
    |--------------------------------------------------------------------------
    | Rollback if Something Goes Wrong
    |--------------------------------------------------------------------------
    */

    if ($pdo->inTransaction()) {

        $pdo->rollBack();

    }


    die(
        "<h3>Unable to save triage assessment</h3>" .
        "<p>" .
        htmlspecialchars(
            $e->getMessage()
        ) .
        "</p>"
    );

}