# HMS1 Patient Registration Module

1. Back up your current hms1 folder and database.
2. Extract/merge these files into C:\xampp\htdocs\hms1.
3. If your existing `patients` and `patient_visits` tables already contain the required columns, keep them and do not recreate them.
4. Otherwise import `database/patient_registration.sql` in phpMyAdmin.
5. Check `config/database.php` for your MySQL credentials.
6. Ensure `includes/auth.php` contains `check_authentication()` and your login stores `$_SESSION['user_id']`.
7. Start Apache and MySQL.

Test:
http://localhost/hms1/dashboard/index.php
http://localhost/hms1/patients/register.php

Workflow:
Registration -> Patient Profile -> Start New Visit -> status Registered -> Triage Queue

If MySQL reports `Unknown column ...`, send the exact error and the structure of the affected table; the PHP should be aligned to your existing schema rather than randomly changing the code.
