<?php
require_once __DIR__.'/auth.php';
check_authentication();
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?=htmlspecialchars($page_title??'Hospital Management System')?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary"><div class="container-fluid">
<a class="navbar-brand fw-bold" href="/hms1/dashboard/index.php">HMS</a>
<div class="navbar-nav me-auto">
<a class="nav-link" href="/hms1/dashboard/index.php">Dashboard</a>
<a class="nav-link" href="/hms1/patients/register.php">Register Patient</a>
<a class="nav-link" href="/hms1/patients/search.php">Patients</a>
</div>
<span class="navbar-text text-white me-3"><?=htmlspecialchars(get_current_user_name())?></span>
<a class="btn btn-light btn-sm" href="/hms1/auth/logout.php">Logout</a>
</div></nav><main class="container-fluid py-4">