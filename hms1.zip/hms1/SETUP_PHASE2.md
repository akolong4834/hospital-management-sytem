# Hospital Management System — Phase 2

This package extends Phase 1 using the same `hospital_management` schema.

## Install
1. Keep the Phase 1 project/database.
2. Replace/add these folders/files from this ZIP into your `hospital_management` folder.
3. Do NOT recreate the database if you already imported the original SQL.
4. Start Apache and MySQL.

## Workflow now available
Patient registration
→ Visit
→ Triage
→ Consultation
→ Laboratory order/results
→ Prescription
→ Pharmacy dispensing
→ Billing/invoice
→ Payment
→ Receipt

## Test
1. Login.
2. Register patient.
3. Create visit.
4. Open `triage/queue.php`.
5. Assess patient and save.
6. Open consultation queue.
7. Enter clinical notes.
8. Select laboratory tests and/or medicines.
9. Save consultation.
10. Process laboratory order and enter results.
11. Dispense prescription.
12. Generate invoice.
13. Record payment.
14. Print receipt.

## Navigation
Phase 1 sidebar has the main pages. You can directly open:
- `/triage/queue.php`
- `/consultation/queue.php`
- `/laboratory/orders.php`
- `/pharmacy/prescriptions.php`

## Important
This is a development implementation. Before production use, add:
- strict role-based permissions
- CSRF protection
- comprehensive validation
- secure session cookies
- audit logging on every clinical/financial action
- stock-batch dispensing and stock transaction ledger
- proper insurance/SHA claims workflow
- M-Pesa Daraja callback verification
- PDF receipts/invoices
- backups, HTTPS and appropriate health-data/privacy controls.
